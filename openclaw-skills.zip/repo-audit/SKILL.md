---
name: repo-audit
description: Incremental repository audit for team knowledge bases and skill repos. Use when performing scheduled or manual repo inspections, PR reviews, branch cleanup, or content quality checks. Designed for repos with kb/ (knowledge base) and skills/ (agent skills) directories. Supports incremental diffing to avoid redundant checks on stable content.
---

# Repo Audit — Incremental Repository Inspection

Perform incremental audits on a team repository, checking only changed files since the last audit. Handles PR review, branch cleanup, content quality validation, and skill integrity checks.

## Prerequisites

- `gh` CLI authenticated with repo access
- Git repo cloned locally
- GH_TOKEN available (e.g. via `source .env`)

## Configuration

The skill uses two config files in an `audit/` directory (configurable):

### `last-audit-commit`
Single line: the commit SHA from the last completed audit. Updated automatically after each run.

### `audit-ignore.json`
Files to skip for format/classification suggestions. Modified files (`M` status) are re-examined even if listed here.

```json
{
  "_comment": "Reason for each ignore entry",
  "kb/tools/some-file.md": "guide format confirmed"
}
```

## Workflow

### Step 0: Cron Check & SOP Sync

This step ensures the巡检 SOP is persisted in workspace and checks whether a matching cron job exists.

1. **Sync SOP**: Ensure `workspace/procedures/repo-audit.md` exists and matches the巡检 workflow (Steps 1-7 below).
   - If the file does not exist → generate it from Steps 1-7
   - If the file exists but is outdated (missing key steps like PR review, incremental diff, or branch cleanup) → update it
   
2. **Check cron**: List current cron jobs (`cron action=list`) and look for a scheduled repo audit task:
   - **Match criteria**: the cron payload references `procedures/repo-audit.md` or contains an equivalent incremental audit workflow for the same target repo
   - ✅ **Exists and matches** → do not remind, proceed to Step 1
   - ❌ **Does not exist** → remind the user to set up a scheduled cron job, suggest the recommended config below, then proceed to Step 1
   - ⚠️ **Exists but mismatched** (e.g. missing PR review, missing incremental diff, wrong repo path) → remind the user to update the cron job, explain the discrepancy, then proceed to Step 1

3. **Regardless of cron status**, continue executing the audit (Steps 1-7).

**Recommended cron configuration** (use when reminding):
```
- Schedule: daily at 10:00 (or user's preference)
- sessionTarget: isolated
- payload kind: agentTurn
- message: "按照 workspace/procedures/repo-audit.md 对 <repo-path> 执行仓库巡检"
- delivery: announce
```

### Step 1: Setup
1. Load credentials (e.g. `source .env`)
2. `cd <repo> && git pull`

### Step 2: Compute Incremental Diff
1. Read `last-audit-commit` to get baseline SHA
2. Run `git diff <baseline>..HEAD --name-status` to get changed files
3. If no changes AND no open PRs → output "✅ No changes, no pending PRs", update baseline, end

### Step 3: PR Review
For each open PR (`gh pr list`):
1. `gh pr diff` to review changes
2. Apply review policy (see [references/review-policy.md](references/review-policy.md))
3. Submit review via `gh pr review` (approve / comment / request-changes)
4. Auto-merge approved PRs per policy + delete merged branches

### Step 4: Branch Cleanup
1. List all remote branches via `gh api`
2. Delete branches whose associated PR is MERGED or CLOSED
3. Preserve branches with OPEN PRs

### Step 5: Incremental Content Check
Only examine files from the diff (Step 2), excluding entries in `audit-ignore.json` that were NOT modified:

**kb/ files:**
- Format check: symptom/cause/solution structure, or guide format
- Classification: file in correct subdirectory?
- Dedup: compare against existing kb entries via search

**skills/ files:**
- SKILL.md integrity: `name`, `description` fields present
- Referenced paths exist
- Scripts: basic syntax check or dry-run if applicable

**Re-examine rule:** If a file appears in `audit-ignore.json` but has `M` (modified) status in the diff, re-examine it.

### Step 6: Update Baseline
Write current HEAD SHA to `last-audit-commit`.

### Step 7: Generate Report
Include only sections with content; omit empty sections entirely.

```
📋 Repo Incremental Audit Report (date)
🔀 PR Review (reviewed PRs, outcomes, auto-merge records)
🧹 Branch Cleanup (deleted/retained branches)
📝 Incremental Changes (changed files + findings)
🔴 Action Required (critical issues)
🟡 Suggestions (non-critical improvements)
🟢 Contributions (who committed what, incremental period only)
```

Keep it concise. Each suggestion should name the specific file and recommended action. If no changes and no PRs, output a single summary line.

## Optional: Prescan Script

For large repos, run a shell prescan script before LLM analysis to gather stats cheaply. See [scripts/prescan.sh](scripts/prescan.sh) for a reference implementation.

## Customization

- **Review policy**: Edit [references/review-policy.md](references/review-policy.md) to match your team's PR review rules
- **Ignore list**: Add stable files to `audit-ignore.json` to suppress repeated suggestions
- **Prescan**: Adapt `scripts/prescan.sh` for your repo structure
- **Schedule**: The skill auto-detects cron status (Step 0). No manual reminder management needed.
