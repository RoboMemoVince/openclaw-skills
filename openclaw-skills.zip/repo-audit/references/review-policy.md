# PR Review Policy

## Review Strategy by Change Type

| Change Type | Default Action | Details |
|-------------|---------------|---------|
| New kb/ file | Auto approve | Check format and classification |
| Modify existing file | Careful review | Examine diff for correctness |
| Delete file | Request changes | Require justification |
| skills/ changes | Review SKILL.md | Check completeness (name/description/platform) |

## Auto-Merge Rules

- Approved non-owner PRs → merge + delete branch immediately
- Owner PRs cannot self-approve (GitHub limitation) → merge directly if review passes; flag issues otherwise
- PRs already approved by owner → merge directly

## Sensitive Content

- Reject PRs containing credentials, tokens, or personal identifiers (open_id, API keys, etc.)
- Flag and request changes with specific line references

## Merge Method

- Default: merge commit (not squash, not rebase)
- Always delete branch after merge
