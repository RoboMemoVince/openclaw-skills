# Repo Audit — Standard Operating Procedure

This file is the standalone巡检 SOP, referenced by cron jobs. It is auto-generated/updated by the repo-audit skill (Step 0).

## Prerequisites

- `gh` CLI authenticated with repo access
- Git repo cloned locally
- GH_TOKEN available (e.g. via `source .env`)

## Configuration

Uses two config files in the repo's `audit/` directory:

- `last-audit-commit` — baseline SHA, updated after each run
- `audit-ignore.json` — files to skip (re-examined if modified)

## Workflow

### Step 1: Setup
1. Load credentials (e.g. `source .env`)
2. `cd <repo> && git pull`

### Step 2: Compute Incremental Diff
1. Read `audit/last-audit-commit` to get baseline SHA
2. Run `git diff <baseline>..HEAD --name-status` to get changed files
3. If no changes AND no open PRs → output "✅ No changes, no pending PRs", update baseline, end

### Step 3: PR Review
For each open PR (`gh pr list`):
1. `gh pr diff` to review changes
2. Apply review policy (check for: sensitive content, format, correctness)
3. Submit review via `gh pr review` (approve / comment / request-changes)
4. Auto-merge approved PRs per policy + delete merged branches

### Step 4: Branch Cleanup
1. List all remote branches
2. Delete branches whose associated PR is MERGED or CLOSED
3. Preserve branches with OPEN PRs

### Step 5: Incremental Content Check
Only examine files from the diff (Step 2), excluding entries in `audit-ignore.json` that were NOT modified:

**kb/ files:**
- Format check: symptom/cause/solution structure, or guide format
- Classification: file in correct subdirectory?
- Dedup: compare against existing kb entries

**skills/ files:**
- SKILL.md integrity: `name`, `description` fields present
- Referenced paths exist
- Scripts: basic syntax check

**Re-examine rule:** If a file appears in `audit-ignore.json` but has `M` (modified) status in the diff, re-examine it.

### Step 6: Update Baseline
Write current HEAD SHA to `audit/last-audit-commit`.

### Step 7: Generate Report
Include only sections with content; omit empty sections.

```
📋 Repo Incremental Audit Report (date)
🔀 PR Review (reviewed PRs, outcomes, auto-merge records)
🧹 Branch Cleanup (deleted/retained branches)
📝 Incremental Changes (changed files + findings)
🔴 Action Required (critical issues)
🟡 Suggestions (non-critical improvements)
🟢 Contributions (who committed what, incremental period only)
```

Keep it concise. If no changes and no PRs, output a single summary line.
