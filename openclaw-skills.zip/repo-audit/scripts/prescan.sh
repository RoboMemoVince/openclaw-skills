#!/bin/bash
# Repo Audit Prescan — collect stats via shell to reduce LLM token consumption
# Usage: bash prescan.sh [repo_dir] [baseline_sha]
set -euo pipefail

REPO_DIR="${1:-.}"
BASELINE="${2:-}"
cd "$REPO_DIR"

echo "=== Repo Audit Prescan $(date '+%Y-%m-%d %H:%M') ==="
echo ""

# 1. Basic stats
echo "## 📊 Basic Stats"
if [ -d "kb" ]; then
    echo "- kb/ md files: $(find kb -name '*.md' -type f 2>/dev/null | wc -l)"
fi
if [ -d "skills" ]; then
    echo "- skills/ directories: $(find skills -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)"
    echo "- skills/ total files: $(find skills -type f 2>/dev/null | wc -l)"
fi
echo ""

# 2. Incremental diff (if baseline provided)
if [ -n "$BASELINE" ]; then
    echo "## 📝 Changes since $BASELINE"
    DIFF_OUTPUT=$(git diff "$BASELINE"..HEAD --name-status 2>/dev/null || echo "")
    if [ -z "$DIFF_OUTPUT" ]; then
        echo "- No changes"
    else
        echo "$DIFF_OUTPUT" | while IFS=$'\t' read -r status file; do
            echo "- [$status] $file"
        done
    fi
    echo ""
fi

# 3. kb/ format check (only changed files if baseline provided)
echo "## 🔍 kb/ Format Check"
if [ -n "$BASELINE" ]; then
    FILES=$(git diff "$BASELINE"..HEAD --name-only --diff-filter=AM 2>/dev/null | grep '^kb/.*\.md$' || true)
else
    FILES=$(find kb -name '*.md' -type f ! -name 'README.md' 2>/dev/null || true)
fi
if [ -z "$FILES" ]; then
    echo "- No files to check"
else
    echo "$FILES" | while read -r f; do
        [ -f "$f" ] || continue
        missing=""
        grep -q '^## 症状' "$f" 2>/dev/null || missing="${missing}症状 "
        grep -q '^## 原因' "$f" 2>/dev/null || missing="${missing}原因 "
        grep -q '^## 解决方案' "$f" 2>/dev/null || missing="${missing}解决方案 "
        if [ -n "$missing" ]; then
            echo "- ⚠️ $f missing: $missing"
        fi
    done
fi
echo ""

# 4. skills/ structure check (only changed skills if baseline provided)
echo "## 🔍 skills/ Structure Check"
if [ -n "$BASELINE" ]; then
    SKILL_DIRS=$(git diff "$BASELINE"..HEAD --name-only 2>/dev/null | grep '^skills/' | cut -d/ -f1-2 | sort -u || true)
else
    SKILL_DIRS=$(find skills -mindepth 1 -maxdepth 1 -type d 2>/dev/null || true)
fi
if [ -z "$SKILL_DIRS" ]; then
    echo "- No skills to check"
else
    echo "$SKILL_DIRS" | while read -r d; do
        [ -d "$d" ] || continue
        skill_name=$(basename "$d")
        if [ ! -f "$d/SKILL.md" ]; then
            echo "- ❌ $skill_name/ missing SKILL.md"
        fi
    done
fi
echo ""

# 5. Open PRs
echo "## 🔀 Open PRs"
if command -v gh &>/dev/null; then
    gh pr list --limit 20 2>/dev/null || echo "- (gh not available or not authenticated)"
else
    echo "- (gh CLI not installed)"
fi
echo ""

# 6. Recent git activity (incremental period)
echo "## 📝 Recent Git Activity"
if [ -n "$BASELINE" ]; then
    git log "$BASELINE"..HEAD --oneline --format="- %h %s (%an)" 2>/dev/null || echo "- (no commits)"
else
    git log --since="7 days ago" --oneline --format="- %h %s (%an, %ar)" 2>/dev/null || echo "- (no commits)"
fi
echo ""

echo "=== Prescan Complete ==="
