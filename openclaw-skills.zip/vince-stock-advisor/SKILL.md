---
name: vince-stock-advisor
description: US and HK stock portfolio monitor, technical analysis, and trading advisor. Use when user asks about stock prices, portfolio performance, buy/sell timing, day-trading (做T) opportunities, market briefings, or any US/HK stock analysis. Covers real-time quotes, technical indicators, earnings calendars, and position tracking.
---

# Vince Stock Advisor

美股港股投资顾问 skill，覆盖实时行情、技术分析、做T策略、持仓跟踪。

## Data Sources (free, no API key)

### Yahoo Finance (primary)
- Real-time quotes: `https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range=5d`
- Quote summary: `https://query1.finance.yahoo.com/v10/finance/quoteSummary/{symbol}?modules=price,summaryDetail,defaultKeyStatistics,financialData,calendarEvents`
- US tickers: `MU`, `NVDA`, `GOOG`, `AVGO`, `DIA`, `SGOV`
- HK tickers: append `.HK` → `1810.HK`, `9988.HK`

### Sina Finance (HK stocks backup)
- `https://hq.sinajs.cn/list=hk01810` (real-time HK quotes)

### Market indices
- `^GSPC` (S&P 500), `^DJI` (Dow), `^IXIC` (Nasdaq)
- `^HSI` (Hang Seng), `^HSTECH` (HS Tech)
- `GC=F` (Gold), `CL=F` (Crude Oil), `^TNX` (10Y Treasury Yield)

## Portfolio File

Portfolio lives at workspace `portfolio.md`. Always read this file for current holdings. **Never fabricate position data.**

## Core Workflows

### 1. Fetch Real-Time Quotes

Use `web_fetch` to grab Yahoo Finance chart data:

```
web_fetch https://query1.finance.yahoo.com/v8/finance/chart/MU?interval=1d&range=5d
```

Parse JSON → extract `regularMarketPrice`, `regularMarketChange`, `regularMarketChangePercent`, `regularMarketVolume`.

For multiple tickers, batch with comma: `symbols=MU,NVDA,GOOG,AVGO`

### 2. Technical Analysis

Fetch 3-month daily data for indicators:

```
web_fetch https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range=3mo
```

Calculate from OHLCV data:
- **MA**: 5/10/20/60 day moving averages
- **RSI**: 14-day relative strength index
- **MACD**: 12/26/9 EMA crossover
- **Bollinger Bands**: 20-day MA ± 2σ
- **Volume**: vs 20-day average volume
- **Support/Resistance**: recent swing highs/lows

### 3. Day-Trading (做T) Analysis

For intraday opportunities, fetch 1-minute data:

```
web_fetch https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1m&range=1d
```

Identify:
- Intraday range (high - low) and % range
- Volume spikes (>2x average)
- Key intraday support/resistance levels
- Entry/exit zones based on price action

### 4. Morning Market Briefing

Daily briefing workflow (see `references/briefing-template.md`):
1. Fetch macro: gold, oil, 10Y yield, VIX
2. Fetch US portfolio positions + pre-market data
3. Fetch HK portfolio positions (if HK market hours)
4. Calculate P&L vs cost basis from portfolio.md
5. Check earnings calendar for upcoming reports
6. Generate trading recommendations

### 5. Earnings & Events

Check earnings dates via quote summary module `calendarEvents`:

```
web_fetch https://query1.finance.yahoo.com/v10/finance/quoteSummary/{symbol}?modules=calendarEvents,earnings
```

### 6. HK Stock Specifics

- HK market hours: 9:30-12:00, 13:00-16:00 HKT
- Use `.HK` suffix on Yahoo, zero-padded 4-digit codes: `1810.HK`, `9988.HK`
- For HK real-time during market hours, Sina may be faster

## Output Format

All analysis output must include:
1. **Current price + change** (absolute and %)
2. **vs cost basis** (P&L per position)
3. **Technical signal** (bullish/bearish/neutral + key indicator)
4. **Action recommendation** (buy/sell/hold + price levels)
5. **Risk warning** (upcoming events, volatility, etc.)

## Rules

- **Never fabricate prices or P&L data** — always fetch live data
- **Always read portfolio.md** for holdings before generating reports
- **Include risk warnings** on every recommendation
- **Be direct** — say bullish or bearish, don't hedge with "it depends"
- **做T recommendations** must include specific entry/exit price levels
