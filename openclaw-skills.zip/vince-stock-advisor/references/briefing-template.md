# Morning Briefing Template

## Structure

### 1. Macro Overview
- Gold (GC=F) price + daily change
- Crude Oil (CL=F) price + daily change  
- US 10Y Yield (^TNX) + change
- VIX if elevated (>20)
- Key geopolitical/macro news (1-2 bullet points)

### 2. US Portfolio (sorted by absolute P&L change)
For each position:
```
{emoji} {TICKER} {name} ${price} ({change%})
  Cost ${cost} | {shares}股 | P&L {+/-$amount} ({pct}%)
  {one-line catalyst or note}
```
Emoji: 🟢 up >1% | 🔴 down >1% | ⚪ flat

Subtotal: total market value, total unrealized P&L

### 3. HK Portfolio
Same format, prices in HKD

### 4. Watchlist Highlights (optional)
Only if significant moves (>3%) in watchlist stocks

### 5. Trading Plan
- **做T targets**: Specific stocks with entry/exit price levels
- **Hold recommendations**: With reasoning
- **Risk alerts**: Earnings dates, ex-dividend, macro events

### Data Fetch Order
1. `web_fetch` portfolio.md → get holdings
2. `web_fetch` Yahoo Finance → batch US quotes
3. `web_fetch` Yahoo Finance → HK quotes  
4. `web_fetch` Yahoo Finance → macro (gold, oil, yield)
5. Calculate all P&L from fetched data + portfolio cost basis
6. Format and deliver

### Critical Rules
- ONLY use prices from Yahoo Finance API responses
- ONLY use cost basis and share counts from portfolio.md
- If a fetch fails, say "data unavailable" — never estimate
