#!/usr/bin/env python3
"""Fetch real-time stock quotes from Yahoo Finance. No API key needed.

Usage:
    python3 fetch_quotes.py MU NVDA GOOG AVGO DIA SGOV 1810.HK
    python3 fetch_quotes.py --macro   # Gold, Oil, 10Y, VIX, indices
    python3 fetch_quotes.py --all     # Portfolio + macro
"""

import sys
import json
import urllib.request
import urllib.error

YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/{}?interval=1d&range=5d"

MACRO_SYMBOLS = {
    "GC=F": "Gold",
    "CL=F": "Crude Oil",
    "^TNX": "10Y Yield",
    "^VIX": "VIX",
    "^GSPC": "S&P 500",
    "^DJI": "Dow Jones",
    "^HSI": "Hang Seng",
    "^HSTECH": "HS Tech",
}

def fetch_quote(symbol):
    url = YAHOO_CHART.format(symbol)
    headers = {"User-Agent": "Mozilla/5.0"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        meta = data["chart"]["result"][0]["meta"]
        return {
            "symbol": symbol,
            "price": meta.get("regularMarketPrice"),
            "prevClose": meta.get("chartPreviousClose") or meta.get("previousClose"),
            "change": round(meta.get("regularMarketPrice", 0) - (meta.get("chartPreviousClose") or meta.get("previousClose", 0)), 4),
            "changePct": round((meta.get("regularMarketPrice", 0) / (meta.get("chartPreviousClose") or meta.get("previousClose", 1)) - 1) * 100, 2),
            "currency": meta.get("currency", "USD"),
            "exchangeName": meta.get("exchangeName", ""),
            "marketState": meta.get("marketState", ""),
        }
    except Exception as e:
        return {"symbol": symbol, "error": str(e)}

def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: fetch_quotes.py [symbols...] [--macro] [--all]")
        sys.exit(1)

    symbols = []
    if "--macro" in args or "--all" in args:
        symbols.extend(MACRO_SYMBOLS.keys())
    if "--all" in args:
        # Default portfolio
        symbols.extend(["MU", "NVDA", "GOOG", "AVGO", "DIA", "SGOV", "1810.HK"])
    
    # Add explicit symbols
    symbols.extend([s for s in args if not s.startswith("--")])
    
    # Deduplicate preserving order
    seen = set()
    unique = []
    for s in symbols:
        if s not in seen:
            seen.add(s)
            unique.append(s)

    results = []
    for sym in unique:
        q = fetch_quote(sym)
        label = MACRO_SYMBOLS.get(sym, sym)
        q["label"] = label
        results.append(q)

    print(json.dumps(results, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
