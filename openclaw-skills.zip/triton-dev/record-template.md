# Iteration Record Template

All iteration records go in `<operator_name>/ITERATIONS.md`. Copy templates below for each iteration.

## Operator Header (once per operator, at top of ITERATIONS.md)

```markdown
# <Operator Name> — Iteration Log

**Operator:** XX
**Shape set:** (B, S, N, D) = ...
**Entry script:** XX_fwd_test.py
**Kernel-name filter:** <kernel_name_substr>
**Start date:** YYYY-MM-DD
```

## Iteration Record (one per trial, append to ITERATIONS.md)

```markdown
### Iter NN: <change_tag>

**Date:** YYYY-MM-DD
**Change:** <what was changed, ONE variable only>
**Config:** BLOCK_M=XX, BLOCK_N=XX, ...
**Profiler dir:** profiler/iter_NN_<tag>/
**msprof dir:** msprof/iter_NN_<tag>/

| Metric | Value |
|--------|-------|
| Accuracy | PASS / FAIL (max relerr: X) |
| Bench time (μs) | XXX (reference only) |
| Kernel avg duration (μs) | XXX |
| msprof: cube_util | XX% |
| msprof: vec_util | XX% |
| msprof: wait_ratio | XX% |

**Conclusion:** continue / rollback / next: <what to try next>
**Commit:** `opt(XX): iter_NN <tag>` or `rollback(XX): iter_NN <tag>`
```

Before moving to next iteration, verify all boxes:

- [ ] **Single variable**: Only ONE main variable changed from previous iteration
- [ ] **Accuracy PASS**: All shapes in shape set pass `assert_close` (re-run even if "only tuning params changed")
- [ ] **Bench recorded**: Bench time logged (reference only, not definitive)
- [ ] **Profiler recorded**: kernel_details.csv collected, avg kernel duration logged
- [ ] **msprof analyzed** (if needed): Bottleneck signals identified
- [ ] **Record written**: Change point, config, results, signals, conclusion all filled in
- [ ] **Failure recorded** (if failed): UB overflow, backend error, etc. documented for pruning future search space

## Completion Checklist

Before declaring an operator "done":

- [ ] Reference implementation matches documentation line-by-line
- [ ] Backward reference verified against autograd (if backward exists)
- [ ] All shapes pass accuracy (small + target + tail/unaligned)
- [ ] All dtypes covered per operator convention
- [ ] `isfinite` check passes (no NaN/Inf)
- [ ] Profiler kernel duration meets target
- [ ] All iteration records are complete and committed
- [ ] Final record has clear "conclusion: done" with summary metrics
