---
name: triton-dev
description: Use when writing, optimizing, or debugging triton-ascend NPU operators on Ascend hardware. Also use when benchmarking Triton kernels or generating performance comparison reports.
platform: [openclaw, claude-code]
---

# Triton-Ascend NPU Operator Development

## Overview

End-to-end workflow for developing and optimizing triton-ascend operators on Ascend NPU.

**Core principle:** Correctness before performance. Always. No exceptions.

**Violating the letter of this process is violating the spirit of NPU operator development.**

## The Iron Laws

```
1. NO PERFORMANCE TUNING WITHOUT ACCURACY PASS FIRST
2. NO MULTI-VARIABLE CHANGES IN A SINGLE ITERATION
3. NO ITERATION WITHOUT A WRITTEN RECORD
```

Broke accuracy to chase performance? Rollback. Start over.
Changed two things at once? Can't isolate what worked. Rollback.
Didn't record an iteration? It didn't happen. You'll repeat the same dead end.

**No exceptions:**
- Not for "just a quick BLOCK size change"
- Not for "I'm pretty sure this won't affect accuracy"
- Not for "I'll record it later"

## When to Use

**Use for:**
- Writing new triton-ascend operators (forward and/or backward)
- Optimizing existing kernel performance (profiler/msprof-guided tuning)
- Debugging accuracy mismatches between reference and kernel
- Benchmarking Triton kernels vs Torch baselines
- Generating formal performance comparison reports

**Do NOT use for:**
- Pure Python wrapper optimization (no kernel changes) → standard debugging
- Exploring whether an operator is feasible → brainstorming first
- torch.compile / graph-level optimization → different workflow
- Reading/understanding existing Triton code → repo-explorer

## The Workflow

```dot
digraph triton_dev {
    rankdir=TB;

    start [label="Step 0\nGather materials\nClassify operator type" shape=box];
    ref [label="Step 1\nWrite reference\n(accuracy gold standard)" shape=box];
    bwd_check [label="Backward needed?" shape=diamond];
    autograd [label="Verify manual backward\nvs autograd" shape=box];
    impl [label="Step 2\nTriton implementation\n(get it running first)" shape=box];
    accuracy [label="Step 3\nAccuracy verification\n(all shapes, all dtypes)" shape=box style=filled fillcolor="#ccffcc"];
    acc_pass [label="Accuracy PASS?" shape=diamond];
    acc_fix [label="Fix kernel or reference\n(single variable only)" shape=box];
    bench [label="Step 4\nBench\n(quick filtering, reference only)" shape=box];
    profiler [label="Step 5\nProfiler\n(kernel_details.csv)" shape=box];
    target [label="Meets target?" shape=diamond];
    msprof [label="Step 6\nmsprof op\n(bottleneck signals)" shape=box];
    tune [label="Step 7\nTrial: change ONE variable\nRecord everything" shape=box];
    done [label="Done\nFinal record + summary" shape=doublecircle];

    start -> ref;
    ref -> bwd_check;
    bwd_check -> autograd [label="yes"];
    bwd_check -> impl [label="no"];
    autograd -> impl;
    impl -> accuracy;
    accuracy -> acc_pass;
    acc_pass -> bench [label="yes"];
    acc_pass -> acc_fix [label="no"];
    acc_fix -> accuracy [label="re-verify"];
    bench -> profiler;
    profiler -> target;
    target -> done [label="yes"];
    target -> msprof [label="no"];
    msprof -> tune;
    tune -> accuracy [label="MUST re-verify\naccuracy after\nANY change"];
}
```

**Key loop:** After ANY change (Step 7), you go back to accuracy verification (Step 3). Not bench. Not profiler. **Accuracy first.**

## Prerequisites

- All execution inside `triton-ascend-hcq` container. Check `ls /.dockerenv` first.
- `ASCEND_TOOLKIT_HOME` and driver library path must be set for msprof.
- Fixed shape set across iterations for valid comparison.
- Fixed seed for reproducibility.

**Environment template:**
```bash
docker exec -itu root triton-ascend-hcq /bin/bash -lc '
  source /usr/local/Ascend/ascend-toolkit/latest/bin/setenv.bash &&
  export PATH=/data0/hcq/Ascend/ascend-toolkit/8.3.RC2/bisheng_toolkit/bishengir/bin:$PATH &&
  cd <YOUR_WORKDIR> &&
  python3 <YOUR_ENTRY>.py --B 1 --S 2048 --N 4 --D 2560
'
```

## Step Details

### Step 0: Input Materials and Operator Classification

- Gather: operator description, pseudocode, reference implementation, or existing source code.
- Classify operator type → choose pattern:

| Operator Type | Key Operations | Pattern | Guide |
|---------------|---------------|---------|-------|
| Pure Vector | Element-wise, small reductions | Standard kernel | [01-vector-add](./demo/official_tutorials/01-vector-add.py) |
| Pure Cube | Matrix multiply only | tl.dot kernel | [05-matmul](./demo/official_tutorials/05-matrix-multiplication.py) |
| CV Mixed | MatMul + activation/norm | CV fusion with `tl.parallel` | [cv-fusion-pattern.md](./guides/cv-fusion-pattern.md) |
| Memory-bound | Gather/scatter/embedding | Custom memory ops | [ascend-api-reference.md](./guides/ascend-api-reference.md) |
| Reduction-heavy | Softmax, LayerNorm | Persistent kernel | [02-softmax](./demo/official_tutorials/02-fused-softmax.py) |

### Step 1: Reference (Accuracy Gold Standard)

Write PyTorch reference with line-by-line correspondence to documentation.

Cross-check:
- Input/output tensor shape, dtype, layout match documentation
- Computation flow matches: reshape, broadcast, mask, reduce, normalize, boundary handling
- Numerical strategy matches: FP32 cast points, eps placement, clamp necessity

**Backward (if needed) — autograd is the first line of defense:**
1. Forward reference + `requires_grad=True` + autograd → gradient baseline
2. Write manual backward reference
3. Verify manual backward vs autograd (**must pass before writing triton kernel**)

```python
# Verify manual backward against autograd
x = torch.randn(..., requires_grad=True)
y = forward_reference(x, ...)
y.backward(grad_output)
x_grad_autograd = x.grad.clone()
x_grad_manual, ... = backward_reference(grad_output, ...)
torch.testing.assert_close(x_grad_autograd, x_grad_manual, rtol=1e-5, atol=1e-5)
```

### Step 2: Triton Implementation

Get a runnable kernel first. If compilation fails, prioritize "minimal runnable version" then incrementally add optimizations.

File conventions, artifact inventory, and git discipline: see [file-conventions.md](./file-conventions.md)

**Required artifacts per operator:** core scripts (triton/ref/test/utils) + README.md + REPORT.md + ITERATIONS.md + profiler/ + msprof/ directories. Missing any = NOT done.

### Step 3: Accuracy Verification (Required Each Iteration)

**Every iteration. No exceptions. Even "just a BLOCK size change."**

Coverage requirements:
- **Shapes**: small (intermediate alignment) + target benchmark + tail/unaligned (triggering mask/remainder)
- **Dtypes**: per operator convention (commonly BF16 input, FP32 accumulation, BF16/FP32 output)
- **Assertions**: `torch.testing.assert_close` (dtype-appropriate tolerances), `isfinite` (NaN/Inf check)
- **Backward**: forward output aligned first, then gradients: `assert_close` + cosine similarity
- **Stability**: fixed seed, fixed inputs, fixed warmup/iters, no "intermittent pass/fail"

### Step 4: Bench (Quick Filtering)

Measure average duration as filtering entry point.

**⚠️ Bench time is REFERENCE ONLY.** It includes Python overhead (~200-300μs: tensor allocation, view/contiguous, cache lookup, kernel launch). **True kernel time comes from Step 5 profiler.**

### Step 5: Profiler (Identify Biggest Contributor)

Collect `kernel_details.csv`, examine average duration per kernel.

**CRITICAL: Only count rows with `Step Id`** (skip warmup rows):
```python
for row in reader:
    step_id = (row.get("Step Id") or "").strip()
    if not step_id:
        continue  # Skip warmup rows
    name = row.get("Name", "").strip()
    duration = float(row.get("Duration(us)", 0))
    durations_us[name] += duration
    kernel_counts[name] += 1
avg_duration = durations_us[name] / kernel_counts[name]
```

### Step 6: msprof op (Bottleneck Signals → Actions)

Translate "slow" into actionable items using msprof CSV metrics.

Quick reference: [op-optimizer.md](./references/op-optimizer.md)
Full guide: [msprof-op.md](./guides/msprof-op.md)
CSV interpretation: [csv-interpretation.md](./guides/csv-interpretation.md)

**Command template:**
```bash
export ASCEND_TOOLKIT_HOME=/usr/local/Ascend/ascend-toolkit/latest && \
source /usr/local/Ascend/ascend-toolkit/latest/bin/setenv.bash && \
export LD_LIBRARY_PATH=/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/driver/lib64:$LD_LIBRARY_PATH && \
msprof op \
  --kernel-name=<KERNEL_NAME_SUBSTR> \
  --output=<MSPROF_OUTPUT_ROOT>/<TAG> \
  --warm-up=5 --launch-count=1 --kill=on \
  --application="python3 <YOUR_ENTRY>.py --mode run <OTHER_ARGS>"
```

### Step 7: Trial-and-Error with Single-Variable Discipline

Change ONE variable. Record EVERYTHING in `ITERATIONS.md`. Use [record-template.md](./record-template.md).

Save profiler/msprof outputs to `profiler/iter_NN_<tag>/` and `msprof/iter_NN_<tag>/`.

Failures are valuable: UB overflow, backend unsupported paths, etc. prune future search space. **Record before rollback.**

### Git Checkpoints

Commit at every milestone. Never commit broken/unverified code. See [file-conventions.md](./file-conventions.md) for full git discipline.

| Event | Commit |
|-------|--------|
| Reference written + verified | `feat(XX): add reference implementation` |
| Kernel runnable | `feat(XX): add triton kernel (initial)` |
| First accuracy PASS | `feat(XX): accuracy pass on all shapes` |
| Baseline profiler collected | `bench(XX): baseline profiler collected` |
| Iteration accuracy PASS | `opt(XX): iter_NN <tag> — <result>` |
| Iteration FAIL (rollback) | `rollback(XX): iter_NN <tag> — <reason>` |
| Final report | `docs(XX): add final report` |

## Red Flags — STOP and Follow Process

If you catch yourself thinking:

- "Accuracy is close enough, let's see performance first"
- "I'll change BLOCK_M and BLOCK_N together, they're related"
- "Bench looks good, skip profiler this time"
- "I'll record this iteration later"
- "This optimization obviously won't affect accuracy"
- "Just one more quick change before re-running accuracy"
- "The tolerance can be looser for this operator"
- "msprof setup is too annoying, profiler is enough"

**ALL of these mean: STOP. You're rationalizing. Follow the process.**

## Common Rationalizations

| Excuse | Reality |
|--------|---------|
| "Accuracy is close enough" | "Close enough" compounds. 1% error × 100 layers = garbage. Fix it. |
| "Just tuning BLOCK sizes, won't affect correctness" | BLOCK sizes affect tiling, masking, reduction order. Re-verify. |
| "Changed two things but they're independent" | On NPU, nothing is independent. UB, pipeline, cache all interact. One variable. |
| "Bench time is good enough, skip profiler" | Bench includes ~300μs Python overhead. A 500μs bench might be 200μs kernel. Profiler tells truth. |
| "I'll record later" | You won't. And when you hit the same dead end next week, you'll wish you had. |
| "This is exploration, not real iteration" | Exploration without records is wandering. Every run that touches hardware gets recorded. |
| "Profiler is enough, don't need msprof" | Profiler shows WHAT is slow. msprof shows WHY. Without WHY, you're guessing. |
| "Manual backward matches my math" | Your math might be wrong. Autograd doesn't lie. Verify. |

## Common Failures (Quick Reference)

| Symptom | Cause | Action |
|---------|-------|--------|
| UB overflow | BLOCK too large | Reduce BLOCK_D/BLOCK_K/BLOCK_M, or split kernel |
| Backend unsupported | Unsupported IR path | Rollback to last compilable config, smaller step search |
| High variance | Non-determinism | Fix seed, increase iters, ensure no concurrent profiling |
| 2D broadcast precision anomaly | `[:, None] * [None, :]` pattern | Use explicit variable expansion. See [pitfalls](./guides/triton-ascend-pitfalls.md) |
| High scalar_ratio + low vec_ratio | Too many grid blocks | Restructure grid or unroll loops. See [op-optimizer](./references/op-optimizer.md) |
| msprof "Can't find libdcmi.so" | Environment not configured | See [troubleshooting.md](./troubleshooting.md) |

For detailed troubleshooting: [troubleshooting.md](./troubleshooting.md)

## Reference Documents

| Document | Content |
|----------|---------|
| [file-conventions.md](./file-conventions.md) | Artifact inventory, naming, code templates, git discipline |
| [record-template.md](./record-template.md) | Iteration record template + checklists |
| [troubleshooting.md](./troubleshooting.md) | msprof environment, import, device issues |
| [op-optimizer.md](./references/op-optimizer.md) | msprof signal → action quick reference |
| [tuning-case-study.md](./references/tuning-case-study.md) | Full tuning example with trial records |
| [triton-ascend-pitfalls.md](./guides/triton-ascend-pitfalls.md) | 12 common NPU pitfalls |
| [benchmark-comparison.md](./guides/benchmark-comparison.md) | Triton vs Torch performance comparison |
| [ascend-api-reference.md](./guides/ascend-api-reference.md) | Ascend-specific Triton API reference |
| [npu-options.md](./guides/npu-options.md) | NPUOptions parameters + msprof correlation |
| [cv-fusion-pattern.md](./guides/cv-fusion-pattern.md) | Cube-Vector fusion programming pattern |
| [migration-from-gpu.md](./guides/migration-from-gpu.md) | GPU Triton → Ascend migration guide |
| [compiler-pipeline.md](./guides/compiler-pipeline.md) | TTIR → Linalg → BiSheng compilation flow |
| [tutorials-index.md](./references/tutorials-index.md) | 15 official tutorials with learning path |

## Tools

| Tool | Purpose |
|------|---------|
| `tools/utils.py` | Profiler, benchmark, accuracy assertion utilities |
| `tools/estimate_ub_usage.py` | Estimate UB memory usage before running kernel |
| `tools/analyze_kernel_ir.py` | Analyze intermediate IR for optimization opportunities |
