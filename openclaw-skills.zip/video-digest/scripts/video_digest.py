#!/usr/bin/env python3
"""
Video Digest - Prepare frames + subtitle context for agent processing.

Usage:
  python video_digest.py --frames-dir ./frames/ --srt ./subtitles/final.srt --output ./report/ [--title "Title"] [--context-minutes 3]

Outputs:
  report/
  ├── frames/                  # Copied keyframe images (scene_001.jpg, ...)
  ├── frame_analysis/          # Empty dir for agent to fill
  └── frames_with_context.json # Frame metadata + nearby subtitles
"""

import argparse
import json
import os
import re
import shutil
from pathlib import Path


def parse_srt(srt_path: str) -> list[dict]:
    """Parse SRT file into list of {index, start, end, start_sec, end_sec, text}."""
    with open(srt_path, "r", encoding="utf-8") as f:
        content = f.read()

    entries = []
    blocks = re.split(r"\n\n+", content.strip())

    for block in blocks:
        lines = block.strip().split("\n")
        if len(lines) < 3:
            continue

        try:
            index = int(lines[0].strip())
        except ValueError:
            continue

        time_match = re.match(
            r"(\d{2}:\d{2}:\d{2}[,\.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,\.]\d{3})",
            lines[1].strip(),
        )
        if not time_match:
            continue

        start_str = time_match.group(1).replace(",", ".")
        end_str = time_match.group(2).replace(",", ".")
        text = "\n".join(lines[2:]).strip()

        entries.append(
            {
                "index": index,
                "start": start_str,
                "end": end_str,
                "start_sec": timestamp_to_seconds(start_str),
                "end_sec": timestamp_to_seconds(end_str),
                "text": text,
            }
        )

    return entries


def timestamp_to_seconds(ts: str) -> float:
    """Convert HH:MM:SS.mmm to seconds."""
    parts = ts.replace(",", ".").split(":")
    h, m = int(parts[0]), int(parts[1])
    s = float(parts[2])
    return h * 3600 + m * 60 + s


def seconds_to_timestamp(sec: float) -> str:
    """Convert seconds to HH:MM:SS."""
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def parse_frame_filename(fname: str) -> dict | None:
    """Parse scene_NNN_HH:MM:SS_sN.N.jpg filename."""
    m = re.match(r"scene_(\d+)_(\d{2}):(\d{2}):(\d{2})_s([\d.]+)\.jpg", fname)
    if not m:
        return None
    idx = int(m.group(1))
    h, mi, s = int(m.group(2)), int(m.group(3)), int(m.group(4))
    score = float(m.group(5))
    sec = h * 3600 + mi * 60 + s
    return {
        "index": idx,
        "filename": fname,
        "timestamp": f"{h:02d}:{mi:02d}:{s:02d}",
        "seconds": sec,
        "score": score,
    }


def get_subtitles_in_range(subs: list[dict], start_sec: float, end_sec: float) -> str:
    """Get subtitle text within a time range."""
    relevant = []
    for sub in subs:
        if sub["end_sec"] >= start_sec and sub["start_sec"] <= end_sec:
            relevant.append(f"[{sub['start']}] {sub['text']}")
    return "\n".join(relevant)


def main():
    parser = argparse.ArgumentParser(description="Prepare video digest data")
    parser.add_argument("--frames-dir", required=True, help="Directory with scene keyframes")
    parser.add_argument("--srt", required=True, help="SRT subtitle file")
    parser.add_argument("--output", required=True, help="Output directory (report/)")
    parser.add_argument("--title", default="Video Digest", help="Video title")
    parser.add_argument(
        "--context-minutes",
        type=float,
        default=3.0,
        help="Minutes of subtitle context around each frame (default: 3)",
    )
    args = parser.parse_args()

    output = Path(args.output)
    frames_out = output / "frames"
    analysis_out = output / "frame_analysis"
    frames_out.mkdir(parents=True, exist_ok=True)
    analysis_out.mkdir(parents=True, exist_ok=True)

    # Parse subtitles
    print(f"Parsing SRT: {args.srt}")
    subs = parse_srt(args.srt)
    print(f"  Found {len(subs)} subtitle entries")

    # Parse and sort frame files
    frames_dir = Path(args.frames_dir)
    frame_files = sorted(frames_dir.glob("scene_*.jpg"))
    frames = []
    for f in frame_files:
        info = parse_frame_filename(f.name)
        if info:
            info["source_path"] = str(f)
            frames.append(info)

    frames.sort(key=lambda x: x["seconds"])
    print(f"Found {len(frames)} scene keyframes")

    # For each frame: copy image + extract context subtitles
    result = {
        "title": args.title,
        "total_frames": len(frames),
        "total_subtitles": len(subs),
        "context_minutes": args.context_minutes,
        "frames": [],
    }

    for i, frame in enumerate(frames):
        # Copy frame to output with clean name
        dest = frames_out / f"scene_{frame['index']:03d}.jpg"
        shutil.copy2(frame["source_path"], dest)

        # Determine segment time range (this frame to next frame)
        next_sec = (
            frames[i + 1]["seconds"]
            if i + 1 < len(frames)
            else (subs[-1]["end_sec"] if subs else frame["seconds"] + 300)
        )

        # Context subtitles: ±context_minutes around frame
        ctx_start = frame["seconds"] - args.context_minutes * 60
        ctx_end = frame["seconds"] + args.context_minutes * 60
        context_subs = get_subtitles_in_range(subs, ctx_start, ctx_end)

        # Segment subtitles: from this frame to next frame
        segment_subs = get_subtitles_in_range(subs, frame["seconds"], next_sec)

        frame_entry = {
            "index": frame["index"],
            "timestamp": frame["timestamp"],
            "seconds": frame["seconds"],
            "score": frame["score"],
            "image_path": str(dest),
            "relative_image": f"frames/scene_{frame['index']:03d}.jpg",
            "context_subtitles": context_subs,
            "segment_subtitles": segment_subs,
            "segment_start": frame["timestamp"],
            "segment_end": seconds_to_timestamp(next_sec),
        }
        result["frames"].append(frame_entry)

    # Write JSON
    json_path = output / "frames_with_context.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\nOutput written to: {output}")
    print(f"  frames/                  - {len(frames)} keyframe images")
    print(f"  frame_analysis/          - empty, for agent to fill")
    print(f"  frames_with_context.json - frame metadata + subtitle context")
    print(f"\nNext steps:")
    print(f"  1. Agent reads frames_with_context.json")
    print(f"  2. For each frame: call vision model with image + subtitle context")
    print(f"  3. Save analysis to frame_analysis/scene_NNN.md")
    print(f"  4. Assemble digest.md")


if __name__ == "__main__":
    main()
