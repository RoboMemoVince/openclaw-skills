---
name: video-digest
description: End-to-end video understanding pipeline. Downloads video, extracts keyframes, generates subtitles with hotwords, and produces a comprehensive Markdown report with embedded images. Orchestrates bilibili-downloader, video-frames, video-subtitles, and vision model.
---

# Video Digest

End-to-end pipeline: **Download → Frames → Subtitles → Report**

## Project Structure

Every video digest lives in a single project directory:

```
{project}/
├── source/
│   └── video.mp4              # Downloaded video
├── frames/
│   ├── scene_001_00:00:08_s11.3.jpg
│   ├── scene_002_00:01:49_s5.7.jpg
│   └── ...                    # Scene-detected keyframes
├── subtitles/
│   ├── preview_00:06:00.jpg   # 5 preview frames for hotwords
│   ├── hotwords.txt           # Extracted technical terms
│   ├── raw.srt                # Raw ASR output
│   ├── fixes.json             # Agent-generated fix dictionary
│   └── final.srt              # Post-processed subtitles
└── report/
    ├── digest.md              # Final report document
    ├── frames/                # Keyframe images (copied for portability)
    │   ├── scene_001.jpg
    │   └── ...
    ├── frame_analysis/        # Per-frame vision analysis
    │   ├── scene_001.md
    │   └── ...
    └── frames_with_context.json  # Frame + subtitle context data
```

## Quick Reference

```
project=~/workspace/downloads/{video_name}
```

## Pipeline

### Phase 1: Download Video

Use `bilibili-downloader` skill (or any other source):

```bash
python3 {skillsDir}/bilibili-downloader/scripts/download_video.py \
    BV1xxxxxxxxx {project}/source/ 64
```

Rename to a descriptive name if needed.

### Phase 2: Extract Keyframes

```bash
FFMPEG=/tmp/ffmpeg bash {skillsDir}/video-frames/scripts/frame.sh \
    {project}/source/video.mp4 \
    --scene-detect --threshold 3.0 \
    --outdir {project}/frames/
```

#### 2b. Deduplicate Frames (optional)

Remove near-duplicate frames using perceptual hashing:

```bash
FFMPEG=/tmp/ffmpeg python3 {skillsDir}/video-frames/scripts/dedup_frames.py \
    --frames-dir {project}/frames/ \
    --threshold 10 --renumber
```

Use `--dry-run` first to preview. This step is fast (~1s for 40 frames) and reduces unnecessary vision API calls. Typically saves 10-30% of frames for lecture content.

### Phase 3: Generate Subtitles (先看再听)

#### 3a. Extract 5 Preview Frames

```bash
mkdir -p {project}/subtitles
duration=$(ffprobe -v error -show_entries format=duration \
    -of default=noprint_wrappers=1:nokey=1 {project}/source/video.mp4)
# Calculate 5 evenly-spaced timestamps and extract frames
```

#### 3b. Vision → Hotwords

Use the `image` tool to analyze the 5 preview frames:

**Prompt template:**
> "这是一个技术视频的5个均匀采样帧。请仔细阅读每张幻灯片/画面上的所有文字，识别出所有专业术语（中英文）、缩写和全称、关键技术概念。输出为简洁的术语列表。"

Save results to `{project}/subtitles/hotwords.txt` (one term per line).

#### 3c. ASR Transcription

**Auto-select ASR provider** (see `video-subtitles` SKILL.md for selection logic):

火山引擎 (primary, if `VOLC_APP_ID` + `VOLC_ACCESS_TOKEN` set):
```bash
{skillsDir}/video-subtitles/scripts/volc_asr.py \
    {project}/source/video.mp4 --srt \
    --hotwords-file {project}/subtitles/hotwords.txt \
    -o {project}/subtitles/raw.srt
```

阿里云百炼 DashScope (fallback, if `DASHSCOPE_API_KEY` set):
```bash
{skillsDir}/video-subtitles/scripts/dashscope_asr.py \
    {project}/source/video.mp4 --srt \
    --hotwords-file {project}/subtitles/hotwords.txt \
    -o {project}/subtitles/raw.srt
```
#### 3d. Review + Fix (2-3 rounds)

1. Sample lines from `raw.srt`
2. Use domain knowledge from 3b to identify errors
3. Create `{project}/subtitles/fixes.json`
4. Apply:

```bash
{skillsDir}/video-subtitles/scripts/fix_srt.py \
    {project}/subtitles/raw.srt \
    --dict {project}/subtitles/fixes.json \
    -o {project}/subtitles/final.srt
```

### Phase 4: Generate Report

#### 4a. Prepare Frame + Subtitle Context

```bash
python3 {baseDir}/scripts/video_digest.py \
    --frames-dir {project}/frames/ \
    --srt {project}/subtitles/final.srt \
    --output {project}/report/ \
    --title "Video Title"
```

#### 4b. Vision Analysis (parallel sub-agents)

Read `{project}/report/frames_with_context.json`, then **spawn multiple sub-agents in parallel** to analyze frames concurrently.

**Strategy:** Split N frames into groups of ~8 frames each, spawn one sub-agent per group. Each sub-agent processes its frames in batches of 4 (image tool limit) and writes results to `frame_analysis/scene_NNN.md`.

**Example for 40 frames → 5 sub-agents:**

```
Sub-agent 1: frames 1-8   (2 batches of 4)
Sub-agent 2: frames 9-16  (2 batches of 4)
Sub-agent 3: frames 17-24 (2 batches of 4)
Sub-agent 4: frames 25-32 (2 batches of 4)
Sub-agent 5: frames 33-40 (2 batches of 4)
```

**Sub-agent task template:**
```
Analyze frames {start}-{end} from a technical lecture video.

For each batch of 4 frames, use the `image` tool with this prompt:
"分析这4张技术讲座幻灯片。标题、内容、要点。"

For each frame, write a markdown file to:
  {project}/report/frame_analysis/scene_NNN.md

Include: timestamp, slide title, content summary, subtitle text.
Subtitle context for each frame is in:
  {project}/report/frames_with_context.json

Frame images are at:
  {project}/report/frames/scene_NNN.jpg
```

**Spawn with `sessions_spawn`:**
```python
sessions_spawn(
    task="<task template above>",
    mode="run",
    cleanup="delete"
)
```

All sub-agents write to the same `frame_analysis/` directory. After all complete, the main agent assembles the final report.

**Fallback (serial):** If sub-agents are unavailable, process in batches of 4 frames serially (10 rounds for 40 frames).

**Prompt template (per batch):**
> "技术讲座关键帧。对每张图：1.标题 2.完整文字 3.代码 4.要点。"

#### 4c. Assemble Final Report

Read all `frame_analysis/scene_NNN.md` files + subtitle data, generate `digest.md`.

**📄 完整报告模板 (必须严格遵循):**

```markdown
# {视频标题}

> 视频来源：Bilibili (BVxxxx) | 时长：{XX}分钟 | 关键帧：{N}张

---

## 📋 课程总结

[Agent 根据所有帧分析提炼的核心要点]

### 核心要点
1. 要点1
2. 要点2
3. ...

### 适合对象
[目标受众]

---

## Segment 1: {start_time} - {end_time}

![scene_001](frames/scene_001.jpg)

# Scene 1 — {画面标题}

**时间戳**: {start_time}

## 幻灯片标题
{标题}

## 完整文字内容
{OCR 识别的完整文字}

## 代码
{如有代码}

## 核心要点
- 要点1
- 要点2

### 字幕内容
{该时间段的完整字幕文本}

---

## Segment 2: {start_time} - {end_time}

![scene_002](frames/scene_002.jpg)

# Scene 2 — {画面标题}

... (重复上述结构)
```

**⚠️ 关键要求:**
- 每个 Segment 必须嵌入对应的帧图片 `![](frames/scene_NNN.jpg)`
- 每个 Segment 必须包含完整字幕内容
- 每个 Segment 必须有详细的画面分析（标题、文字、代码、要点）
- 参考 `downloads/digest/digest.md` 作为标准格式

## Cost & Time Estimate

| Phase | Cost | Time (serial) | Time (parallel) |
|-------|------|---------------|-----------------|
| Download | Free | ~1min | — |
| Frames + Dedup | Free | ~10s | — |
| ASR (火山引擎/DashScope) | ~1h quota | ~2-6min | — |
| Preview vision (5 frames) | ~$0.15 | ~30s | — |
| Report vision (40 frames) | ~$0.60-0.90 | **~3-5min** | **~40-60s** (5 agents) |
| **Total** | **~$0.75-1.05/hr** | **~8-10min** | **~4-5min** |

## Tips

- **Scene threshold**: 3.0 for PPT lectures, 1.0-2.0 for dynamic content
- **Hotwords matter**: They significantly improve ASR accuracy for domain terms
- **Batch vision calls**: 4 frames per call to balance cost and quality
- **Subtitle context ±3min**: Gives vision model enough context for domain terms
- **Code extraction**: Vision model reliably extracts code from slides when asked explicitly
- **Preview vs full frames**: 5 preview frames for hotwords, all scene frames for report
- **frame.sh bug**: The script now correctly parses `lavfi.scd.time` timestamps (fixed sed regex)
- **📄 报告格式**: 必须严格遵循上述模板，每个 Segment 包含：帧图片 + 画面分析 + 完整字幕
- **通用模板**: 此格式适用于所有技术视频分析（如 Ascend C 编译调试、SIMT 编程等）

## Requirements

- **Skills**: `bilibili-downloader`, `video-frames`, `video-subtitles`
- **Tools**: ffmpeg, ffprobe, python3
- **APIs**: 火山引擎 ASR 或 阿里云百炼 DashScope ASR, vision model (image tool)
- **Python packages**: requests, bilibili-api-python, dashscope (for DashScope fallback)

### Phase 5: Cleanup

After the report is generated and delivered (e.g. sent to user, synced to Feishu), **proactively ask the user** whether to clean up temporary files:

> "报告已生成。是否清理临时文件？将只保留最终学习报告和相关插图，删除视频源文件、中间帧、字幕中间产物等（预计释放 XXX MB）。"

**If user confirms cleanup:**

保留的文件（白名单）：
```
{project}/
├── report/
│   ├── digest.md              # 最终报告（必须保留）
│   └── frames/                # 报告中引用的插图（如有）
│       ├── scene_001.jpg
│       └── ...
└── subtitles/
    └── final.srt              # 修正后字幕（必须保留）
```

删除的文件：
```
{project}/source/              # 视频源文件（最大）
{project}/frames/              # 原始关键帧（report/frames/ 已有副本）
{project}/subtitles/audio.*    # 提取的音频
{project}/subtitles/raw.srt    # 原始 ASR 字幕
{project}/subtitles/raw_result.json
{project}/subtitles/hotwords.txt
{project}/subtitles/fixes.json
{project}/subtitles/preview_*  # 预览帧
{project}/report/frames_with_context.json
{project}/report/frame_analysis/  # 中间分析文件
```

**Cleanup script:**
```bash
PROJECT={project}

# 删除视频源、原始帧、音频
rm -rf "$PROJECT/source"
rm -rf "$PROJECT/frames"

# 删除字幕中间产物（保留 final.srt）
rm -f "$PROJECT/subtitles/audio."*
rm -f "$PROJECT/subtitles/raw.srt"
rm -f "$PROJECT/subtitles/raw_result.json"
rm -f "$PROJECT/subtitles/hotwords.txt"
rm -f "$PROJECT/subtitles/fixes.json"
rm -f "$PROJECT/subtitles/"preview_*

# 删除报告中间产物（保留 digest.md + frames/）
rm -f "$PROJECT/report/frames_with_context.json"
rm -rf "$PROJECT/report/frame_analysis"

# 清理全局临时文件
rm -f /tmp/asr_input.wav
```

**Important:**
- 清理前先检查 `digest.md` 中是否引用了 `report/frames/` 下的图片，如有则**保留** `report/frames/` 目录
- 如果 `digest.md` 中没有图片引用（或图片已改为文字描述），则 `report/frames/` 也可删除
- 清理后显示前后空间对比（如 "98MB → 88KB"）
- **不要自动清理**，必须先询问用户确认
