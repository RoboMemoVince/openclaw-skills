# Evidence Guide — 取证页制作指南

## 核心原则

**取证必须指向具体内容** — 不是页面概览截图，而是：
- 具体的函数签名/API 参数
- 具体的 import 语句/依赖声明
- 具体的配置文件条目
- 具体的代码行号

## 5 级证据层次

| 层级 | 类型 | 示例 | 强度 |
|------|------|------|------|
| L1 | 代码级 | 函数定义、类结构、import | 最强 |
| L2 | 结构级 | 模型可视化(Netron)、存储结构 | 强 |
| L3 | 行为级 | 网络抓包、API 调用日志、行为测试 | 中 |
| L4 | 统计级 | Token 分布、延迟统计、资源占用 | 弱 |
| L5 | 推断级 | 间接推理、类比论证 | 最弱，尽量避免 |

**每个 PP 至少需要一个 L3 及以上的证据。**

## 常见取证模式

| PP 类型 | 取证方法 | 截图目标 | 红框内容 |
|---------|---------|---------|---------|
| 算法创新 | 公开资料+行为测试 | GitHub 代码/论文 | 函数名/关键参数 |
| 数据结构 | 存储分析 | 文件目录结构 | 特征文件名/格式 |
| API 调用 | 网络抓包 | 抓包工具输出 | 调用次数/参数 |
| 库依赖 | 公开检查 | GitHub/PyPI 页面 | 版本号/许可证 |
| 数据流 | 协议分析 | Wireshark/mitmproxy | 数据包内容 |
| 性能特征 | 基准测试 | 性能对比图表 | 关键指标数值 |
| 协议实现 | 规范比对 | RFC/标准文档 | 协议字段定义 |

## 取证搜索工作流

1. **识别公开组件** — 列出 PP 涉及的公开技术组件（开源库、标准协议、公开 API）
2. **搜索证据源** — 在 GitHub/官方文档/PyPI/NPM 搜索每个组件
3. **截图取证** — 截取包含关键技术特征的页面
4. **红框标注** — 用 `scripts/annotate_screenshot.py` 标注具体内容
5. **记录 URL** — 保存截图来源 URL 用于证据页

## 截图获取方式

### 方式 A: 浏览器手动截图
最简单，适合大多数场景。

### 方式 B: Playwright 自动截图
适合需要滚动/交互的页面：
```python
# 使用 MCP Playwright 工具
browser_navigate(url="https://github.com/...")
browser_take_screenshot(filename="evidence/screenshots/xxx.png")
```

### 方式 C: 命令行截图
```bash
# 若有 chromium
chromium --headless --screenshot=output.png --window-size=1280,800 "URL"
```

## 红框标注

### CLI 方式
```bash
python scripts/annotate_screenshot.py input.png output.png "x1,y1,x2,y2" "x1,y1,x2,y2"
```

### JSON 配置方式（批量）
```json
[
  {
    "input": "evidence/screenshots/faiss_github.png",
    "output": "evidence/annotated/faiss_github.png",
    "boxes": [[120, 340, 680, 420], [120, 500, 500, 560]],
    "line_width": 4,
    "color": "red"
  }
]
```

```bash
python scripts/annotate_screenshot.py --config evidence/boxes.json
```

### 红框坐标确定

1. 用图片查看器打开截图，记录感兴趣区域的像素坐标
2. 坐标格式: `(x1, y1, x2, y2)` — 左上角到右下角
3. 每边预留 5-10px padding
4. **验证**: 用 `verify_all.py --evidence evidence/` 检查标注版本存在

## Layout F — 单截图取证页

左侧 (LF_POINTS): 取证步骤 + 判定标准
右侧 (LF_SCREEN): 截图 → URL → caption（链式定位）

```python
make_slide_evidence_img(prs, layout,
    title="取证 PP1: [名称]",
    points=[
        "[取证方法]: XX",
        "",
        "Step 1: [操作步骤]",
        ("详细说明", 1),
        "",
        "Step 2: [观察内容]",
        ("详细说明", 1),
        "",
        "[判定标准]: XXX",
    ],
    img_path="evidence/annotated/xxx.png",
    url_text="Source: https://...",
    caption="红框说明: ...")
```

## Layout F2 — 双截图取证页

用于对比两个来源（如标准文档 vs 竞争对手实现）：

```python
make_slide_evidence_2img(prs, layout,
    title="取证 PP2: [名称]",
    points=[...],
    img1_path="evidence/annotated/source1.png",
    img2_path="evidence/annotated/source2.png",
    url1="https://source1...",
    url2="https://source2...")
```

## 取证页排序

**取证页必须按 PP 编号排序**: PP1 → PP2 → PP3 → PP4

## 截图回退机制

优先使用 `evidence/annotated/` 目录下的标注版本。
如果标注版本不存在，回退到 `evidence/screenshots/` 下的原始版本。

## 检查清单

- [ ] 红框指向具体内容（函数名/参数/版本号），不是页面概览
- [ ] 取证步骤左侧要点与右侧截图红框交叉引用
- [ ] URL 可访问且与截图对应
- [ ] 截图分辨率足够（至少 800x400）
- [ ] 判定标准可操作（不是模糊描述）
- [ ] 标注坐标准确（红框包围目标内容）
- [ ] 取证页按 PP 编号排序
- [ ] 标题格式一致: "取证 PPX: [名称]"
