# Layout System — 8 种布局坐标常量与使用指南

> **CRITICAL**: 禁止用 Read 工具查看生成的配图！用 `scripts/verify_all.py` 纯文本验证。
> 加载图片到 LLM context 会导致 context 溢出。

## 模板参数

- **尺寸**: 13.34" x 7.50" (宽屏)
- **边距**: 0.8" (左右)
- **Footer 保留**: 0.8" (底部)
- **Caption 高度**: 0.35"
- **Caption 间距**: 0.1"

## SlideRegion 坐标系

所有布局使用 `SlideRegion(left, top, width, height)` 定义区域，单位为英寸。

```python
from build_template import SlideRegion, SW, SH, MARGIN
```

## 8 种布局

### Layout A — 封面/尾页 (居中标题)

封面由用户在 `build_ppt.py` 中手动构建（标题、副标题、日期）。
尾页使用 LG_TEXT 居中。

```python
LG_TEXT = SlideRegion(2.67, 2.5, 8.0, 3.0)
```

### Layout B — 目录 (全页文字)

```python
# 全页文字区域
SlideRegion(0.8, 1.3, 11.7, 5.5)
```

用 `add_points()` 填充，`font_size=Pt(18)` 或 `Pt(17)`。

### Layout C — 要点 (上) + 图 (下)

```python
LC_POINTS = SlideRegion(0.8, 1.3, 11.7, 1.6)
LC_IMAGE  = SlideRegion(1.5, 3.35, 10.3, 3.95)  # 动态计算
```

- 用途: 技术背景、现有技术问题、实施例
- **图片 valign="top"** — 顶部对齐，caption 动态跟随图片底部
- 占位版: `make_slide_points_below()`
- 实图版: `make_slide_points_below_img()`

### Layout D — 要点 (左) + 图 (右)

```python
LD_POINTS = SlideRegion(0.8, 1.3, 5.8, 5.5)
LD_IMAGE  = SlideRegion(7.0, 2.0, 5.5, 4.0)
```

- 用途: 创新点、部署方式、有益效果
- **图片 valign="center"** — 垂直居中
- 占位版: `make_slide_points_right()`
- 实图版: `make_slide_points_right_img()`

### Layout E* — 保护点 + 分割线 + 应用价值

```python
# 上半: 保护点列表
SlideRegion(0.8, 1.3, 11.7, 3.5)
# 分割线: y=5.0
# 应用价值标签: y=5.2
# 下半: 价值要点
SlideRegion(0.8, 5.7, 11.7, 1.5)
```

- 用途: 技术保护点总览页
- 函数: `make_slide_protection()`

### Layout F — 单截图取证页

```python
LF_POINTS = SlideRegion(0.8, 1.3, 5.5, 5.0)
LF_SCREEN = SlideRegion(6.6, 1.3, 6.0, 4.0)
LF_URL    = SlideRegion(6.6, 5.45, 6.0, 0.35)  # 动态: 截图下方
```

- 用途: 侵权取证页
- **链式定位**: 截图 → URL → caption，每个元素的 top 由上一个的 bottom 决定
- 占位版: `make_slide_evidence()`
- 实图版: `make_slide_evidence_img()`

### Layout F2 — 双截图取证页

```python
LF2_IMG1 = SlideRegion(6.6, 1.3, 6.0, 2.3)
LF2_URL1 = SlideRegion(6.6, 3.7, 6.0, 0.3)
LF2_IMG2 = SlideRegion(6.6, 3.9, 6.0, 2.3)  # 动态链式
LF2_URL2 = SlideRegion(6.6, 6.3, 6.0, 0.3)
```

- 用途: 需要对比两个来源的取证页
- 函数: `make_slide_evidence_2img()`

### Layout G — 尾页 (居中结束语)

```python
LG_TEXT = SlideRegion(2.67, 2.5, 8.0, 3.0)
```

- 华为模板自带尾页，通常只需移动到最后

### Layout H — 双栏对比

```python
LDUAL_LEFT  = SlideRegion(0.8, 1.3, 5.6, 5.5)
LDUAL_RIGHT = SlideRegion(6.8, 1.3, 5.7, 5.5)
```

- 用途: 外显特征页（每页 2 个 PP 并列对比）
- 带垂直分割线和 section label
- 函数: `make_slide_dual_column()`

## Helper 函数

| 函数 | 用途 | 返回 |
|------|------|------|
| `add_title(slide, text)` | 红色标题 | textbox |
| `add_points(slide, points, ...)` | 要点列表 | textbox |
| `add_image_placeholder(slide, ...)` | 虚线占位框 | shape |
| `add_real_image(slide, path, region)` | 实际图片（缺失回退占位框）| (l, t, w, h) |
| `add_url_box(slide, url, ...)` | URL 引用框 | textbox |
| `add_caption(slide, text, ...)` | 灰色斜体注释 | textbox |
| `add_divider(slide, ...)` | 水平分割线 | shape |
| `add_section_label(slide, text, ...)` | 彩色标签 | shape |
| `add_speaker_notes(slide, text)` | 演讲者备注 | None |

## `add_real_image()` 行为

```python
add_real_image(slide, img_path, region, valign="center")
```

- 图片存在: 按比例缩放至 region 内，水平居中，垂直按 valign
- **图片不存在: 自动回退到 `add_image_placeholder()`**，不会报错
- 返回 `(actual_left, actual_top, actual_w, actual_h)` — 用于 caption 链式定位

## 常见错误

| # | 错误 | 正确做法 |
|---|------|---------|
| 1 | Caption 与图片分离 | Caption top = image bottom + 0.1 |
| 2 | 图片超出区域 | 用 `add_real_image()` 自动缩放 |
| 3 | URL 与截图重叠 | URL top = image bottom + 0.1（链式定位）|
| 4 | 硬编码居中坐标 | `left = (SW - width) / 2` |
| 5 | 元素底部越界 | 预留 0.8" footer + 0.35" caption |
| 6 | Layout C 图片垂直居中 | Layout C 用 `valign="top"`，D 用 `"center"` |
