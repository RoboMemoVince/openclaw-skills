# Figure Generation — 配图生成指南

> **可选功能**: 有 Gemini API 则自动生成，无 API 则用户手动提供或使用占位框。

> **CRITICAL**: 禁止用 Read 工具查看生成的图片！用 `scripts/verify_all.py --figures dir/` 验证。

## 概述

使用 `scripts/generate_figure.py` 通过 Gemini API 生成技术配图。
支持 5 种风格预设和 5 种尺寸预设。

## Prompt 结构 (4 层)

```
Level 1 — 上下文: 图的用途和目标读者
Level 2 — 布局: 元素排列方式（流程/对比/层次/网络）
Level 3 — 区域细节: 每个元素的标签、连接、样式
Level 4 — 风格约束: 颜色、字体、元素数量限制
```

### 示例 Prompt

```
Draw a system architecture diagram for a patent defense slide.

Layout: Left-to-right flow with 3 main stages.
Stage 1: "Sensor Data" box (blue) → arrow →
Stage 2: "STM Processing" box (green) containing "Welford Statistics" →
Stage 3: "Knowledge Base" box (orange) containing "Global KB" and "Personal KB"

Below the main flow: dashed arrow from Stage 2 down to "Scene Boundary Detection" box,
then arrow to "KL Divergence Check" diamond, then arrow to Stage 3.

Style: Bold colors, large labels, flat design for slide projection.
Constraints: Maximum 8 boxes, labels ≤ 6 Chinese characters each.
```

## 图表类型模板

### 架构图 (Architecture)
```
Draw a system architecture with [N] layers/components.
[Component 1] connects to [Component 2] via [relationship].
Use [color scheme]. Label each component with [≤8 char name].
```

### 对比图 (Comparison)
```
Draw a side-by-side comparison: "[A]" vs "[B]".
Left: [A's flow/structure], labeled "[limitation]"
Right: [B's flow/structure], labeled "[improvement]"
Arrow between them labeled "[delta]".
```

### 流程图 (Flowchart)
```
Draw a flowchart: [Start] → [Step 1] → [Decision] → [Branch A] / [Branch B] → [End].
Use diamond for decisions, rounded rectangles for steps.
Color code: blue for input, green for process, orange for output.
```

### 时间线 (Timeline)
```
Draw a horizontal timeline with [N] milestones.
[Year 1]: "[Event 1]" — [Description]
[Year 2]: "[Event 2]" — [Description]
Highlight the last milestone as "Our Invention" in red.
```

### 网络/关系图 (Network)
```
Draw a network graph with [N] nodes.
Node "[A]" connects to "[B]" (weight: [X]).
Node "[A]" connects to "[C]" (weight: [Y]).
Highlight cluster around "[A]" with dashed circle.
```

### 映射图 (Mapping)
```
Draw a mapping from [Source items] to [Target items].
[Source 1] → [Target 1] (labeled "[relationship]")
[Source 2] → [Target 2]
Use arrows with different colors for different relationship types.
```

## PPT 配图约束

- **元素数量**: ≤ 12 个主要元素（box/circle/diamond）
- **标签长度**: ≤ 8 个中文字符（英文可略长）
- **颜色数量**: 3-5 种颜色（不含黑白灰）
- **布局方向**: 优先左→右 或 上→下
- **背景**: 白色或透明
- **分辨率**: 建议 1280x720 或 1600x900

## 批量生成

### 统一风格前缀

批量生成时，所有 prompt 共享一个风格前缀，确保全套配图风格一致：

```
All figures share this style: Bold colors (blue #1A73E8, green #34A853,
orange #FBBC04, red #EA4335), large sans-serif labels, flat design,
white background, suitable for slide projection at 1280x720.
```

### Manifest 文件格式

```json
[
  {"prompt": "Draw ...", "output": "figures/ppt/01_background.png", "style": "slide", "size": "landscape"},
  {"prompt": "Draw ...", "output": "figures/ppt/02_problems.png", "style": "slide", "size": "landscape"}
]
```

### 批量生成命令

```bash
python scripts/generate_figure.py --batch figures_manifest.json
```

## 质量门控

生成后必须验证（**不要用 Read 看图片**）：

```bash
# 单张检查
python scripts/generate_figure.py --check-only --output figures/ppt/01_background.png

# 批量检查
python scripts/verify_all.py --figures figures/ppt/
```

通过标准:
- 文件大小 > 50KB
- 分辨率 > 800x400
- 无生成错误

## 无 API 时的降级方案

如果没有 Gemini API:
1. `build_template.py` 中的 `add_real_image()` 会自动回退到占位框
2. 用户可以手动提供图片放到 `figures/ppt/` 目录
3. PPT 中会显示 `[Missing: filename.png]` 提示
4. 用户后续可用任何工具（draw.io、Keynote、PPT）手绘替换

## API 配置

环境变量（生成配图时必需）：
```bash
export IMAGE_API_KEY="your-api-key"
export IMAGE_API_BASE="https://api.openai.com/v1"    # 或其他兼容 OpenAI 格式的 API
export IMAGE_MODEL="gemini-3-pro-image-preview"       # 支持图片生成的模型
```
