# 专利答辩 PPT 制作 (Patent Defense PPT Builder)

## 概述

从零开始，通过结构化 interview 收集专利信息，构建华为风格的专利答辩 PPT。
自包含所有代码和模板，不依赖外部 skill。

## 触发条件

- "专利PPT"、"答辩PPT"、"patent defense PPT"
- "保护点"、"取证页"、"PP策略"
- "patent presentation"、"专利答辩"

## 快速开始

1. 将此仓库 clone 到本地
2. 告诉 LLM："帮我做专利答辩 PPT"
3. LLM 会给你信息收集模板 (`templates/patent_info_template.md`)，按提示填写
4. LLM 完成剩余工作（内容提炼、PP 策略、配图、取证、构建、验证）

---

## 6 阶段工作流

### 阶段 0: 信息收集 (Interview)

**输入**: 空的 `templates/patent_info_template.md`
**输出**: 填好的 `ppt_materials.md`
**参考**: `references/interview-guide.md`

流程:
1. 给用户 `templates/patent_info_template.md` 模板
2. 用户填写能填的部分，返回给 LLM
3. LLM 按优先级追问缺失/模糊信息:
   - P0 (必须): 创新点描述、PP-创新点对应
   - P1 (应有): 取证方法、商业价值数据
   - P2 (可选): 实施例、量化效果
4. 每次只问 1-2 个问题，不要一次问太多
5. 信息完整后生成 `ppt_materials.md`

### 阶段 1: 内容提炼

**输入**: `ppt_materials.md`
**输出**: 18 页内容大纲 + 配图描述列表
**参考**: `references/content-extraction.md`

将收集的信息映射到 18 页标准结构。每页确定:
- 标题、Layout 类型、要点内容、配图描述

### 阶段 2: PP 策略

**输入**: 内容大纲
**输出**: PP 编号/评分/取证顺序
**参考**: `references/pp-strategy.md`

核心原则: **PP 编号 = 创新点编号**，一一对应。

### 阶段 3: 配图生成（可选）

**输入**: 配图描述列表
**输出**: `figures/ppt/*.png`
**参考**: `references/figure-generation.md`
**脚本**: `scripts/generate_figure.py`

- 有 API → 用 `generate_figure.py` 批量生成
- 无 API → 用户手动提供图片，或跳过（自动使用占位框）
- **验证**: `python scripts/verify_all.py --figures figures/ppt/`

### 阶段 4: 取证页制作

**输入**: 取证信息 + 截图
**输出**: `evidence/annotated/*.png`
**参考**: `references/evidence-guide.md`
**脚本**: `scripts/annotate_screenshot.py`

- 用户提供截图 → `annotate_screenshot.py` 加红框
- 红框必须指向具体内容（函数名/参数/版本号），不是页面概览
- 回退机制: 无标注版 → 用原始截图

### 阶段 5: PPT 构建 + 验证

**输入**: 所有素材
**输出**: 最终 `.pptx`
**参考**: `references/layout-system.md`, `references/speaker-notes.md`
**脚本**: `scripts/build_template.py`, `scripts/verify_all.py`

流程:
1. LLM 编写 `build_ppt.py`（导入 `scripts/build_template.py` 中的布局函数）
2. `build_ppt.py` 导入 `scripts/build_template.py` 的函数构建 PPT
3. 运行 `python scripts/verify_all.py --pptx output.pptx --figures figures/ppt/`
4. 修复发现的问题，重新生成
5. 导出 PDF 供人工审查: `libreoffice --headless --convert-to pdf output.pptx`

---

## 18 页标准结构

| # | 页面 | Layout | 内容 |
|---|------|--------|------|
| 1 | 封面 | A | 专利名称 + 发明人 + 日期 |
| 2 | 目录 | B | 章节列表 |
| 3 | 技术背景 | C | 领域背景 + 演进时间线图 |
| 4 | 现有技术缺陷 | C | 痛点列表 + 缺陷映射图 |
| 5-8 | 创新点 ×N | D | 每个创新点 1 页: 要点 + 结构图 |
| 9 | 实施例 | C | 具体场景 + 流程图 |
| 10 | 部署方式 | D | 端云协同 / 部署架构 |
| 11 | 有益效果 | D | 问题→方案(PP)→效果 |
| 12 | 保护点+应用价值 | E* | PP 列表 + 商业价值 |
| 13-14 | 外显特征 ×2 | H | 每页 2 个 PP 并列对比 |
| 15-18 | 取证页 ×M | F/F2 | 按 PP 编号排序 |
| 19 | 尾页 | G | 谢谢 / Q&A |

页数可调整（通常 16-22 页）。创新点数决定 5-8 页数量，取证页按需增减。

## 8 种布局类型

| Layout | 结构 | 用途 | 函数 |
|--------|------|------|------|
| A | 居中标题 | 封面/尾页 | 手动构建 |
| B | 全页文字 | 目录 | `add_points()` |
| C | 要点(上)+图(下) | 背景、实施例 | `make_slide_points_below[_img]()` |
| D | 要点(左)+图(右) | 创新点、部署 | `make_slide_points_right[_img]()` |
| E* | 保护点+分割线+价值 | 保护点总览 | `make_slide_protection()` |
| F | 要点(左)+截图(右)+URL | 单截图取证 | `make_slide_evidence[_img]()` |
| F2 | 要点(左)+双截图(右) | 双截图取证 | `make_slide_evidence_2img()` |
| G | 居中结束语 | 尾页 | 模板自带 |
| H | 双栏对比 | 外显特征 | `make_slide_dual_column()` |

详见: `references/layout-system.md`

## 文件组织

用户项目中的推荐目录结构:

```
my-patent/
├── ppt_materials.md          # 阶段 0 输出
├── build_ppt.py              # 阶段 5 LLM 生成的构建脚本
├── output.pptx               # 最终 PPT
├── figures/
│   └── ppt/                  # 配图 PNG
│       ├── 01_background.png
│       ├── 02_problems.png
│       └── ...
└── evidence/
    ├── screenshots/           # 原始截图
    └── annotated/             # 红框标注版
```

## Context 安全规则

> 以下规则是强制性的，违反会导致 LLM context 溢出。

1. **禁止用 Read 工具批量查看图片** — 使用 `scripts/verify_all.py` 的纯文本输出
2. **每次最多 Read 1 张图片**，且仅在用户明确要求时
3. **配图验证、PPT 验证全部用 `verify_all.py`** — 它只输出文本（文件名、尺寸、KB），不加载图片内容
4. **截图标注用 `annotate_screenshot.py`** — 不需要看图片，只需知道坐标

## 关键教训（23 条）

### 布局与排版
1. Caption 必须动态跟随图片位置，用 `add_real_image()` 返回值定位
2. 配图 ≤12 元素，标签 ≤8 中文字，否则缩放后不可读
3. Layout C 用 `valign="top"`，Layout D 用 `valign="center"`
4. Layout F 链式定位：截图 → URL → caption
5. 封面居中计算：`left = (SW - width) / 2`
6. TOTAL_SLIDES 不要硬编码，构建完成后统一刷新

### PP 编号与一致性
7. PP 编号 = 创新点编号，一一对应
8. PP 变更时全部同步更新（有益效果、保护点、外显特征、取证、配图、备注）
9. 取证页按 PP 编号排序
10. 含 PP 编号的配图必须与 PP 策略同步

### 内容与证据
11. 取证截图红框必须指向具体内容（函数名/参数/版本号），不是页面概览
12. 先生成所有配图，再构建 PPT
13. 截图回退机制：优先 `annotated/`，缺失回退到 `screenshots/`

### 演讲者备注
14. 每页都加备注：封面 2-3 句开场白，内容页 3-5 句，取证页说明判定逻辑
15. 备注与要点互补：要点是关键词，备注是完整讲稿

### 商业价值
16. 保护点页必须有商业价值数据
17. 用具体市场数据，不说"市场规模巨大"
18. 点名竞争对手的空白

### Context 安全与工作流
19. **禁止用 Read 工具批量查看图片** — 用 `verify_all.py`
20. **不假设能访问用户代码** — 所有技术细节通过 interview 获取
21. **信息收集模板先行** — 先给模板让用户填，再追问补充
22. **API 可选降级** — 无图片 API 时用占位框 + 提示用户手动替换
23. **迭代验证** — 每次修改后重新运行 `verify_all.py` 确认
