# 专利答辩 PPT 自动构建工具

一个自包含的专利答辩 PPT 制作工具包，通过 LLM 驱动的 interview 收集信息，自动构建华为风格的答辩 PPT。

## 使用前提

- Python 3.x
- `python-pptx` (必需)
- `Pillow` (必需)
- `requests` (可选，用于 Gemini 配图生成 API)

```bash
pip install python-pptx Pillow requests
```

## 快速开始

### 1. Clone 仓库

```bash
git clone <repo-url> patent-ppt-skill
cd patent-ppt-skill
```

### 2. 填写信息模板

复制 `templates/patent_info_template.md` 到你的项目目录，填写你的专利信息。

### 3. 告诉 LLM

把 `SKILL.md` 的内容和你填好的模板一起发给 LLM:

```
请帮我制作专利答辩 PPT。信息模板如下: [粘贴你填好的模板]
```

LLM 会按 6 阶段工作流完成 PPT 制作。

## 目录结构

```
patent-ppt-skill/
├── SKILL.md                    # 主技能定义 (LLM 读这个)
├── README.md                   # 本文件
├── templates/
│   ├── patent_info_template.md # 信息收集模板 (用户填写)
│   └── template.pptx           # 华为 PPT 模板
├── references/
│   ├── interview-guide.md      # Interview 追问策略
│   ├── layout-system.md        # 8 种布局坐标系统
│   ├── pp-strategy.md          # PP 编号与评分
│   ├── evidence-guide.md       # 取证方法指南
│   ├── figure-generation.md    # 配图生成最佳实践
│   ├── speaker-notes.md        # 演讲者备注模板
│   └── content-extraction.md   # 内容提炼规则
├── scripts/
│   ├── build_template.py       # 核心布局引擎 (8 种布局 + 验证)
│   ├── generate_figure.py      # 配图生成 (可选 Gemini API)
│   ├── annotate_screenshot.py  # 截图红框标注
│   ├── verify_all.py           # 一站式纯文本验证
│   └── test_layouts.py         # 布局测试脚本
└── examples/                   # (使用时由 LLM 自动生成)
```

## 使用方式

### Claude Code

将 `SKILL.md` 注册为 skill，或直接在对话中引用:
```
请按照 SKILL.md 的流程帮我做专利答辩 PPT
```

### OpenClaw / Claude API / GLM API

将 `SKILL.md` 内容作为 system prompt 或上下文，然后正常对话。
LLM 会按照 SKILL.md 中定义的 6 阶段工作流引导你完成 PPT 制作。

### 命令行 (高级用户)

```bash
# 测试布局引擎
python scripts/test_layouts.py

# 生成配图 (需要 API)
python scripts/generate_figure.py --prompt "..." --output fig.png --style slide

# 标注截图
python scripts/annotate_screenshot.py input.png output.png "x1,y1,x2,y2"

# 验证 PPT
python scripts/verify_all.py --pptx output.pptx --figures figures/ppt/
```

## 配图生成 API 配置 (可选)

如果你有支持图片生成的 API（OpenAI 兼容格式），设置以下环境变量:

```bash
export IMAGE_API_KEY="your-api-key"
export IMAGE_API_BASE="https://api.openai.com/v1"          # 或其他兼容端点
export IMAGE_MODEL="gemini-3-pro-image-preview"             # 支持图片生成的模型
```

没有 API 也能用 — PPT 中会显示占位框，你可以手动替换为自己的图片。

## 示例

使用时 LLM 会根据你的信息自动生成 `build_ppt.py` 构建脚本。
你也可以参考 `scripts/test_layouts.py` 了解各 Layout 的用法。

## 工作流图

```
用户填写模板 → LLM追问补充 → 内容提炼 → PP策略
     ↓              ↓           ↓          ↓
ppt_materials.md → 18页大纲 → 配图生成 → 取证截图
                                ↓          ↓
                        build_ppt.py → 构建PPT → verify_all.py → 导出PDF
```
