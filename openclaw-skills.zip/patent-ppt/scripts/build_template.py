#!/usr/bin/env python3
"""
Patent Defense PPT Layout System

Self-contained layout engine for Huawei-style patent defense PPTs.
Provides 8 layout types (A-H), validation, and helper functions.

Layout Types:
  A. Cover/End page (centered title)
  B. Table of contents (full-page text)
  C. Points (top) + Image (bottom)
  D. Points (left) + Image (right)
  E*. Protection points + divider + Application value
  F. Evidence: points (left) + screenshot (right) + URL
  F2. Evidence: points (left) + 2 screenshots stacked (right)
  G. End slide (centered)
  H. Dual-column comparison (observable features)
"""

from dataclasses import dataclass
import math
import os
import re

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE


# === Color Palette ===
RED_TITLE  = RGBColor(0xCC, 0x00, 0x00)   # Title red
DARK_BLUE  = RGBColor(0x00, 0x33, 0x66)   # Emphasis
MID_BLUE   = RGBColor(0x1A, 0x73, 0xE8)   # Links/highlights
BLACK      = RGBColor(0x33, 0x33, 0x33)   # Body text
GRAY       = RGBColor(0x88, 0x88, 0x88)   # Captions/annotations
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xF0, 0xF0, 0xF0)   # Placeholder fill
BORDER_GRAY= RGBColor(0xCC, 0xCC, 0xCC)   # Placeholder border

# === Font Sizes ===
TITLE_SIZE = Pt(32)
BODY_SIZE  = Pt(16)
SUB_SIZE   = Pt(14)
CAP_SIZE   = Pt(12)
URL_SIZE   = Pt(11)

# Slide dimensions (from template: 13.34 x 7.50 inches)
SW = 13.34
SH = 7.50


# ============================================================
# SlideRegion — safe layout coordinate system
# ============================================================

@dataclass
class SlideRegion:
    left: float
    top: float
    width: float
    height: float

    @property
    def right(self):
        return self.left + self.width

    @property
    def bottom(self):
        return self.top + self.height

    def below(self, gap=0.3):
        """Return top coordinate for a region placed below this one with gap."""
        return self.bottom + gap

    def fits_image(self, img_w, img_h):
        """Check if image can fit in this region (after aspect-ratio scaling)."""
        aspect = img_w / img_h
        if aspect > self.width / self.height:
            return self.width / aspect <= self.height + 0.01
        else:
            return self.height * aspect <= self.width + 0.01


# Layout constants
MARGIN = 0.8
TITLE_REGION = SlideRegion(MARGIN, 0.4, SW - 2 * MARGIN, 0.7)

# Layout C: points above + image below
LC_POINTS = SlideRegion(MARGIN, 1.3, 11.7, 1.6)
LC_IMAGE = SlideRegion(1.5, LC_POINTS.below(0.15), 10.3, SH - LC_POINTS.below(0.15) - 1.2)

# Layout D: points left + image right
LD_POINTS = SlideRegion(MARGIN, 1.3, 5.8, 5.5)
LD_IMAGE = SlideRegion(7.0, 2.0, 5.5, 4.0)

# Layout F: evidence page (points left + screenshot right + URL below)
LF_POINTS = SlideRegion(MARGIN, 1.3, 5.5, 5.0)
LF_SCREEN = SlideRegion(6.6, 1.3, 6.0, 4.0)
LF_URL = SlideRegion(6.6, LF_SCREEN.below(0.15), 6.0, 0.35)

# Layout F2: evidence page with 2 screenshots stacked
LF2_IMG1 = SlideRegion(6.6, 1.3, 6.0, 2.3)
LF2_URL1 = SlideRegion(6.6, LF2_IMG1.below(0.1), 6.0, 0.3)
LF2_IMG2 = SlideRegion(6.6, LF2_IMG1.below(0.5), 6.0, 2.3)
LF2_URL2 = SlideRegion(6.6, LF2_IMG2.below(0.1), 6.0, 0.3)

# Layout G: End slide (centered)
LG_TEXT = SlideRegion(2.67, 2.5, 8.0, 3.0)

# Layout H: Dual-column comparison
LDUAL_LEFT  = SlideRegion(MARGIN, 1.3, 5.6, 5.5)
LDUAL_RIGHT = SlideRegion(6.8, 1.3, 5.7, 5.5)

# Convenience dict for reference
SLIDE_LAYOUTS = {
    'A': {'title': LG_TEXT},
    'B': {'points': SlideRegion(0.8, 1.3, 11.7, 5.5)},
    'C': {'points': LC_POINTS, 'image': LC_IMAGE},
    'D': {'points': LD_POINTS, 'image': LD_IMAGE},
    'E': {'points': SlideRegion(0.8, 1.3, 11.7, 3.5), 'value': SlideRegion(0.8, 5.7, 11.7, 1.5)},
    'F': {'points': LF_POINTS, 'screen': LF_SCREEN, 'url': LF_URL},
    'F2': {'img1': LF2_IMG1, 'url1': LF2_URL1, 'img2': LF2_IMG2, 'url2': LF2_URL2},
    'G': {'text': LG_TEXT},
    'H': {'left': LDUAL_LEFT, 'right': LDUAL_RIGHT},
}


# ============================================================
# Validation functions — 3-layer self-correction
# ============================================================

def estimate_text_lines(points, font_size_pt, box_width_inches):
    """Estimate how many lines a list of bullet points needs at given width."""
    chars_per_line = int(box_width_inches * 72 / font_size_pt * 1.8)
    total_lines = 0
    for point in points:
        text = point[0] if isinstance(point, tuple) else point
        total_lines += max(1, math.ceil(len(text) / chars_per_line)) if text else 1
    return total_lines


def validate_slide_content(points, font_size_pt, box_width_in, box_height_in):
    """Check if text content fits in the given box. Returns (ok, message)."""
    line_height = font_size_pt * 1.5 / 72
    max_lines = int(box_height_in / line_height)
    needed_lines = estimate_text_lines(points, font_size_pt, box_width_in)
    if needed_lines > max_lines:
        return False, f"Content needs {needed_lines} lines, box fits {max_lines}"
    return True, "OK"


def validate_figure_prompt(prompt_text):
    """Pre-generation check on figure prompt quality. Returns (pass, warnings)."""
    warnings = []
    labels = re.findall(r'["\u201c\u201d](.*?)["\u201c\u201d]', prompt_text)
    for label in labels:
        if len(label) > 8:
            warnings.append(f"Label too long: '{label}' ({len(label)} chars)")
    element_count = len(labels) + prompt_text.count('\u2192') + prompt_text.count('->')
    if element_count > 12:
        warnings.append(f"Too many elements: {element_count} > 12")
    sentence_markers = prompt_text.count('\u3002') + prompt_text.count('\uff0c')
    if sentence_markers > 5:
        warnings.append(f"Too much descriptive text ({sentence_markers} sentence markers)")
    return len(warnings) == 0, warnings


def check_slide_overlaps(slide, slide_w=SW, slide_h=SH):
    """Check all shapes on a slide for overlap and out-of-bounds issues."""
    issues = []
    shapes_info = []
    for shape in slide.shapes:
        left = shape.left / 914400
        top = shape.top / 914400
        w = shape.width / 914400
        h = shape.height / 914400
        shapes_info.append((shape.name, left, top, left + w, top + h))
        if left + w > slide_w + 0.1:
            issues.append(f"'{shape.name}' right overflow: {left+w:.2f} > {slide_w}")
        if top + h > slide_h + 0.1:
            issues.append(f"'{shape.name}' bottom overflow: {top+h:.2f} > {slide_h}")
    for i, (n1, l1, t1, r1, b1) in enumerate(shapes_info):
        for j, (n2, l2, t2, r2, b2) in enumerate(shapes_info):
            if i >= j:
                continue
            if l1 < r2 and r1 > l2 and t1 < b2 and b1 > t2:
                ow = min(r1, r2) - max(l1, l2)
                oh = min(b1, b2) - max(t1, t2)
                if ow > 0.2 and oh > 0.2:
                    issues.append(f"Overlap: '{n1}' and '{n2}' ({ow:.1f}x{oh:.1f}in)")
    return issues


def validate_ppt(pptx_path):
    """Full PPT quality validation — check every slide for overlaps/out-of-bounds."""
    prs = Presentation(pptx_path)
    all_issues = []
    for i, slide in enumerate(prs.slides):
        issues = check_slide_overlaps(slide)
        if issues:
            all_issues.append(f"Slide {i+1}: {issues}")
    if all_issues:
        for issue in all_issues:
            print(f"  {issue}")
        return all_issues
    else:
        print("All slides pass overlap/bounds check")
        return []


def verify_pp_consistency(pptx_path):
    """Extract all PP references and check consistency. Returns dict of PP -> slide list."""
    pp_refs = {}
    prs = Presentation(pptx_path)
    for i, slide in enumerate(prs.slides):
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = para.text.strip()
                    for m in re.finditer(r'PP\d+', text):
                        pp_refs.setdefault(m.group(), []).append(i + 1)
    return pp_refs


def verify_speaker_notes(pptx_path):
    """Check all slides have speaker notes. Returns list of (slide_num, has_notes, char_count)."""
    prs = Presentation(pptx_path)
    results = []
    for i, slide in enumerate(prs.slides):
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            results.append((i + 1, bool(notes), len(notes)))
        else:
            results.append((i + 1, False, 0))
    return results


# ============================================================
# Utility functions
# ============================================================

def get_content_layout(prs):
    """Find the '1_Chinese text page' layout in the template."""
    for master in prs.slide_masters:
        for layout in master.slide_layouts:
            if layout.name == '1_Chinese text page':
                return layout
    raise ValueError("Content layout '1_Chinese text page' not found")


def delete_slide(prs, index):
    """Delete a slide by index."""
    rId = prs.slides._sldIdLst[index].get(
        '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    prs.part.drop_rel(rId)
    del prs.slides._sldIdLst[index]


# ============================================================
# Helper functions — add content elements to slides
# ============================================================

def add_title(slide, text, left=0.8, top=0.4, width=11.7, height=0.7):
    """Add red title textbox."""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    run.font.size = TITLE_SIZE
    run.font.bold = True
    run.font.color.rgb = RED_TITLE
    return txBox


def add_points(slide, points, left, top, width, height, font_size=BODY_SIZE):
    """Add bullet points textbox. Each point is a string or (text, level) tuple."""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True

    for i, pt in enumerate(points):
        if isinstance(pt, tuple):
            text, level = pt
        else:
            text, level = pt, 0

        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()

        run = p.add_run()
        run.text = text
        run.font.size = font_size if level == 0 else SUB_SIZE
        run.font.color.rgb = BLACK if level == 0 else GRAY
        if level == 0 and text.startswith("["):
            run.font.bold = True
            run.font.color.rgb = DARK_BLUE
        p.space_after = Pt(6) if level == 0 else Pt(3)
        p.level = level

    return txBox


def add_image_placeholder(slide, left, top, width, height, label="[Image Area]", sublabel=""):
    """Add a dashed-border rectangle as image placeholder."""
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shape.fill.solid()
    shape.fill.fore_color.rgb = LIGHT_GRAY
    line = shape.line
    line.color.rgb = BORDER_GRAY
    line.dash_style = 2
    line.width = Pt(1.5)

    tf = shape.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = label
    run.font.size = SUB_SIZE
    run.font.color.rgb = GRAY
    run.font.bold = True

    if sublabel:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        run2 = p2.add_run()
        run2.text = sublabel
        run2.font.size = CAP_SIZE
        run2.font.color.rgb = GRAY

    return shape


def add_real_image(slide, img_path, region, valign="center"):
    """Place image within a SlideRegion, maintaining aspect ratio.
    If image file doesn't exist, falls back to add_image_placeholder().
    valign: "center" (default) or "top" (flush to top of region).
    Returns (actual_left, actual_top, actual_w, actual_h) in inches."""
    if not os.path.exists(img_path):
        add_image_placeholder(slide, region.left, region.top, region.width, region.height,
                              label=f"[Missing: {os.path.basename(img_path)}]")
        return region.left, region.top, region.width, region.height

    from PIL import Image
    img = Image.open(img_path)
    iw, ih = img.size
    aspect = iw / ih
    container_aspect = region.width / region.height

    if aspect > container_aspect:
        w_in = region.width
        h_in = region.width / aspect
    else:
        h_in = region.height
        w_in = region.height * aspect

    assert w_in <= region.width + 0.01, f"Width overflow: {w_in:.2f} > {region.width}"
    assert h_in <= region.height + 0.01, f"Height overflow: {h_in:.2f} > {region.height}"

    actual_left = region.left + (region.width - w_in) / 2
    if valign == "top":
        actual_top = region.top
    else:
        actual_top = region.top + (region.height - h_in) / 2

    slide.shapes.add_picture(img_path,
                              Inches(actual_left), Inches(actual_top),
                              Inches(w_in), Inches(h_in))
    return actual_left, actual_top, w_in, h_in


def verify_figure(img_path):
    """Post-generation basic quality check."""
    if not os.path.exists(img_path):
        return False, f"File not found: {img_path}"
    size = os.path.getsize(img_path)
    if size < 50 * 1024:
        return False, f"File too small ({size/1024:.0f}KB), generation may have failed"
    from PIL import Image
    img = Image.open(img_path)
    if img.size[0] < 800 or img.size[1] < 400:
        return False, f"Resolution too low ({img.size})"
    return True, "Basic check passed"


def add_url_box(slide, url_text, left, top, width):
    """Add a URL reference box."""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(0.35))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = url_text
    run.font.size = URL_SIZE
    run.font.color.rgb = MID_BLUE
    run.font.underline = True
    return txBox


def add_caption(slide, text, left, top, width):
    """Add a gray italic caption."""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(0.35))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    run.font.size = CAP_SIZE
    run.font.color.rgb = GRAY
    run.font.italic = True
    return txBox


def add_divider(slide, left, top, width):
    """Add a thin horizontal line."""
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(left), Inches(top), Inches(width), Pt(1.5))
    shape.fill.solid()
    shape.fill.fore_color.rgb = BORDER_GRAY
    shape.line.fill.background()
    return shape


def add_section_label(slide, text, left, top, width=2.5, height=0.35):
    """Add a colored section label (e.g., 'Application Value')."""
    shape = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shape.fill.solid()
    shape.fill.fore_color.rgb = RED_TITLE
    shape.line.fill.background()
    tf = shape.text_frame
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = SUB_SIZE
    run.font.bold = True
    run.font.color.rgb = WHITE
    return shape


def add_speaker_notes(slide, notes_text):
    """Add speaker notes to a slide."""
    notes_slide = slide.notes_slide
    tf = notes_slide.notes_text_frame
    tf.text = notes_text


# ============================================================
# Slide builder functions — 8 layout types
# ============================================================

def _clear_placeholders(slide):
    """Remove all placeholders from a slide."""
    for ph in list(slide.placeholders):
        sp = ph._element
        sp.getparent().remove(sp)


def _check_slide(slide, slide_name):
    """Run overlap/out-of-bounds check on a slide, print warnings."""
    issues = check_slide_overlaps(slide)
    if issues:
        print(f"  Warning {slide_name}: {issues}")
    return issues


def make_slide_points_below(prs, layout, title, points, fig_label, fig_sub="", caption=""):
    """Layout C: points (top) + image placeholder (bottom).
    Uses LC_POINTS and LC_IMAGE regions."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    r = LC_POINTS
    add_points(slide, points, left=r.left, top=r.top, width=r.width, height=r.height)
    r = LC_IMAGE
    add_image_placeholder(slide, left=r.left, top=r.top, width=r.width, height=r.height,
                         label=fig_label, sublabel=fig_sub)
    if caption:
        add_caption(slide, caption, left=MARGIN, top=SH - 0.35, width=SW - 2 * MARGIN)
    return slide


def make_slide_points_below_img(prs, layout, title, points, img_path, caption=""):
    """Layout C with actual image. Caption placed right below the image."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    add_points(slide, points,
               left=LC_POINTS.left, top=LC_POINTS.top,
               width=LC_POINTS.width, height=LC_POINTS.height)
    al, at, aw, ah = add_real_image(slide, img_path, LC_IMAGE, valign="top")
    if caption:
        cap_top = at + ah + 0.1
        add_caption(slide, caption, left=MARGIN, top=cap_top, width=SW - 2 * MARGIN)
    _check_slide(slide, title[:20])
    return slide


def make_slide_points_right(prs, layout, title, points, fig_label, fig_sub="", caption=""):
    """Layout D: points (left) + image placeholder (right).
    Uses LD_POINTS and LD_IMAGE regions."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    r = LD_POINTS
    add_points(slide, points, left=r.left, top=r.top, width=r.width, height=r.height)
    r = LD_IMAGE
    add_image_placeholder(slide, left=r.left, top=r.top, width=r.width, height=r.height,
                         label=fig_label, sublabel=fig_sub)
    if caption:
        add_caption(slide, caption, left=MARGIN, top=SH - 0.35, width=SW - 2 * MARGIN)
    return slide


def make_slide_points_right_img(prs, layout, title, points, img_path, caption=""):
    """Layout D with actual image. Caption placed right below the image."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    add_points(slide, points,
               left=LD_POINTS.left, top=LD_POINTS.top,
               width=LD_POINTS.width, height=LD_POINTS.height)
    al, at, aw, ah = add_real_image(slide, img_path, LD_IMAGE)
    if caption:
        cap_top = at + ah + 0.1
        add_caption(slide, caption, left=LD_IMAGE.left, top=cap_top, width=LD_IMAGE.width)
    _check_slide(slide, title[:20])
    return slide


def make_slide_protection(prs, layout, title, protection_points, value_points):
    """Layout E*: protection points + divider + application value."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    add_points(slide, protection_points, left=0.8, top=1.3, width=11.7, height=3.5)
    add_divider(slide, left=0.8, top=5.0, width=11.7)
    add_section_label(slide, "\u5e94\u7528\u4ef7\u503c", left=0.8, top=5.2)
    add_points(slide, value_points, left=0.8, top=5.7, width=11.7, height=1.5)
    return slide


def make_slide_evidence(prs, layout, title, points, screenshot_label, url_text, screenshot_sub=""):
    """Layout F: evidence page with placeholder — points + screenshot + URL.
    Uses LF_POINTS, LF_SCREEN, LF_URL regions."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    r = LF_POINTS
    add_points(slide, points, left=r.left, top=r.top, width=r.width, height=r.height)
    r = LF_SCREEN
    add_image_placeholder(slide, left=r.left, top=r.top, width=r.width, height=r.height,
                         label=screenshot_label, sublabel=screenshot_sub)
    r = LF_URL
    add_url_box(slide, url_text, left=r.left, top=r.top, width=r.width)
    return slide


def make_slide_evidence_img(prs, layout, title, points, img_path, url_text, caption=""):
    """Layout F with actual screenshot. URL placed right below image; caption below URL."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    add_points(slide, points,
               left=LF_POINTS.left, top=LF_POINTS.top,
               width=LF_POINTS.width, height=LF_POINTS.height)
    al, at, aw, ah = add_real_image(slide, img_path, LF_SCREEN)
    url_top = at + ah + 0.1
    add_url_box(slide, url_text, left=LF_SCREEN.left, top=url_top, width=LF_SCREEN.width)
    if caption:
        cap_top = url_top + 0.35 + 0.05
        add_caption(slide, caption, left=LF_SCREEN.left, top=cap_top, width=LF_SCREEN.width)
    _check_slide(slide, title[:20])
    return slide


def make_slide_evidence_2img(prs, layout, title, points, img1_path, img2_path, url1, url2):
    """Evidence page with 2 screenshots stacked. URL placed right below each image."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)
    add_points(slide, points,
               left=LF_POINTS.left, top=LF_POINTS.top,
               width=LF_POINTS.width, height=LF_POINTS.height)
    al1, at1, aw1, ah1 = add_real_image(slide, img1_path, LF2_IMG1)
    url1_top = at1 + ah1 + 0.05
    add_url_box(slide, url1, left=LF2_IMG1.left, top=url1_top, width=LF2_IMG1.width)
    img2_region = SlideRegion(
        LF2_IMG1.left, url1_top + 0.35 + 0.1,
        LF2_IMG1.width, SH - (url1_top + 0.35 + 0.1) - 0.7)
    al2, at2, aw2, ah2 = add_real_image(slide, img2_path, img2_region)
    url2_top = at2 + ah2 + 0.05
    add_url_box(slide, url2, left=LF2_IMG1.left, top=url2_top, width=LF2_IMG1.width)
    _check_slide(slide, title[:20])
    return slide


def make_slide_dual_column(prs, layout, title, left_header, left_points,
                           right_header, right_points, font_size=Pt(13)):
    """Layout H: dual-column text with vertical divider + section labels."""
    slide = prs.slides.add_slide(layout)
    _clear_placeholders(slide)
    add_title(slide, title)

    div_left = (LDUAL_LEFT.right + LDUAL_RIGHT.left) / 2
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(div_left), Inches(1.3), Pt(1.5), Inches(5.5))
    shape.fill.solid()
    shape.fill.fore_color.rgb = BORDER_GRAY
    shape.line.fill.background()

    add_section_label(slide, left_header,
                      left=LDUAL_LEFT.left, top=LDUAL_LEFT.top, width=3.5, height=0.35)
    add_points(slide, left_points,
               left=LDUAL_LEFT.left, top=LDUAL_LEFT.top + 0.5,
               width=LDUAL_LEFT.width, height=LDUAL_LEFT.height - 0.5,
               font_size=font_size)

    add_section_label(slide, right_header,
                      left=LDUAL_RIGHT.left, top=LDUAL_RIGHT.top, width=3.5, height=0.35)
    add_points(slide, right_points,
               left=LDUAL_RIGHT.left, top=LDUAL_RIGHT.top + 0.5,
               width=LDUAL_RIGHT.width, height=LDUAL_RIGHT.height - 0.5,
               font_size=font_size)

    _check_slide(slide, title[:20])
    return slide
