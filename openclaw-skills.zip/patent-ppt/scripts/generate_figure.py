#!/usr/bin/env python3
"""
Generate technical figures using Gemini image generation API.

Self-contained script — no external skill dependencies.

Usage:
    python generate_figure.py --prompt "description" --output fig1.png
    python generate_figure.py --prompt-file prompt.txt --output fig2.png
    python generate_figure.py --prompt-file prompt.txt --output fig.png --style slide
    python generate_figure.py --check-only --output fig.png
    python generate_figure.py --batch manifest.json

Environment (required for image generation):
    IMAGE_API_KEY   - API key for image generation service
    IMAGE_API_BASE  - API base URL (default: https://api.openai.com/v1)
    IMAGE_MODEL     - Model name (default: gemini-3-pro-image-preview)
"""

import argparse
import base64
import json
import os
import re
import sys
import time
from pathlib import Path

import requests


# --- Configuration ---
DEFAULT_API_BASE = os.environ.get("IMAGE_API_BASE", "https://api.openai.com/v1")
DEFAULT_API_KEY = ""  # Must be set via IMAGE_API_KEY environment variable
DEFAULT_MODEL = "gemini-3-pro-image-preview"
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds

# Style presets — appended to the user prompt to enforce visual consistency
STYLE_PRESETS = {
    "patent": (
        "Style: clean patent-style technical illustration. Black/gray lines on white, "
        "minimal color (use color only for emphasis). High contrast, suitable for "
        "monochrome printing. No decorative elements. Sans-serif labels."
    ),
    "paper": (
        "Style: academic paper figure. Clean vector-art look, professional color palette "
        "(blue, orange, green, gray). Clear labels with readable font size. White background. "
        "Suitable for two-column IEEE/ACM paper at 300 DPI."
    ),
    "slide": (
        "Style: presentation slide figure. Bold colors, large readable labels, "
        "high contrast suitable for projection. Slightly rounded corners on boxes. "
        "Modern flat design aesthetic."
    ),
    "poster": (
        "Style: academic poster figure. Very large labels, bold outlines, "
        "vibrant but professional colors. Must be readable from 1-2 meters away. "
        "Minimal text, maximum visual clarity."
    ),
    "minimal": (
        "Style: minimalist technical diagram. Thin lines, muted color palette, "
        "generous whitespace. Elegant and uncluttered. Suitable for a journal cover."
    ),
}

# Size hints — prepended to guide aspect ratio
SIZE_PRESETS = {
    "square": "Generate a square image (1:1 aspect ratio).",
    "landscape": "Generate a wide landscape image (16:9 aspect ratio).",
    "portrait": "Generate a tall portrait image (9:16 aspect ratio).",
    "wide": "Generate an extra-wide image (2:1 aspect ratio), suitable for full-width figures.",
    "column": "Generate a narrow image suitable for a single journal column (3:4 aspect ratio).",
}


def get_config():
    api_key = os.environ.get("IMAGE_API_KEY", DEFAULT_API_KEY)
    if not api_key:
        print("Error: IMAGE_API_KEY environment variable is required.", file=sys.stderr)
        print("  export IMAGE_API_KEY='your-api-key'", file=sys.stderr)
        sys.exit(1)
    return {
        "api_base": os.environ.get("IMAGE_API_BASE", DEFAULT_API_BASE),
        "api_key": api_key,
        "model": os.environ.get("IMAGE_MODEL", DEFAULT_MODEL),
    }


def extract_image_data(content: str) -> tuple:
    """Extract base64 image data from the API response content."""
    match = re.search(r'data:image/(\w+);base64,([A-Za-z0-9+/=]+)', content)
    if match:
        img_format = match.group(1)
        img_data = base64.b64decode(match.group(2))
        return img_data, img_format
    return None, None


def build_prompt(base_prompt: str, style: str = None, size: str = None) -> str:
    """Compose final prompt from base prompt + optional style/size presets."""
    parts = []
    if size and size in SIZE_PRESETS:
        parts.append(SIZE_PRESETS[size])
    parts.append(base_prompt)
    if style and style in STYLE_PRESETS:
        parts.append(STYLE_PRESETS[style])
    return "\n\n".join(parts)


def generate_image(prompt: str, config: dict) -> tuple:
    """Call the API and return (image_bytes, format_str)."""
    messages = [{"role": "user", "content": prompt}]

    payload = {
        "model": config["model"],
        "messages": messages,
        "max_tokens": 8192,
    }

    headers = {
        "Authorization": f"Bearer {config['api_key']}",
        "Content-Type": "application/json",
    }

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f"[attempt {attempt}/{MAX_RETRIES}] Calling {config['model']}...", flush=True)
            resp = requests.post(
                f"{config['api_base']}/chat/completions",
                headers=headers,
                json=payload,
                timeout=120,
            )

            if resp.status_code != 200:
                print(f"  HTTP {resp.status_code}: {resp.text[:500]}", file=sys.stderr)
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_DELAY)
                    continue
                resp.raise_for_status()

            data = resp.json()
            content = data["choices"][0]["message"]["content"]

            img_bytes, img_fmt = extract_image_data(content)
            if img_bytes:
                print(f"  Success! Got {len(img_bytes)} bytes ({img_fmt})", flush=True)
                return img_bytes, img_fmt

            print(f"  No image in response. Text content:\n{content[:500]}", file=sys.stderr)
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_DELAY)
                continue
            raise ValueError("API returned no image data")

        except requests.exceptions.Timeout:
            print(f"  Timeout on attempt {attempt}", file=sys.stderr)
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_DELAY)
                continue
            raise

    raise RuntimeError(f"Failed after {MAX_RETRIES} attempts")


def save_image(img_bytes: bytes, output_path: str, img_format: str):
    """Save image bytes to file, converting format if needed."""
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    target_ext = out.suffix.lower().lstrip(".")

    if target_ext in (img_format, "jpg", "jpeg") and img_format in ("jpeg", "jpg"):
        out.write_bytes(img_bytes)
    elif target_ext == img_format:
        out.write_bytes(img_bytes)
    else:
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(img_bytes))
            if target_ext == "pdf":
                img.save(str(out), "PDF", resolution=300)
            elif target_ext == "png":
                img.save(str(out), "PNG")
            else:
                img.save(str(out))
        except ImportError:
            fallback = out.with_suffix(f".{img_format}")
            fallback.write_bytes(img_bytes)
            print(f"  PIL not available. Saved as {fallback} instead.", file=sys.stderr)
            return str(fallback)

    print(f"  Saved: {out} ({out.stat().st_size} bytes)", flush=True)
    return str(out)


def check_image(output_path, min_size_kb=50, min_width=800, min_height=400):
    """Verify existing image quality without generating. Returns (ok, message)."""
    p = Path(output_path)
    if not p.exists():
        return False, f"File not found: {output_path}"
    size_kb = p.stat().st_size / 1024
    try:
        from PIL import Image
        with Image.open(p) as img:
            w, h = img.size
    except Exception as e:
        return False, f"Cannot open: {e}"
    issues = []
    if size_kb < min_size_kb:
        issues.append(f"{size_kb:.0f}KB < {min_size_kb}KB")
    if w < min_width:
        issues.append(f"width {w} < {min_width}")
    if h < min_height:
        issues.append(f"height {h} < {min_height}")
    if issues:
        return False, f"{p.name}: {size_kb:.0f}KB, {w}x{h} -- {', '.join(issues)}"
    return True, f"{p.name}: {size_kb:.0f}KB, {w}x{h}"


def main():
    parser = argparse.ArgumentParser(
        description="Generate technical figures via Gemini image generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"Available styles: {', '.join(STYLE_PRESETS.keys())}\n"
               f"Available sizes:  {', '.join(SIZE_PRESETS.keys())}",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--prompt", type=str, help="Image generation prompt text")
    group.add_argument("--prompt-file", type=str, help="Path to file containing the prompt")
    parser.add_argument("--output", "-o", help="Output file path (.png, .jpg, .pdf)")
    parser.add_argument("--style", type=str, choices=list(STYLE_PRESETS.keys()),
                        help="Visual style preset")
    parser.add_argument("--size", type=str, choices=list(SIZE_PRESETS.keys()),
                        help="Aspect ratio / size preset")
    parser.add_argument("--check-only", action="store_true",
                        help="Only verify existing image quality, do not generate")
    parser.add_argument("--batch", type=str,
                        help="Path to manifest JSON file for batch generation")
    args = parser.parse_args()

    # --check-only mode
    if args.check_only:
        if not args.output:
            print("Error: --check-only requires --output", file=sys.stderr)
            sys.exit(1)
        ok, msg = check_image(args.output)
        icon = "\u2713" if ok else "\u2717"
        print(f"{icon} {msg}")
        sys.exit(0 if ok else 1)

    # --batch mode
    if args.batch:
        manifest_path = Path(args.batch)
        if not manifest_path.exists():
            print(f"Error: manifest not found: {args.batch}", file=sys.stderr)
            sys.exit(1)
        with open(manifest_path) as f:
            items = json.load(f)
        config = get_config()
        success = 0
        for i, item in enumerate(items):
            print(f"\n=== [{i+1}/{len(items)}] {item.get('output', '?')} ===")
            prompt_text = item.get("prompt", "")
            if item.get("prompt_file"):
                prompt_text = Path(item["prompt_file"]).read_text(encoding="utf-8").strip()
            if not prompt_text:
                print("  Skipping: empty prompt")
                continue
            prompt = build_prompt(prompt_text,
                                  style=item.get("style"),
                                  size=item.get("size"))
            try:
                img_bytes, img_fmt = generate_image(prompt, config)
                save_image(img_bytes, item["output"], img_fmt)
                success += 1
            except Exception as e:
                print(f"  FAILED: {e}", file=sys.stderr)
        print(f"\nBatch complete: {success}/{len(items)} succeeded")
        sys.exit(0 if success == len(items) else 1)

    # Single image mode
    if not args.prompt and not args.prompt_file:
        parser.error("One of --prompt, --prompt-file, --check-only, or --batch is required")
    if not args.output:
        parser.error("--output is required for generation")

    if args.prompt_file:
        base_prompt = Path(args.prompt_file).read_text(encoding="utf-8").strip()
    else:
        base_prompt = args.prompt

    if not base_prompt:
        print("Error: empty prompt", file=sys.stderr)
        sys.exit(1)

    prompt = build_prompt(base_prompt, style=args.style, size=args.size)

    config = get_config()
    print(f"Model: {config['model']}")
    print(f"Output: {args.output}")
    if args.style:
        print(f"Style: {args.style}")
    if args.size:
        print(f"Size: {args.size}")
    print(f"Prompt length: {len(prompt)} chars")

    img_bytes, img_fmt = generate_image(prompt, config)
    saved_path = save_image(img_bytes, args.output, img_fmt)
    print(f"\nDone: {saved_path}")


if __name__ == "__main__":
    main()
