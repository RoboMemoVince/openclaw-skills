#!/usr/bin/env python3
"""Screenshot red-box annotation tool for patent evidence pages.

Usage:
    # Direct coordinates (x1,y1,x2,y2 per box):
    python annotate_screenshot.py input.png output.png "100,200,400,350" "500,100,700,250"

    # JSON config:
    python annotate_screenshot.py --config boxes.json

    # boxes.json format (single):
    # {"input": "input.png", "output": "output.png",
    #  "boxes": [[100,200,400,350], [500,100,700,250]],
    #  "line_width": 4, "color": "red"}

    # boxes.json format (batch):
    # [{"input": "a.png", "output": "a_ann.png", "boxes": [[10,10,100,100]]}, ...]
"""
import argparse
import json
import os
import sys
from PIL import Image, ImageDraw


def annotate_screenshot(input_path, output_path, boxes, line_width=4, color='red'):
    """Add red rectangular boxes to a screenshot.

    Args:
        input_path: Path to original screenshot
        output_path: Path to save annotated version
        boxes: List of (x1, y1, x2, y2) tuples
        line_width: Width of the box border
        color: Box border color (default: red)
    """
    img = Image.open(input_path)
    draw = ImageDraw.Draw(img)
    for box in boxes:
        x1, y1, x2, y2 = box
        for i in range(line_width):
            draw.rectangle([x1 - i, y1 - i, x2 + i, y2 + i], outline=color)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.save(output_path)
    w, h = img.size
    size_kb = os.path.getsize(output_path) // 1024
    print(f"\u2713 Annotated: {output_path} ({w}x{h}, {len(boxes)} boxes, {size_kb}KB)")
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Annotate screenshots with red boxes')
    parser.add_argument('input', nargs='?', help='Input image path')
    parser.add_argument('output', nargs='?', help='Output image path')
    parser.add_argument('boxes', nargs='*', help='Box coordinates as "x1,y1,x2,y2"')
    parser.add_argument('--config', type=str, help='JSON config file path')
    parser.add_argument('--line-width', type=int, default=4, help='Border line width')
    parser.add_argument('--color', type=str, default='red', help='Box color')
    args = parser.parse_args()

    if args.config:
        with open(args.config) as f:
            cfg = json.load(f)
        items = cfg if isinstance(cfg, list) else [cfg]
        for item in items:
            annotate_screenshot(
                item['input'], item['output'],
                [tuple(b) for b in item['boxes']],
                item.get('line_width', 4),
                item.get('color', 'red')
            )
    elif args.input and args.output and args.boxes:
        boxes = [tuple(int(x) for x in b.split(',')) for b in args.boxes]
        annotate_screenshot(args.input, args.output, boxes, args.line_width, args.color)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
