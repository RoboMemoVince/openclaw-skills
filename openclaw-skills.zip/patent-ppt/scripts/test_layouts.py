#!/usr/bin/env python3
"""Test all layout types generate without overlap errors."""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from build_template import *
from pptx import Presentation

TEMPLATE = os.path.join(os.path.dirname(__file__), '..', 'templates', 'template.pptx')
OUTPUT = '/tmp/test_layouts.pptx'


def main():
    prs = Presentation(TEMPLATE)
    layout = get_content_layout(prs)

    # Remove demo slides
    while len(prs.slides._sldIdLst) > 2:
        delete_slide(prs, 1)

    _tmp = OUTPUT + ".tmp"
    prs.save(_tmp)
    prs = Presentation(_tmp)
    layout = get_content_layout(prs)
    os.remove(_tmp)

    errors = []

    # Test Layout C (points below)
    print("Testing Layout C (points below)...")
    slide = make_slide_points_below(prs, layout, "Test Layout C",
        ["Point 1", "Point 2", "Point 3"], "Test figure placeholder")
    issues = check_slide_overlaps(slide)
    if issues:
        errors.extend([f"Layout C: {i}" for i in issues])

    # Test Layout D (points right)
    print("Testing Layout D (points right)...")
    slide = make_slide_points_right(prs, layout, "Test Layout D",
        ["Point 1", ("Sub point", 1), "Point 2"], "Test figure placeholder")
    issues = check_slide_overlaps(slide)
    if issues:
        errors.extend([f"Layout D: {i}" for i in issues])

    # Test Layout E* (protection)
    print("Testing Layout E* (protection)...")
    slide = make_slide_protection(prs, layout, "Test Layout E*",
        ["PP1: Test protection point (12/20)", "PP2: Test protection point (10/20)"],
        ["Market: $100B", "Barrier: High"])
    issues = check_slide_overlaps(slide)
    if issues:
        errors.extend([f"Layout E*: {i}" for i in issues])

    # Test Layout F (evidence)
    print("Testing Layout F (evidence)...")
    slide = make_slide_evidence(prs, layout, "Test Layout F",
        ["Evidence step 1", "Evidence step 2"],
        "Screenshot placeholder", "https://example.com")
    issues = check_slide_overlaps(slide)
    if issues:
        errors.extend([f"Layout F: {i}" for i in issues])

    # Test Layout H (dual column)
    print("Testing Layout H (dual column)...")
    slide = make_slide_dual_column(prs, layout, "Test Layout H",
        "Left Header", ["Left point 1", ("Left sub", 1)],
        "Right Header", ["Right point 1", ("Right sub", 1)])
    issues = check_slide_overlaps(slide)
    if issues:
        errors.extend([f"Layout H: {i}" for i in issues])

    # Test speaker notes
    print("Testing speaker notes...")
    add_speaker_notes(slide, "This is a test speaker note for verification.")

    prs.save(OUTPUT)

    # Final full validation
    print("\nRunning full PPT validation...")
    all_issues = validate_ppt(OUTPUT)

    if errors:
        print("\nERRORS FOUND:")
        for e in errors:
            print(f"  {e}")
        sys.exit(1)
    elif all_issues:
        print("\nPPT VALIDATION ISSUES:")
        for i in all_issues:
            print(f"  {i}")
        sys.exit(1)
    else:
        print("\nALL LAYOUTS PASS - no overlaps detected")
        print(f"Output: {OUTPUT}")
        print(f"Total slides: {len(prs.slides)}")


if __name__ == "__main__":
    main()
