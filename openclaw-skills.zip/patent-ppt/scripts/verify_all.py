#!/usr/bin/env python3
"""One-stop verification script -- all checks output plain text, NO image loading to context.

Usage:
    python verify_all.py --figures figures/ppt/ --pptx output.pptx --evidence evidence/

CRITICAL: This script exists because loading images with Read tool floods the LLM context.
All checks use PIL metadata only (dimensions, file size) -- never display image content.
"""
import argparse
import os
import sys
from pathlib import Path


def verify_figures(fig_dir, min_size_kb=50, min_width=800, min_height=400):
    """Verify all figure files: size >50KB, resolution >800x400."""
    results = []
    fig_path = Path(fig_dir)
    if not fig_path.exists():
        return [("ERROR", f"Directory not found: {fig_dir}")]

    from PIL import Image
    files = sorted(fig_path.glob('*.png')) + sorted(fig_path.glob('*.jpg')) + sorted(fig_path.glob('*.jpeg'))
    if not files:
        return [("WARN", f"No image files found in {fig_dir}")]

    for f in files:
        size_kb = f.stat().st_size / 1024
        try:
            with Image.open(f) as img:
                w, h = img.size
        except Exception as e:
            results.append(("FAIL", f"{f.name}: cannot open ({e})"))
            continue

        issues = []
        if size_kb < min_size_kb:
            issues.append(f"{size_kb:.0f}KB < {min_size_kb}KB")
        if w < min_width:
            issues.append(f"width {w} < {min_width}")
        if h < min_height:
            issues.append(f"height {h} < {min_height}")

        if issues:
            results.append(("FAIL", f"{f.name}: {size_kb:.0f}KB, {w}x{h} -- {', '.join(issues)}"))
        else:
            results.append(("PASS", f"{f.name}: {size_kb:.0f}KB, {w}x{h}"))

    return results


def verify_pptx(pptx_path):
    """Verify PPT: overlap detection + PP consistency + speaker notes."""
    import re
    results = []
    if not os.path.exists(pptx_path):
        return [("ERROR", f"File not found: {pptx_path}")]

    from pptx import Presentation
    prs = Presentation(pptx_path)
    total_slides = len(prs.slides)
    results.append(("INFO", f"Total slides: {total_slides}"))

    # 1. Overlap check
    try:
        sys.path.insert(0, os.path.dirname(__file__))
        from build_template import check_slide_overlaps
        for i, slide in enumerate(prs.slides):
            issues = check_slide_overlaps(slide)
            if issues:
                for issue in issues:
                    results.append(("WARN", f"Slide {i+1}: {issue}"))
            else:
                results.append(("PASS", f"Slide {i+1}: no overlaps"))
    except ImportError:
        results.append(("SKIP", "check_slide_overlaps not available"))

    # 2. PP consistency
    pp_refs = {}
    for i, slide in enumerate(prs.slides):
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = para.text.strip()
                    for m in re.finditer(r'PP\d+', text):
                        pp_refs.setdefault(m.group(), []).append(i + 1)

    if pp_refs:
        results.append(("INFO", f"PP references found: {', '.join(sorted(pp_refs.keys()))}"))
        for pp, slides in sorted(pp_refs.items()):
            results.append(("INFO", f"  {pp} appears on slides: {slides}"))
    else:
        results.append(("WARN", "No PP references found in any slide"))

    # 3. Speaker notes
    notes_count = 0
    empty_slides = []
    for i, slide in enumerate(prs.slides):
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                notes_count += 1
            else:
                empty_slides.append(i + 1)
        else:
            empty_slides.append(i + 1)

    results.append(("INFO", f"Speaker notes: {notes_count}/{total_slides} slides"))
    if empty_slides:
        results.append(("WARN", f"Missing notes on slides: {empty_slides}"))

    return results


def verify_evidence(evidence_dir):
    """Verify evidence screenshots exist and have annotated versions."""
    results = []
    ev_path = Path(evidence_dir)
    if not ev_path.exists():
        return [("SKIP", f"Evidence directory not found: {evidence_dir}")]

    ss_dir = ev_path / 'screenshots'
    ann_dir = ev_path / 'annotated'

    if not ss_dir.exists():
        results.append(("WARN", "screenshots/ subdirectory not found"))
        return results

    screenshots = sorted(ss_dir.glob('*.png')) + sorted(ss_dir.glob('*.jpg'))
    results.append(("INFO", f"Screenshots found: {len(screenshots)}"))

    for ss in sorted(screenshots):
        ann_file = ann_dir / ss.name if ann_dir.exists() else None
        if ann_file and ann_file.exists():
            results.append(("PASS", f"{ss.name}: annotated version exists"))
        else:
            results.append(("WARN", f"{ss.name}: no annotated version (will use raw)"))

    return results


def main():
    parser = argparse.ArgumentParser(
        description='Verify patent PPT assets (text output only, no image display)')
    parser.add_argument('--figures', type=str, help='Figures directory path')
    parser.add_argument('--pptx', type=str, help='PPTX file path')
    parser.add_argument('--evidence', type=str, help='Evidence directory path')
    args = parser.parse_args()

    if not args.figures and not args.pptx and not args.evidence:
        parser.print_help()
        sys.exit(1)

    all_pass = True
    icons = {"PASS": "\u2713", "FAIL": "\u2717", "ERROR": "!!", "INFO": "\u2139",
             "SKIP": "\u2298", "WARN": "\u26a0"}

    if args.figures:
        print("=== Figure Verification ===")
        for status, msg in verify_figures(args.figures):
            print(f"  {icons[status]} {msg}")
            if status == "FAIL":
                all_pass = False

    if args.pptx:
        print("\n=== PPTX Verification ===")
        for status, msg in verify_pptx(args.pptx):
            print(f"  {icons[status]} {msg}")
            if status in ("FAIL", "ERROR"):
                all_pass = False

    if args.evidence:
        print("\n=== Evidence Verification ===")
        for status, msg in verify_evidence(args.evidence):
            print(f"  {icons[status]} {msg}")
            if status == "FAIL":
                all_pass = False

    print("\n=== Summary ===")
    if all_pass:
        print("\u2713 ALL CHECKS PASSED")
    else:
        print("\u2717 SOME CHECKS FAILED -- see above for details")
        sys.exit(1)


if __name__ == '__main__':
    main()
