---
name: ascend-davinci-architecture
description: Use when working on any project involving Huawei Ascend NPU or DaVinci architecture. Triggers include any mention of Ascend, DaVinci, AICore, Cube core, Vector core, MTE, FixP, L0A/L0B/L0C/L1/UB buffers, or NPU operator development. Provides background knowledge on AICore structure, compute units, memory hierarchy, data transfer engines, hardware streams, and data flow patterns for both disaggregated and non-disaggregated architectures.
---

# Ascend DaVinci NPU Hardware Architecture

## Overview

The Ascend DaVinci architecture is Huawei's AI accelerator design. Each chip contains multiple **AICores**, each with independent Cube core, Vector core, Scalar unit, MTE (Memory Transfer Engine) units and FixP unit:

- **Cube core**: Matrix multiply accelerator, analogous to NVIDIA's Tensor Core
- **Vector core**: General-purpose vectorized computation, analogous to NVIDIA's CUDA Core
- **MTE units**: DMA engines for data movement between memory levels
- **FixP unit**: A special data path originating from Cube core's L0C output buffer, with some inline computation instructions (e.g. dequantize, type cast). FixP is the only way to move data out of L0C.

The architecture's key distinguishing feature is the **separated** Cube-Vector design: Cube and Vector cores have separate buffer hierarchies, requiring explicit data exchange through global memory (or direct on-chip paths in non-disaggregated architecture).

**IMPORTANT**: Specific numeric values (buffer sizes, bandwidths, clock frequencies, core counts) vary across chip generations. Always obtain these from chip config files or ask the user. This skill documents the **architecture and data flow patterns**, not chip-specific numbers.

## Data Flow Patterns and Architecture

### Disaggregated Architecture

Cube and Vector sides have **separate** buffer hierarchies. Data exchange must go through GM.

**Cube side data path:**
- GM -> L1 (via MTE2_Cube)
- L1 -> L0A (via MTE1_A, left operand)
- L1 -> L0B (via MTE1_B, right operand)
- L0A + L0B -> L0C (Cube core compute, 4-byte accumulate)
- L0C -> GM (via FixP, the only exit from L0C)

**Vector side data path:**
- GM -> UB (via MTE2_Vector)
- UB -> Register -> UB (Vector core compute)
- UB -> GM (via MTE3)

**Cube-Vector exchange (must transit GM):**
- Cube -> Vector: L0C --FixP--> GM --MTE2_Vector--> UB (2 sequential stream ops)
- Vector -> Cube: UB --MTE3--> GM --MTE2_Cube--> L1 --MTE1--> L0A/L0B (3 sequential stream ops)

**Rarely used paths:**
- L0C -> L1 (via FixP_L1)
- L1 -> GM (via Cube_MTE3)

### Non-Disaggregated Architecture

All paths above remain the same, plus direct on-chip exchange paths:
- **Cube -> Vector**: L0C --FixP_UB--> UB (bypasses GM, low latency)
- **Vector -> Cube**: UB --MTE3_L1--> L1 --MTE1--> L0A/L0B (bypasses GM, low latency)

These direct paths are the **defining feature** of non-disaggregated architecture. Whether a chip is disaggregated or not is a key architectural property — check chip config.

### About L2 Cache

L2 is a **shared cache** sitting between GM (HBM) and all AICores. It is transparent to the data paths above — when MTE2 reads from GM, data may be served from L2 if cached; when AICores write data out (via FixP or MTE3), the data is also written into L2. L2 uses an LRU-like eviction policy. It is not explicitly addressed; treat it as part of the GM access path with potentially higher bandwidth and lower latency on cache hits.

## Storage Hierarchy (Per AICore)

| Buffer | Role | Notes |
|--------|------|-------|
| **L0A** | Cube left matrix input | Feeds Cube core left operand |
| **L0B** | Cube right matrix input | Feeds Cube core right operand |
| **L0C** | Cube output accumulator | **Always 4 bytes per element** (fp32 or int32), regardless of input precision |
| **L1** | Cube-side unified buffer | Staging area between GM and L0A/L0B |
| **UB** | Vector-side unified buffer | Both input and output for Vector core |
| **Vector Register** | Vector compute register | Data in UB must be loaded into registers for computation. Whether registers are software-manageable depends on chip generation |
| **GM** | Global memory (HBM) | Shared across all AICores |
| **L2** | Shared cache | See "About L2 Cache" section above |

### Reference Buffer Sizes: Ascend 910B / A3 (DaVinci V220)

| Buffer | Size | Notes |
|--------|------|-------|
| **L0A** | 64 KB | Cube left input buffer |
| **L0B** | 64 KB | Cube right input buffer |
| **L0C** | 128 KB | Cube output accumulator (4 bytes/element) |
| **L1** | 512 KB | Cube-side unified buffer |
| **UB** | 192 KB | Vector-side unified buffer |

The 910B / A3 is a **disaggregated** architecture (no FixP_UB or MTE3_L1 direct paths).

**Key constraint**: Every tile must fit in the target buffer. Tiling parameters are bounded by buffer capacities (check chip config for exact sizes).

## Compute Units

### Cube Core (Matrix Multiply Accelerator)

Executes one MMA (Matrix Multiply-Accumulate) per cycle. Shape is M x N x K per cycle; ops/cycle = 2*M*N*K. Output accumulates in L0C (**4 bytes per element**, fp32 or int32).

MMA shapes and supported precisions vary by chip generation. Common input types include fp16, bf16, fp8, int8, int4, fp4, MXFP, HiFP, etc. Lower-precision types typically increase the K dimension for higher ops/cycle.

**Total Cube TFLOPS** = ops_per_cycle x num_cores x clock_MHz x 1e6 / 1e12

### Vector Core (Element-wise Operations)

Each Vector instruction has a fixed **throughput** (elements/cycle), which varies across chip generations and **depends on the data precision** (e.g. the same instruction may have different throughput for fp16 vs fp32). The throughput for each instruction and precision should be obtained from chip config.

**Cycle calculation example**: If `vadd` for fp32 has throughput `a` elements/cycle, and the Vector register size is `reg_size` elements, then processing `b` fp32 elements requires:

```
cycles = ceil(b / reg_size) * reg_size / a
```

The `ceil(b / reg_size) * reg_size` is because each invocation operates on a full register width, so the element count is rounded up to `reg_size` alignment.

## Hardware Streams (Per AICore)

All streams execute **in parallel** within one AICore. Each stream is strictly sequential internally.

### Common Streams (Both Architectures)

| Stream | Path | Shared? | Notes |
|--------|------|---------|-------|
| MTE2_Cube | GM -> L1 | **Yes** (read from GM) | |
| MTE1_A | L1 -> L0A | No | |
| MTE1_B | L1 -> L0B | No | |
| Cube | L0A+L0B -> L0C (compute) | No | |
| FixP | L0C -> GM | **Yes** (write to GM) | |
| FixP_L1 | L0C -> L1 | No | Rarely used |
| MTE2_Vector | GM -> UB | **Yes** (read from GM) | |
| Vector | UB -> Register -> UB (compute) | No | |
| MTE3 | UB -> GM | **Yes** (write to GM) | |
| Cube_MTE3 | L1 -> GM | **Yes** (write to GM) | Rarely used |

### Additional Streams (Non-Disaggregated Architecture Only)

| Stream | Path | Shared? | Notes |
|--------|------|---------|-------|
| FixP_UB | L0C -> UB | No | Direct Cube -> Vector exchange |
| MTE3_L1 | UB -> L1 | No | Direct Vector -> Cube exchange |

These direct paths are the **defining feature** of non-disaggregated architecture. They bypass GM entirely for Cube-Vector data exchange, dramatically reducing exchange latency. Whether a chip is disaggregated or non-disaggregated is a key architectural property — check chip config.

### Shared Bandwidth

**Read contention (MTE2):** MTE2_Cube and MTE2_Vector share a total read bandwidth pool from GM/L2, **fair-shared across all AICores**. Under contention: if N cores access MTE2 simultaneously, each gets pool/N.

**Write contention (FixP + MTE3 + Cube_MTE3):** FixP, MTE3, and Cube_MTE3 all write to GM/L2, sharing the L2 write bandwidth. This can cause contention when multiple write streams are active simultaneously.

## Operator Event Decomposition

When performing operator decomposition, performance analysis, or writing/reviewing NPU operator code, read **`references/operator-decomposition-examples.md`** for concrete examples of how operators (FlashAttention, GEMM, element-wise Vector ops) decompose into hardware stream events, including tiling constraints and transfer granularity notes.

## Pipeline Overlap

Independent streams can execute in parallel, allowing different events to **overlap** and hide each other's latency. For example, iteration N+1's MTE2 load can overlap with iteration N's Cube compute.

For operators that have both Cube stages and Vector stages (e.g. FlashAttention), the overlap between Cube and Vector stages is **critical** to performance — the Cube-Vector exchange overhead can be partially or fully hidden by overlapping with other stream operations.
