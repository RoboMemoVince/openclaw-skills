# Operator Event Decomposition Examples

The following examples show how operators decompose into hardware stream events. Refer to the main SKILL.md for stream definitions and data flow patterns.

## FlashAttention — Disaggregated (One Basic Block Iteration, Fused-Cube-Vector-Operator)

Cube-Vector exchange must transit GM (marked below). SingleM = Q block rows, SingleN = KV block rows within this basic block.

```
 1. MTE2_Cube:   Q_block  GM -> L1        (SingleM x Dk x elem_bytes)
 2. MTE2_Cube:   K_block  GM -> L1        (SingleN x Dk x elem_bytes)
 3. MTE1_A:      Q_block  L1 -> L0A
 4. MTE1_B:      K_block  L1 -> L0B
 5. Cube:        S = Q x K^T -> L0C       (SingleM x SingleN, 4-byte accumulate)
 6. FixP:        S  L0C -> GM             (Cube->Vector exchange, part 1)
 7. MTE2_Vector: S  GM -> UB              (Cube->Vector exchange, part 2)
 8. Vector:      P = onlinesoftmax(S) in UB
 9. MTE3:        P  UB -> GM              (Vector->Cube exchange, part 1)
10. MTE2_Cube:   P  GM -> L1              (Vector->Cube exchange, part 2)
11. MTE1:        P  L1 -> L0A
12. MTE2_Cube:   V_block  GM -> L1        (SingleN x Dv x elem_bytes)
13. MTE1_B:      V_block  L1 -> L0B
14. Cube:        O = P x V -> L0C         (SingleM x Dv output)
15. FixP:        O  L0C -> GM
16. MTE2_Vector: O  GM -> UB              (Cube->Vector exchange)
17. Vector:      Rescale O in UB
18. MTE3:        O  UB -> GM
```

## FlashAttention — Non-Disaggregated (One Basic Block Iteration)

Cube-Vector exchange uses direct on-chip paths (FixP_UB, MTE3_L1), bypassing GM.

```
 1. MTE2_Cube:   Q_block  GM -> L1        (SingleM x Dk x elem_bytes)
 2. MTE2_Cube:   K_block  GM -> L1        (SingleN x Dk x elem_bytes)
 3. MTE1_A:      Q_block  L1 -> L0A
 4. MTE1_B:      K_block  L1 -> L0B
 5. Cube:        S = Q x K^T -> L0C       (SingleM x SingleN, 4-byte accumulate)
 6. FixP_UB:     S  L0C -> UB             (direct Cube->Vector)
 7. Vector:      P = onlinesoftmax(S) in UB
 8. MTE3_L1:     P  UB -> L1              (direct Vector->Cube)
 9. MTE1:        P  L1 -> L0A
10. MTE2_Cube:   V_block  GM -> L1        (SingleN x Dv x elem_bytes)
11. MTE1_B:      V_block  L1 -> L0B
12. Cube:        O = P x V -> L0C         (SingleM x Dv output)
13. FixP_UB:     O  L0C -> UB             (direct Cube->Vector)
14. Vector:      Rescale O in UB
15. MTE3:        O  UB -> GM              (or reside in UB if not last loop)
```

## GEMM (One Basic Block Iteration, Cube Operator)

SingleM = left operand block rows, SingleN = right operand block rows, SingleK = reduction dimension block size (or shared dimension size), within this basic block.
```
1. MTE2_Cube:  A_tile  GM -> L1   (SingleM x SingleK x elem_bytes)
2. MTE2_Cube:  B_tile  GM -> L1   (SingleK x SingleN x elem_bytes)
3. MTE1_A:     A_tile  L1 -> L0A
4. MTE1_B:     B_tile  L1 -> L0B
5. Cube:       C = A x B -> L0C   (SingleM x SingleN, 4-byte accumulate)
6. FixP:       C  L0C -> GM
```

## Element-wise Vector Operation (e.g. Activation, One Basic Block Iteration, Vector Operator)

SingleM = block rows, SingleN = right columns within this basic block.
```
1. MTE2_Vector: X_block  GM -> UB         (SingleM x SingleN x elem_bytes)
2. Vector:      Y = f(X) in UB            (e.g. ReLU, GELU, etc.)
3. MTE3:        Y  UB -> GM
```

## Note on Transfer Granularity

The examples above show the **logical event flow** at basic-block (**stage**) granularity. In practice, a basic block may be too large to fit in the target buffer in one transfer. The actual per-transfer size is further constrained by buffer capacities — e.g., L1 may load in (BaseM x BaseK) chunks rather than the full (SingleM x SingleK) at once, and UB may load in (BaseM x BaseN) chunks. These inner subdivisions are called **phases**, and their sizing is operator-specific and determined by the phase configuration.

## Tiling Constraints

Every tile must fit in its target buffer. General pattern:
- L0A: baseM x baseK x elem_bytes <= L0A capacity
- L0B: baseN x baseK x elem_bytes <= L0B capacity
- L0C: output_rows x output_cols x 4 <= L0C capacity (4-byte accumulator)
- UB: depends on operator's vector workspace requirements
