#!/bin/bash
# =============================================================================
# OpenClaw 环境变量自动加载和配置展开
# 
# 在每次运行 openclaw 命令前自动:
# 1. 加载 .env 环境变量
# 2. 展开配置文件中的 ${VAR} 占位符
#
# 使用方式: 无需修改，直接运行 openclaw 命令即可
# =============================================================================

_openclaw_env_init() {
    local openclaw_dir="$HOME/.openclaw"
    local env_file="$openclaw_dir/.env"
    local expand_script="$openclaw_dir/scripts/openclaw-config-expand.sh"
    
    # 检查是否需要初始化
    if [ -z "$_OPENCLAW_ENV_LOADED" ]; then
        # 加载环境变量
        if [ -f "$env_file" ]; then
            set -a
            source "$env_file" 2>/dev/null
            set +a
        fi
        
        # 标记已加载
        export _OPENCLAW_ENV_LOADED=1
    fi
    
    # 展开配置文件 (如果需要)
    if [ -f "$expand_script" ] && [ -f "$openclaw_dir/openclaw.json" ]; then
        # 检查配置文件是否包含 ${VAR} 格式的占位符
        if grep -q '\$\{[A-Za-z_][A-Za-z0-9_]*\}' "$openclaw_dir/openclaw.json" 2>/dev/null; then
            bash "$expand_script" > /dev/null 2>&1
        fi
    fi
}

# 在运行任何 openclaw 命令前自动初始化
openclaw() {
    _openclaw_env_init
    command openclaw "$@"
}

# 初始化当前 shell 的环境
_openclaw_env_init
