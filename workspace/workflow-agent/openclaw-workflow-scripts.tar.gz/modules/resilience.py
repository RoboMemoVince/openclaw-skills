"""
Resilience infrastructure -- circuit breakers and dead-letter queue.

  CircuitBreaker         -- three-state breaker with active health probing
  CircuitBreakerRegistry -- per-service fault isolation
  DeadLetterQueue        -- JSONL-backed queue for permanently failed tasks
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("openclaw.resilience")


class BreakerState(Enum):
    """
    @description 断路器三态模型。
    """

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """
    Three-state circuit breaker with optional active health probing.

    CLOSED    -> normal, count failures
    OPEN      -> reject all calls immediately
    HALF_OPEN -> allow one probe call; success -> CLOSED, failure -> OPEN

    @param failure_threshold  Consecutive failures before opening.
    @param recovery_timeout   Seconds before passive OPEN -> HALF_OPEN.
    @param probe_interval     Seconds between active health probes.
    @param health_probe       Optional async callable returning True if healthy.
    @param on_state_change    Optional async callback(service, old_state, new_state).
    """

    CLOSED = BreakerState.CLOSED.value
    OPEN = BreakerState.OPEN.value
    HALF_OPEN = BreakerState.HALF_OPEN.value

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60,
        probe_interval: float = 15,
        health_probe: Optional[Callable] = None,
        on_state_change: Optional[Callable] = None,
    ):
        self.state: str = self.CLOSED
        self.failure_count: int = 0
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self._probe_interval = probe_interval
        self._health_probe = health_probe
        self._on_state_change = on_state_change
        self._last_failure_time: float = 0
        self._probe_task: Optional[asyncio.Task] = None
        self._service_name: str = ""

    def allow_request(self) -> bool:
        """Check whether a call should proceed."""
        if self.state == self.CLOSED:
            return True
        if self.state == self.OPEN:
            if time.monotonic() - self._last_failure_time >= self.recovery_timeout:
                self._transition(self.HALF_OPEN)
                return True
            return False
        return True

    def record_success(self) -> None:
        old = self.state
        self.failure_count = 0
        self.state = self.CLOSED
        self._stop_probe()
        if old != self.CLOSED:
            self._fire_state_change(old, self.CLOSED)

    def record_failure(self) -> None:
        self.failure_count += 1
        self._last_failure_time = time.monotonic()
        if self.failure_count >= self.failure_threshold:
            old = self.state
            self.state = self.OPEN
            self._start_probe()
            if old != self.OPEN:
                self._fire_state_change(old, self.OPEN)

    def _transition(self, new_state: str) -> None:
        old = self.state
        self.state = new_state
        if old != new_state:
            self._fire_state_change(old, new_state)

    def _fire_state_change(self, old: str, new: str) -> None:
        if self._on_state_change:
            try:
                asyncio.get_event_loop().call_soon(
                    lambda: asyncio.ensure_future(
                        self._on_state_change(self._service_name, old, new)
                    )
                )
            except RuntimeError:
                pass

    def _start_probe(self) -> None:
        """Launch background health probe when a probe function is available."""
        if not self._health_probe:
            return
        if self._probe_task and not self._probe_task.done():
            return
        try:
            self._probe_task = asyncio.ensure_future(self._probe_loop())
        except RuntimeError:
            pass

    def _stop_probe(self) -> None:
        if self._probe_task and not self._probe_task.done():
            self._probe_task.cancel()
            self._probe_task = None

    async def _probe_loop(self) -> None:
        """Periodically probe downstream service health while OPEN."""
        while self.state == self.OPEN:
            await asyncio.sleep(self._probe_interval)
            if self.state != self.OPEN:
                break
            try:
                healthy = await asyncio.wait_for(
                    self._health_probe(), timeout=10,
                )
                if healthy:
                    self._transition(self.HALF_OPEN)
                    logger.info("Health probe succeeded for %s, entering HALF_OPEN",
                                self._service_name)
                    break
            except (asyncio.TimeoutError, Exception) as e:
                logger.debug("Health probe failed for %s: %s", self._service_name, e)


class CircuitBreakerRegistry:
    """
    Per-service fault isolation with optional health probes.

    @method get            Retrieve (or auto-create) the breaker for a service.
    @method register_probe Register a health probe for a service.
    @method summary        Snapshot of all breaker states.
    """

    def __init__(self, on_state_change: Optional[Callable] = None, **kwargs: Any):
        self._breakers: Dict[str, CircuitBreaker] = {}
        self._probes: Dict[str, Callable] = {}
        self._defaults = kwargs
        self._on_state_change = on_state_change

    def get(self, service: str) -> CircuitBreaker:
        """Return the breaker for *service*, creating one if needed."""
        if service not in self._breakers:
            cb = CircuitBreaker(
                health_probe=self._probes.get(service),
                on_state_change=self._on_state_change,
                **self._defaults,
            )
            cb._service_name = service
            self._breakers[service] = cb
        return self._breakers[service]

    def register_probe(self, service: str, probe: Callable) -> None:
        """
        Register an async health-check function for a service.

        @param {str} service      - service name matching ``get()`` key
        @param {callable} probe   - async function returning True if healthy
        """
        self._probes[service] = probe
        if service in self._breakers:
            self._breakers[service]._health_probe = probe

    def record_failure(self, service: str) -> None:
        """
        @description 记录服务失败。
        @param {str} service
        @returns {None}
        """

        self.get(service).record_failure()

    def record_success(self, service: str) -> None:
        """
        @description 记录服务成功。
        @param {str} service
        @returns {None}
        """

        self.get(service).record_success()

    def check_recovery(self, service: str) -> BreakerState:
        """
        @description 触发一次恢复检查并返回当前状态。
        @param {str} service
        @returns {BreakerState}
        """

        breaker = self.get(service)
        breaker.allow_request()
        return BreakerState(breaker.state)

    def summary(self) -> Dict[str, str]:
        """Return ``{service: state}`` for all known breakers."""
        return {k: v.state for k, v in self._breakers.items()}

    def reader(self) -> "BreakerStateReader":
        """
        @description 创建只读断路器视图给 Scheduler 使用。
        @returns {BreakerStateReader}
        """

        return BreakerStateReader(self)


class BreakerStateReader:
    """
    @description Scheduler 使用的只读接口。
    """

    def __init__(self, registry: CircuitBreakerRegistry):
        self._registry = registry

    def is_open(self, service: str) -> bool:
        """
        @description 判断指定服务是否处于 OPEN（同时触发恢复检查）。
        @param {str} service
        @returns {bool}
        """

        breaker = self._registry.get(service)
        breaker.allow_request()
        return BreakerState(breaker.state) == BreakerState.OPEN

    def state(self, service: str) -> BreakerState:
        """
        @description 返回指定服务断路器状态（触发恢复检查）。
        @param {str} service
        @returns {BreakerState}
        """

        breaker = self._registry.get(service)
        breaker.allow_request()
        return BreakerState(breaker.state)


class DeadLetterQueue:
    """
    JSONL-backed queue for permanently failed tasks with consume/alert support.

    @param path             File path for the JSONL store.
    @param max_age_hours    Entries older than this trigger an alert on scan.
    @param alert_callback   Async callback invoked with a summary string.
    """

    def __init__(
        self,
        path: Path,
        max_age_hours: float = 24,
        alert_callback: Optional[Callable] = None,
    ):
        self._path = path
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._max_age_hours = max_age_hours
        self._alert_callback = alert_callback
        self._consumed_path = path.with_suffix(".consumed.jsonl")

    async def enqueue(
        self,
        task_id: str,
        step_name: str,
        error: str,
        context_snapshot: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Append a failed-task entry."""
        entry = {
            "task_id": task_id,
            "step_name": step_name,
            "error": error[:500],
            "context": {k: str(v)[:200] for k, v in (context_snapshot or {}).items()},
            "timestamp": datetime.now().isoformat(),
            "status": "pending",
        }
        try:
            with open(self._path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            logger.warning("DLQ write failed for task %s", task_id)

    async def list_pending(self, limit: int = 50) -> List[dict]:
        """Read the most recent *limit* entries."""
        if not self._path.exists():
            return []
        lines = self._path.read_text(encoding="utf-8").strip().splitlines()
        entries: List[dict] = []
        for line in lines[-limit:]:
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return entries

    async def consume(self) -> List[dict]:
        """
        Atomically move all pending entries to the consumed file and return them.

        @returns {list[dict]} entries that were consumed
        """
        if not self._path.exists():
            return []
        try:
            raw = self._path.read_text(encoding="utf-8").strip()
            if not raw:
                return []
            entries: List[dict] = []
            for line in raw.splitlines():
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
            with open(self._consumed_path, "a", encoding="utf-8") as f:
                for entry in entries:
                    entry["consumed_at"] = datetime.now().isoformat()
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            self._path.write_text("", encoding="utf-8")
            return entries
        except Exception:
            logger.warning("DLQ consume failed")
            return []

    async def scan_and_alert(self) -> int:
        """
        Scan for stale entries and fire the alert callback if any exist.

        @returns {int} number of stale entries found
        """
        entries = await self.list_pending()
        if not entries:
            return 0

        now = datetime.now()
        stale = []
        for entry in entries:
            try:
                ts = datetime.fromisoformat(entry.get("timestamp", ""))
                age_hours = (now - ts).total_seconds() / 3600
                if age_hours > self._max_age_hours:
                    stale.append(entry)
            except (ValueError, TypeError):
                stale.append(entry)

        total_pending = len(entries)
        if (stale or total_pending > 0) and self._alert_callback:
            summary = (
                f"DLQ 告警: {total_pending} 条待处理, {len(stale)} 条超过 "
                f"{self._max_age_hours}h 未消费"
            )
            try:
                await self._alert_callback(summary)
            except Exception:
                logger.warning("DLQ alert callback failed")

        return len(stale)

    async def consume_and_classify(self) -> Dict[str, List[dict]]:
        """
        Consume all pending entries, classify them as retryable or escalate.

        Retryable: TRANSIENT errors younger than ``_max_age_hours``.
        Escalate:  PERMANENT errors or entries older than ``_max_age_hours``.

        @returns {dict} with keys ``retryable`` and ``escalate``
        """
        entries = await self.consume()
        if not entries:
            return {"retryable": [], "escalate": []}

        now = datetime.now()
        retryable: List[dict] = []
        escalate: List[dict] = []

        for entry in entries:
            error_lower = entry.get("error", "").lower()
            is_permanent = any(kw in error_lower for kw in (
                "permanent", "authentication", "permission", "401", "403",
            ))
            try:
                ts = datetime.fromisoformat(entry.get("timestamp", ""))
                age_hours = (now - ts).total_seconds() / 3600
            except (ValueError, TypeError):
                age_hours = self._max_age_hours + 1

            if is_permanent or age_hours > self._max_age_hours:
                entry["escalation_reason"] = (
                    "permanent_error" if is_permanent
                    else f"stale ({age_hours:.1f}h)"
                )
                escalate.append(entry)
            else:
                retryable.append(entry)

        return {"retryable": retryable, "escalate": escalate}

    def start_periodic_scan(
        self,
        interval_seconds: float = 300,
        auto_consume: bool = False,
        consume_callback: Optional[Callable] = None,
    ) -> Optional[asyncio.Task]:
        """
        Launch a background task that periodically scans for stale DLQ entries.

        When *auto_consume* is True, each scan also calls
        ``consume_and_classify()`` and forwards the classified entries to
        *consume_callback* (if provided) so the caller can trigger retries
        and escalations.

        @param {float} interval_seconds - seconds between scans (default 5 min)
        @param {bool} auto_consume      - also consume and classify entries each cycle
        @param {callable|None} consume_callback - async fn(classified: dict) called after consume
        @returns {asyncio.Task|None} the background task, or None on failure
        """
        async def _loop() -> None:
            while True:
                await asyncio.sleep(interval_seconds)
                try:
                    stale_count = await self.scan_and_alert()
                    if stale_count:
                        logger.info("DLQ periodic scan: %d stale entries", stale_count)

                    if auto_consume:
                        classified = await self.consume_and_classify()
                        total = len(classified.get("retryable", [])) + len(classified.get("escalate", []))
                        if total and consume_callback:
                            await consume_callback(classified)
                        elif total:
                            logger.info(
                                "DLQ auto-consume: %d retryable, %d escalate (no callback)",
                                len(classified.get("retryable", [])),
                                len(classified.get("escalate", [])),
                            )
                except Exception:
                    logger.exception("DLQ periodic scan error")

        try:
            task = asyncio.ensure_future(_loop())
            logger.info(
                "DLQ periodic scan started (interval=%ds, auto_consume=%s)",
                interval_seconds, auto_consume,
            )
            return task
        except RuntimeError:
            logger.warning("Cannot start DLQ periodic scan: no event loop")
            return None
