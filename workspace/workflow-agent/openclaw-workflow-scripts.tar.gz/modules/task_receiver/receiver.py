"""
TaskReceiver -- normalises raw inputs into TaskRequest.
Handles /miniagent, /help, /status slash commands.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Any, Optional, Tuple

from modules.base import ModuleBase
from modules.data_types import TaskRequest

_USER_HOME = str(Path.home())

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

_COMMANDS = {"/miniagent", "/status", "/help"}


class TaskReceiver(ModuleBase):

    @property
    def name(self) -> str:
        return "task_receiver"

    @property
    def version(self) -> str:
        return "1.0"

    async def initialize(self, registry: ModuleRegistry) -> None:
        pass

    async def receive(self, raw: Dict[str, Any]) -> TaskRequest:
        """
        @param {dict} raw - at minimum {"content": str}; may also contain
            user_id, source, workspace, timeout, message_id, chat_id.
        @returns {TaskRequest}
        """
        content = (raw.get("content") or "").strip()
        command, task_body = self._parse_command(content)

        return TaskRequest(
            task_id=raw.get("message_id") or f"task_{uuid.uuid4().hex[:12]}",
            content=task_body,
            user_id=raw.get("user_id", ""),
            source=raw.get("source", "api"),
            command=command,
            workspace=raw.get("workspace", _USER_HOME),
            timeout=int(raw.get("timeout", 600)),
            metadata={
                k: v for k, v in raw.items()
                if k not in ("content", "user_id", "source", "workspace",
                             "timeout", "message_id")
            },
            created_at=datetime.now().isoformat(),
        )

    @staticmethod
    def _parse_command(content: str) -> Tuple[str, str]:
        """
        Split "/command args..." into (command, args).
        Returns ("", content) for non-command messages.
        """
        if not content.startswith("/"):
            return "", content

        parts = content.split(None, 1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        if cmd in _COMMANDS:
            return cmd, args
        return "", content
