"""
Workflow runtime exceptions shared by controller and DSL runtime.
"""

from __future__ import annotations


class WorkflowCancelled(Exception):
    """
    @description 工作流被取消时抛出的异常。
    """

    def __init__(self, step_name: str = ""):
        self.step_name = step_name
        message = f"Workflow cancelled: {step_name}" if step_name else "Workflow cancelled"
        super().__init__(message)


class WorkflowAborted(Exception):
    """
    @description 工作流主动中止时抛出的异常。
    """

    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class HookAborted(Exception):
    """
    @description 必需钩子失败且最终选择 abort。
    """

    def __init__(self, hook_name: str, message: str = ""):
        self.hook_name = hook_name
        super().__init__(f"Hook aborted: {hook_name}: {message}")


class HookReclassify(Exception):
    """
    @description 必需钩子失败且最终选择重新分类。
    """

    def __init__(self, hook_name: str):
        self.hook_name = hook_name
        super().__init__(f"Hook reclassify: {hook_name}")


class ServiceUnavailable(Exception):
    """
    @description 下游服务不可用。
    """


class NoWorkerAvailable(Exception):
    """
    @description 没有满足条件的可用 Worker。
    """


class QueueFull(Exception):
    """
    @description 调度队列达到背压阈值。
    """
