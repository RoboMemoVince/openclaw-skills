"""
Step middleware chain for the workflow runtime.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, List

from modules.data_types import ErrorCategory, StepResult, TaskStep
from modules.dsl.errors import WorkflowAborted, WorkflowCancelled


class StepMiddleware:
    """
    @description 步骤执行中间件接口。
    """

    async def process(self, step: TaskStep, ctx: Any, next_fn: Callable) -> StepResult:
        return await next_fn(step)


class CancellationMiddleware(StepMiddleware):
    """
    @description 每步执行前检查取消标记。
    """

    async def process(self, step: TaskStep, ctx: Any, next_fn: Callable) -> StepResult:
        if ctx.is_cancelled:
            raise WorkflowCancelled(step.name)
        return await next_fn(step)


class EventMiddleware(StepMiddleware):
    """
    @description 步骤事件通知，覆盖执行成功、失败和取消路径。
    """

    def __init__(self, event_bus: Any):
        self._bus = event_bus

    async def process(self, step: TaskStep, ctx: Any, next_fn: Callable) -> StepResult:
        event_name = None
        event_data = {
            "task_id": ctx.envelope.task_id,
            "step_name": step.name,
            "service": "agent_runner",
            "channel": ctx.envelope.channel,
        }
        try:
            result = await next_fn(step)
            event_name = "step_completed" if result.success else "step_failed"
            event_data["success"] = result.success
            event_data["cached"] = result.cached
            event_data["error"] = result.error
            event_data["error_category"] = result.error_category.value if result.error_category else ""
            return result
        except WorkflowCancelled:
            event_name = "step_cancelled"
            raise
        finally:
            if event_name and self._bus is not None:
                await self._bus.emit(event_name, event_data)


class IdempotencyMiddleware(StepMiddleware):
    """
    @description 幂等缓存，中命中时直接返回历史结果。
    """

    def __init__(self, state_store: Any):
        self._store = state_store

    async def process(self, step: TaskStep, ctx: Any, next_fn: Callable) -> StepResult:
        if step.idempotency_key:
            cached = await self._store.load_step_result(ctx.envelope.task_id, step.idempotency_key)
            if cached is not None:
                cached.cached = True
                return cached

        result = await next_fn(step)
        if result.success and step.idempotency_key:
            await self._store.checkpoint_step(ctx.envelope.task_id, step.idempotency_key, result)
        return result


class RetryMiddleware(StepMiddleware):
    """
    @description 指数退避重试 + 降级 + on_fail 策略。
    """

    def __init__(self, llm_service: Any):
        self._llm = llm_service

    async def process(self, step: TaskStep, ctx: Any, next_fn: Callable) -> StepResult:
        attempts = step.max_retries + 1
        last_result: StepResult | None = None
        for attempt in range(1, attempts + 1):
            try:
                result = await next_fn(step)
            except WorkflowCancelled:
                raise
            except WorkflowAborted:
                raise
            except Exception as error:
                result = StepResult(
                    step_name=step.name,
                    agent_type=step.agent_type,
                    success=False,
                    duration=0.0,
                    error=str(error),
                    error_category=ErrorCategory.TRANSIENT,
                )

            if result.success:
                return result

            last_result = result
            if (
                result.error_category == ErrorCategory.DEGRADABLE
                and not step.required
            ):
                result.degraded = True
                result.skipped = True
                return result
            if result.error_category != ErrorCategory.TRANSIENT or attempt >= attempts:
                break
            await asyncio.sleep(min(2 ** (attempt - 1), 5))

        assert last_result is not None
        if step.on_fail == "llm_fallback" and self._llm is not None:
            output = await self._llm.chat(step.prompt, max_tokens=2048)
            if output:
                return StepResult(
                    step_name=step.name,
                    agent_type="llm_fallback",
                    output=output,
                    success=True,
                    duration=last_result.duration,
                    passed=True,
                )

        should_skip = step.on_fail == "skip" or (step.on_fail == "auto" and not step.required)
        if should_skip:
            last_result.skipped = True
            return last_result
        raise WorkflowAborted(last_result.error or f"step failed: {step.name}")


class MiddlewareChain:
    """
    @description 按顺序嵌套执行中间件。
    """

    def __init__(self, middlewares: List[StepMiddleware]):
        self._middlewares = middlewares

    async def process(self, step: TaskStep, ctx: Any, final_fn: Callable) -> StepResult:
        """
        @description 将中间件包装成递归调用链。
        @param {TaskStep} step
        @param {Any} ctx
        @param {Callable} final_fn
        @returns {StepResult}
        """

        async def call(index: int, current_step: TaskStep) -> StepResult:
            if index >= len(self._middlewares):
                return await final_fn(current_step)
            middleware = self._middlewares[index]
            return await middleware.process(
                current_step,
                ctx,
                lambda next_step: call(index + 1, next_step),
            )

        return await call(0, step)
