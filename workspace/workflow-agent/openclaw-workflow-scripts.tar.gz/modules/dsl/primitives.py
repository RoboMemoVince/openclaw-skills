"""
Workflow DSL primitives.
"""

from __future__ import annotations

import hashlib
from contextvars import ContextVar
from typing import Dict, List

from modules.data_types import StepResult, TaskStep

_runtime_var: ContextVar["WorkflowRuntime"] = ContextVar("workflow_runtime")

AGENT_LABEL_MAP: Dict[str, Dict[str, str]] = {
    "executor": {},
    "reviewer": {"review": "true"},
    "instant": {"instant": "true"},
}


def _build_task_step(
    name: str,
    prompt: str,
    *,
    agent: str = "executor",
    mcp: List[str] | None = None,
    labels: Dict[str, str] | None = None,
    timeout: int = 300,
    required: bool = True,
    max_retries: int = 2,
    on_fail: str = "auto",
    prompt_extra: str = "",
    **_: object,
) -> TaskStep:
    """
    @description 构建 TaskStep，统一处理标签和 MCP 需求。
    @param {str} name
    @param {str} prompt
    @returns {TaskStep}
    """

    merged_labels = dict(AGENT_LABEL_MAP.get(agent, {}))
    for group in mcp or []:
        merged_labels[f"mcp.{group}"] = "true"
    for key, value in (labels or {}).items():
        merged_labels[key] = value

    final_prompt = prompt
    if prompt_extra:
        final_prompt = f"{prompt}\n\n{prompt_extra}"

    idempotency_key = hashlib.sha256(f"{name}:{agent}:{final_prompt[:200]}".encode()).hexdigest()[:16]
    return TaskStep(
        name=name,
        prompt=final_prompt,
        requirements=merged_labels,
        timeout=timeout,
        required=required,
        max_retries=max_retries,
        on_fail=on_fail,
        idempotency_key=idempotency_key,
        agent_type=agent,
        mcp_groups=list(mcp or []),
        prompt_extra=prompt_extra,
    )


async def step(
    name: str,
    prompt: str,
    *,
    agent: str = "executor",
    mcp: List[str] | None = None,
    labels: Dict[str, str] | None = None,
    timeout: int = 300,
    required: bool = True,
    max_retries: int = 2,
    on_fail: str = "auto",
    prompt_extra: str = "",
) -> StepResult:
    """
    @description 单步执行原语。
    @returns {StepResult}
    """

    runtime = _runtime_var.get()
    task_step = _build_task_step(
        name,
        prompt,
        agent=agent,
        mcp=mcp,
        labels=labels,
        timeout=timeout,
        required=required,
        max_retries=max_retries,
        on_fail=on_fail,
        prompt_extra=prompt_extra,
    )
    return await runtime.execute_step(task_step)


async def parallel(steps: List[dict]) -> List[StepResult]:
    """
    @description 并行执行多个步骤。
    @param {list[dict]} steps
    @returns {list[StepResult]}
    """

    runtime = _runtime_var.get()
    task_steps = [_build_task_step(**payload) for payload in steps]
    return await runtime.schedule_batch_and_execute(task_steps)


async def ask(
    name: str,
    prompt: str,
    *,
    options: List[str] | None = None,
    timeout: int = 60,
    default: str = "",
) -> str:
    """
    @description 执行中向用户请求输入。
    @param {str} name
    @param {str} prompt
    @param {list[str] | None} options
    @param {int} timeout
    @param {str} default
    @returns {str}
    """

    runtime = _runtime_var.get()
    interaction_key = hashlib.sha256(f"ask:{name}:{prompt[:100]}".encode()).hexdigest()[:16]
    saved = await runtime.load_interaction(interaction_key)
    if saved is not None:
        return saved

    await runtime.save_interaction_request(interaction_key, prompt, options, default)
    result = await runtime.request_user_input(
        name, prompt, options, timeout, default, interaction_key=interaction_key,
    )
    await runtime.save_interaction_response(interaction_key, result)
    return result
