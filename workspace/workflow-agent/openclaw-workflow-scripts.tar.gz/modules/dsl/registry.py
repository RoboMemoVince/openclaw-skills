"""
Workflow registry and decorator.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

DEFAULT_MIDDLEWARES = ["cancellation", "event", "idempotency", "retry"]


@dataclass
class WorkflowEntry:
    """
    @description 工作流注册条目。
    """

    fn: Callable
    timeout: int
    middlewares: List[str] = field(default_factory=lambda: list(DEFAULT_MIDDLEWARES))
    interaction_mode: str = "auto"


_workflows: Dict[str, WorkflowEntry] = {}


def workflow(
    name: str,
    *,
    timeout: int = 300,
    middlewares: Optional[List[str]] = None,
    interaction_mode: str = "auto",
):
    """
    @description 装饰器，注册工作流函数。
    @param {str} name
    @param {int} timeout
    @param {list[str] | None} middlewares
    @param {str} interaction_mode
    @returns {Callable}
    """

    def decorator(fn: Callable) -> Callable:
        _workflows[name] = WorkflowEntry(
            fn=fn,
            timeout=timeout,
            middlewares=list(middlewares) if middlewares is not None else list(DEFAULT_MIDDLEWARES),
            interaction_mode=interaction_mode,
        )
        return fn

    return decorator


class WorkflowRegistry:
    """
    @description 工作流注册表。
    """

    def get(self, name: str) -> Callable | None:
        entry = _workflows.get(name)
        return entry.fn if entry else None

    def get_entry(self, name: str) -> WorkflowEntry | None:
        return _workflows.get(name)

    def list_all(self) -> List[str]:
        return list(_workflows.keys())
