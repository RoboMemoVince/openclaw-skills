"""
Workflow runtime that bridges DSL primitives to scheduler and workers.
"""

from __future__ import annotations

import asyncio
from typing import Any, List

from modules.data_types import StepResult, TaskStep, WorkflowResult
from modules.dsl.errors import WorkflowAborted, WorkflowCancelled
from modules.dsl.middleware import (
    CancellationMiddleware,
    EventMiddleware,
    IdempotencyMiddleware,
    MiddlewareChain,
    RetryMiddleware,
)
from modules.dsl.primitives import _runtime_var


class WorkflowRuntime:
    """
    @description 桥接 DSL 原语与系统组件，通过中间件链处理每个步骤。
    """

    def __init__(
        self,
        scheduler: Any,
        state_store: Any,
        event_bus: Any,
        llm_service: Any,
        user_interactor: Any = None,
    ):
        self._scheduler = scheduler
        self._state_store = state_store
        self._event_bus = event_bus
        self._llm_service = llm_service
        self._interactor = user_interactor
        self.MIDDLEWARE_REGISTRY = {
            "cancellation": CancellationMiddleware,
            "event": lambda: EventMiddleware(event_bus),
            "idempotency": lambda: IdempotencyMiddleware(state_store),
            "retry": lambda: RetryMiddleware(llm_service),
        }

    def _build_chain(self, middleware_names: List[str]) -> MiddlewareChain:
        """
        @description 根据工作流配置动态构建中间件链。
        @param {list[str]} middleware_names
        @returns {MiddlewareChain}
        """

        middlewares = []
        for name in middleware_names:
            factory = self.MIDDLEWARE_REGISTRY.get(name)
            if factory is None:
                continue
            middlewares.append(factory() if callable(factory) else factory)
        return MiddlewareChain(middlewares)

    async def run(
        self,
        workflow_fn,
        ctx,
        timeout: int = 300,
        middlewares: List[str] | None = None,
    ) -> WorkflowResult:
        """
        @description 执行工作流函数，支持工作流级超时和中间件链。
        @param {Callable} workflow_fn
        @param {Any} ctx
        @param {int} timeout
        @param {list[str] | None} middlewares
        @returns {WorkflowResult}
        """

        self._chain = self._build_chain(middlewares or ["cancellation", "event", "idempotency", "retry"])
        self._ctx = ctx
        self._step_results: List[StepResult] = []
        token = _runtime_var.set(self)
        try:
            output = await asyncio.wait_for(workflow_fn(ctx), timeout=timeout)
            if isinstance(output, WorkflowResult):
                result = output
            else:
                result = WorkflowResult(success=True, output=str(output))
            result.steps = list(self._step_results)
            result.degraded_steps = [
                step.step_name for step in self._step_results if step.degraded or step.skipped
            ]
            return result
        except asyncio.TimeoutError:
            return WorkflowResult(
                success=False,
                error=f"workflow timeout ({timeout}s)",
                steps=list(self._step_results),
            )
        except WorkflowCancelled:
            return WorkflowResult(success=False, error="cancelled", steps=list(self._step_results))
        except WorkflowAborted as error:
            return WorkflowResult(success=False, error=str(error), steps=list(self._step_results))
        finally:
            _runtime_var.reset(token)

    async def execute_step(self, step: TaskStep) -> StepResult:
        """
        @description DSL `step()` 原语的最终执行入口。
        @param {TaskStep} step
        @returns {StepResult}
        """

        result = await self._chain.process(step, self._ctx, self._schedule_and_execute)
        self._step_results.append(result)
        return result

    async def schedule_batch_and_execute(self, steps: List[TaskStep]) -> List[StepResult]:
        """
        @description 并行执行多个步骤。
        @param {list[TaskStep]} steps
        @returns {list[StepResult]}
        """
        assignments = await self._scheduler.schedule_batch(steps, self._ctx.envelope.priority)
        results = await asyncio.gather(
            *[
                self._chain.process(
                    step,
                    self._ctx,
                    lambda current_step, assignment=assignment: assignment.slot.execute_and_release(current_step),
                )
                for step, assignment in zip(steps, assignments)
            ],
            return_exceptions=True,
        )
        normalized: List[StepResult] = []
        for item in results:
            if isinstance(item, Exception):
                normalized.append(StepResult(step_name="parallel", success=False, error=str(item)))
            else:
                self._step_results.append(item)
                normalized.append(item)
        return normalized

    async def _schedule_and_execute(self, step: TaskStep) -> StepResult:
        """
        @description 中间件链最内层：调度并执行步骤。
        @param {TaskStep} step
        @returns {StepResult}
        """

        assignment = await self._scheduler.schedule(step, self._ctx.envelope.priority)
        return await assignment.slot.execute_and_release(step)

    async def load_interaction(self, interaction_key: str) -> str | None:
        """
        @description 读取已保存的交互响应。
        @param {str} interaction_key
        @returns {str | None}
        """

        return await self._state_store.get_kv(
            self._ctx.envelope.task_id,
            f"interaction:{interaction_key}:response",
        )

    async def save_interaction_request(
        self,
        interaction_key: str,
        prompt: str,
        options: List[str] | None,
        default: str,
    ) -> None:
        """
        @description 保存交互请求检查点。
        @returns {None}
        """

        await self._state_store.set_kv(
            self._ctx.envelope.task_id,
            f"interaction:{interaction_key}:request",
            {"prompt": prompt, "options": options, "default": default},
        )

    async def save_interaction_response(self, interaction_key: str, response: str) -> None:
        """
        @description 保存交互响应检查点。
        @returns {None}
        """

        await self._state_store.set_kv(
            self._ctx.envelope.task_id,
            f"interaction:{interaction_key}:response",
            response,
        )

    async def request_user_input(
        self,
        name: str,
        prompt: str,
        options: List[str] | None,
        timeout: int,
        default: str,
        *,
        interaction_key: str = "",
    ) -> str:
        """
        @description 通过 UserInteractor 请求用户输入，传递 interaction_key 和 options。
        @returns {str}
        """

        if self._interactor is None:
            return default
        result = await self._interactor.request_input(
            self._ctx.envelope,
            prompt,
            timeout,
            interaction_key=interaction_key,
            options=options,
        )
        return result if result is not None else default
