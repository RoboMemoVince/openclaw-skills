"""
Centralised logging configuration with task_id correlation.

Provides:
  - ``setup_logging()``      -- one-time root logger configuration
  - ``TaskContextFilter``    -- injects ``task_id`` into every log record
  - ``set_task_id()``        -- set the current task_id for the calling coroutine
  - ``get_task_id()``        -- read the current task_id

Usage (at application startup)::

    from modules.logging_config import setup_logging
    setup_logging()

Usage (inside a task handler)::

    from modules.logging_config import set_task_id
    set_task_id("abc123")
    # all subsequent logger.xxx() calls in this coroutine include task_id=abc123
"""

from __future__ import annotations

import contextvars
import logging
import sys
from pathlib import Path
from typing import Optional

_task_id_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "openclaw_task_id", default="",
)

_LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
_LOG_FORMAT = (
    "%(asctime)s [%(levelname)s] %(name)s"
    " [task=%(task_id)s]"
    " %(message)s"
)
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def set_task_id(task_id: str) -> None:
    """Set the task_id for the current asyncio task / thread."""
    _task_id_var.set(task_id)


def get_task_id() -> str:
    """Read the current task_id (empty string if unset)."""
    return _task_id_var.get()


class TaskContextFilter(logging.Filter):
    """Inject ``task_id`` from the context variable into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.task_id = _task_id_var.get()  # type: ignore[attr-defined]
        return True


def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[str] = None,
) -> None:
    """
    Configure the root ``openclaw`` logger with structured output.

    @param {int} level     - minimum log level (default INFO)
    @param {str|None} log_file - optional file path; defaults to ``logs/openclaw.log``
    """
    root_logger = logging.getLogger("openclaw")

    if root_logger.handlers:
        return

    root_logger.setLevel(level)
    context_filter = TaskContextFilter()

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(formatter)
    console.addFilter(context_filter)
    root_logger.addHandler(console)

    file_path = Path(log_file) if log_file else _LOG_DIR / "openclaw.log"
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(str(file_path), encoding="utf-8")
        file_handler.setFormatter(formatter)
        file_handler.addFilter(context_filter)
        root_logger.addHandler(file_handler)
    except OSError:
        root_logger.warning("Cannot create log file at %s, file logging disabled", file_path)
