"""
Core data types -- pure dataclasses and enums used across old and new runtimes.

This file intentionally keeps backward compatibility with the legacy
Orchestrator/ExecutionEngine while introducing the new workflow architecture
types required by Gateway -> Controller -> Scheduler -> Worker.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

_USER_HOME = str(Path.home())


class Phase(Enum):
    """
    @description 任务生命周期阶段。
    """

    RECEIVED = "received"
    CLASSIFIED = "classified"
    PREPARING = "preparing"
    EXECUTING = "executing"
    DELIVERED = "delivered"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Priority(Enum):
    """
    @description 任务优先级，数值越小优先级越高。
    """

    P0_REALTIME = 0
    P1_BACKGROUND = 1
    P2_OPS = 2


class ErrorCategory(Enum):
    """
    @description 错误分类，决定自动处理策略。
    """

    TRANSIENT = "transient"
    PERMANENT = "permanent"
    DEGRADABLE = "degradable"

    @classmethod
    def from_error_code(cls, code_value: str) -> "ErrorCategory":
        """
        @description 将服务层 ErrorCode 映射为执行层错误分类。
        @param {str} code_value - ErrorCode 值，例如 "E1001"。
        @returns {ErrorCategory}
        """

        permanent_codes = {"E1002", "E1003", "E5000", "E5001", "E5002"}
        degradable_codes = {"E2000"}
        if code_value in permanent_codes:
            return cls.PERMANENT
        if code_value in degradable_codes:
            return cls.DEGRADABLE
        return cls.TRANSIENT


class SubTaskState(Enum):
    """
    @description 旧执行引擎使用的子任务生命周期状态。
    """

    PENDING = "pending"
    BLOCKED = "blocked"
    ACQUIRED = "acquired"
    RUNNING = "running"
    VALIDATING = "validating"
    DONE = "done"
    DEGRADED = "degraded"
    RETRY_REVIEW = "retry_review"
    RETRY_EXEC = "retry_exec"
    FAILED = "failed"
    LLM_FALLBACK = "llm_fallback"
    ABORTED = "aborted"


@dataclass
class TaskEnvelope:
    """
    @description 新工作流架构使用的标准化任务容器，同时兼容旧 TaskRequest。
    """

    task_id: str
    content: str
    user_id: str = ""
    source: str = "cli"
    command: str = ""
    parsed_args: str = ""
    workspace: str = _USER_HOME
    timeout: int = 600
    phase: Phase = Phase.RECEIVED
    priority: Priority = Priority.P0_REALTIME
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Any = field(default_factory=datetime.now)
    scheduled_at: datetime | None = None
    workflow_name: str = ""
    result: Any = None
    iteration: int = 0
    max_iterations: int = 3
    reclassify: bool = False
    reclassified: bool = False

    @property
    def channel(self) -> str:
        """
        @description 新架构别名，兼容旧 source 字段。
        @returns {str}
        """

        return self.source

    @channel.setter
    def channel(self, value: str) -> None:
        self.source = value

    @property
    def parsed_command(self) -> str:
        """
        @description 新架构别名，兼容旧 command 字段。
        @returns {str}
        """

        return self.command

    @parsed_command.setter
    def parsed_command(self, value: str) -> None:
        self.command = value


# Backward compatibility: legacy code still imports TaskRequest.
TaskRequest = TaskEnvelope


@dataclass
class TaskStep:
    """
    @description DSL `step()` 原语产生的步骤声明。
    """

    name: str
    prompt: str
    requirements: Dict[str, str] = field(default_factory=dict)
    timeout: int = 300
    required: bool = True
    max_retries: int = 2
    on_fail: str = "auto"
    idempotency_key: str = ""
    agent_type: str = "executor"
    mcp_groups: List[str] = field(default_factory=list)
    prompt_extra: str = ""


@dataclass
class SubTask:
    """
    @description 旧 Planner 产生的单个子任务声明。
    """

    step_index: int
    step_name: str
    agent_type: str
    prompt: str
    mcp_groups: List[str] = field(default_factory=list)
    output_key: str = ""
    parallel: bool = False
    required: bool = True
    max_retries: int = 2
    timeout: int = 300
    input_template: str = ""
    depends_on: List[str] = field(default_factory=list)
    max_review_retries: int = 2
    state: SubTaskState = SubTaskState.PENDING
    idempotency_key: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


@dataclass
class Assignment:
    """
    @description 旧执行引擎使用的分配结果。
    """

    subtask: SubTask
    agent_id: str = "main"
    workspace: str = _USER_HOME
    concurrency_group: Optional[int] = None


@dataclass
class StepResult:
    """
    @description 单步执行结果，兼容旧 AgentRunner/ExecutionEngine 和新 DSL Runtime。
    """

    step_name: str
    agent_type: str = ""
    output_key: str = ""
    output: str = ""
    success: bool = False
    duration: float = 0.0
    error: str = ""
    error_category: Optional[ErrorCategory] = None
    mcp_groups: List[str] = field(default_factory=list)
    returncode: int = 0
    passed: bool = False
    feedback: str = ""
    degraded: bool = False
    skipped: bool = False
    cached: bool = False
    items: List[Any] | None = None


@dataclass
class ReviewedResult:
    """
    @description 审核/校验结果。
    """

    passed: bool
    feedback: str
    result: StepResult


@dataclass
class WorkflowResult:
    """
    @description 工作流整体执行结果，兼容旧聚合结果与新迭代协议。
    """

    success: bool = False
    output: str = ""
    error: str = ""
    needs_iteration: bool = False
    reclassify: bool = False
    iteration_reason: str = ""
    steps: List[StepResult] = field(default_factory=list)
    degraded_steps: List[str] = field(default_factory=list)
    task_id: str = ""
    workflow_id: str = ""
    workflow_name: str = ""
    partial: bool = False
    reviewed: List[ReviewedResult] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    total_duration: float = 0.0
    routing_decision: str = ""


@dataclass
class WorkerAssignment:
    """
    @description Scheduler 分配的 WorkerSlot-Step 绑定。
    """

    slot: Any
    step: TaskStep
    priority: Priority
    assigned_at: datetime = field(default_factory=datetime.now)
    timeout_at: datetime | None = None


@dataclass
class ClassifyResult:
    """
    @description 分类结果，携带工作流、置信度、来源和候选项。
    """

    workflow_name: str
    confidence: float
    source: str
    reason: str = ""
    alternatives: List[str] = field(default_factory=list)


@dataclass
class EscalatableDecision:
    """
    @description 系统层可升级决策。
    """

    auto_choice: str
    confidence: float
    alternatives: List[str]
    reason: str
    escalation_prompt: str


@dataclass
class EscalationConfig:
    """
    @description 各决策点的升级行为配置。
    """

    classification_threshold: float = 0.6
    classification_timeout_s: int = 30
    iteration_threshold: float = 0.5
    iteration_timeout_s: int = 30
    hook_failure_threshold: float = 0.5
    hook_failure_timeout_s: int = 15


@dataclass
class IterationConfig:
    """
    @description 迭代策略的自主行为配置。
    """

    reclassify_threshold: float = 0.5


CRASH_MARKERS = ("Traceback", "FATAL", "panic:", "Segmentation fault")

DEGRADED_PREFIX = "@@DEGRADED@@"
FAILED_PREFIX = "@@STEP_FAILED@@"


def make_degraded_value(step_name: str, error: str) -> str:
    """
    @description 构造降级占位值，供下游步骤识别。
    @param {str} step_name
    @param {str} error
    @returns {str}
    """

    return f"{DEGRADED_PREFIX}{step_name}: {error[:100]}"


def make_failed_value(step_name: str, error: str) -> str:
    """
    @description 构造失败占位值，供下游步骤识别。
    @param {str} step_name
    @param {str} error
    @returns {str}
    """

    return f"{FAILED_PREFIX}{step_name}: {error[:100]}"


def is_degraded_or_failed(value: str) -> bool:
    """
    @description 判断上下文值是否为降级/失败占位符。
    @param {str} value
    @returns {bool}
    """

    if not isinstance(value, str):
        return False
    return value.startswith(DEGRADED_PREFIX) or value.startswith(FAILED_PREFIX)
