"""
ModuleRegistry -- auto-discovery, dependency resolution, lifecycle management.

Discovery strategy (combined):
  1. Read config/module-registry.yaml for explicitly registered modules
  2. Scan modules/ and services/ for module.yaml manifests
  3. Newly discovered modules (present on disk but absent from registry.yaml)
     are logged for the user to confirm
"""

from __future__ import annotations

import asyncio
import importlib
import importlib.util
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore

from modules.base import ModuleBase

_OPENCLAW_ROOT = Path(__file__).resolve().parent.parent
_CONFIG_PATH = _OPENCLAW_ROOT / "config" / "module-registry.yaml"
_SCAN_DIRS = [_OPENCLAW_ROOT / "modules", _OPENCLAW_ROOT / "services"]


class ModuleRegistry:
    """
    Central registry that owns all module/service instances.

    @param {str} config_path - path to module-registry.yaml
    """

    def __init__(self, config_path: str = str(_CONFIG_PATH)):
        self._config_path = Path(config_path)
        self._instances: Dict[str, ModuleBase] = {}
        self._manifests: Dict[str, dict] = {}
        self._enabled: Dict[str, bool] = {}

    # ── public API ────────────────────────────────────────────────

    def get(self, name: str) -> Optional[ModuleBase]:
        """Retrieve an initialised module by name."""
        return self._instances.get(name)

    def get_all(self) -> Dict[str, ModuleBase]:
        return dict(self._instances)

    async def boot(self) -> None:
        """Full lifecycle: discover -> instantiate -> topo-sort -> parallel-layer init."""
        self._load_registry_config()
        self._scan_manifests()
        self._report_discovered()
        self._instantiate_all()
        layers = self._topo_layers()
        for layer in layers:
            insts = [self._instances[n] for n in layer if n in self._instances]
            if len(insts) == 1:
                await insts[0].initialize(self)
            elif insts:
                await asyncio.gather(*(inst.initialize(self) for inst in insts))

    async def shutdown_all(self) -> None:
        for inst in reversed(list(self._instances.values())):
            try:
                await inst.shutdown()
            except Exception:
                pass

    # ── discovery ─────────────────────────────────────────────────

    def _load_registry_config(self) -> None:
        """Read config/module-registry.yaml."""
        if not yaml or not self._config_path.exists():
            return
        with open(self._config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        for section in ("modules", "services"):
            for name, cfg in data.get(section, {}).items():
                self._enabled[name] = cfg.get("enabled", True) if isinstance(cfg, dict) else bool(cfg)

    def _scan_manifests(self) -> None:
        """Walk modules/ and services/ looking for module.yaml files."""
        if not yaml:
            return
        for scan_dir in _SCAN_DIRS:
            if not scan_dir.is_dir():
                continue
            for manifest_path in scan_dir.rglob("module.yaml"):
                try:
                    with open(manifest_path, "r", encoding="utf-8") as f:
                        manifest = yaml.safe_load(f)
                    name = manifest.get("name", "")
                    if name:
                        manifest["_dir"] = str(manifest_path.parent)
                        self._manifests[name] = manifest
                except Exception:
                    continue

    def _report_discovered(self) -> None:
        """Log modules found on disk but not in registry.yaml."""
        for name in self._manifests:
            if name not in self._enabled:
                print(f"[registry] discovered new module '{name}' "
                      f"-- add to module-registry.yaml to enable")

    # ── instantiation ─────────────────────────────────────────────

    def _instantiate_all(self) -> None:
        for name, manifest in self._manifests.items():
            if not self._enabled.get(name, False):
                continue
            inst = self._load_module_class(manifest)
            if inst:
                self._instances[name] = inst

    def _load_module_class(self, manifest: dict) -> Optional[ModuleBase]:
        """Dynamically import the entry class from a manifest."""
        mod_dir = manifest.get("_dir", "")
        entry_file = manifest.get("entry", "")
        class_name = manifest.get("class", "")
        if not (mod_dir and entry_file and class_name):
            return None

        entry_path = os.path.join(mod_dir, entry_file)
        if not os.path.isfile(entry_path):
            return None

        module_name = f"_ocmod_{manifest['name']}"
        spec = importlib.util.spec_from_file_location(module_name, entry_path)
        if not spec or not spec.loader:
            return None

        mod = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = mod
        try:
            spec.loader.exec_module(mod)
        except Exception as e:
            print(f"[registry] failed to load {manifest['name']}: {e}")
            return None

        cls = getattr(mod, class_name, None)
        if cls is None or not (isinstance(cls, type) and issubclass(cls, ModuleBase)):
            print(f"[registry] {class_name} in {entry_path} is not a ModuleBase subclass")
            return None

        try:
            return cls()
        except Exception as e:
            print(f"[registry] failed to instantiate {class_name}: {e}")
            return None

    # ── dependency resolution ─────────────────────────────────────

    def _topo_layers(self) -> List[List[str]]:
        """
        Topological sort split into layers.  Modules within the same layer
        have no dependencies on each other and can be initialised in parallel.
        """
        graph: Dict[str, List[str]] = defaultdict(list)
        in_degree: Dict[str, int] = {n: 0 for n in self._instances}

        for name, inst in self._instances.items():
            for dep in inst.dependencies:
                if dep in self._instances:
                    graph[dep].append(name)
                    in_degree[name] = in_degree.get(name, 0) + 1

        layers: List[List[str]] = []
        queue = [n for n, d in in_degree.items() if d == 0]
        while queue:
            layers.append(list(queue))
            next_queue: List[str] = []
            for node in queue:
                for neighbor in graph[node]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        next_queue.append(neighbor)
            queue = next_queue

        remaining = set(self._instances) - {n for layer in layers for n in layer}
        if remaining:
            print(f"[registry] circular dependency detected for: {remaining}")
            layers.append(list(remaining))

        return layers

    def _topo_sort(self) -> List[str]:
        """Flat topological order (for backward compatibility)."""
        return [n for layer in self._topo_layers() for n in layer]
