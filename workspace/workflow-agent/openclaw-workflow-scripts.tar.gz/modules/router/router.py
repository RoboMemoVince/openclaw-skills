"""
Router -- three-level routing funnel with adaptive feedback.

Extracted from Orchestrator to be a first-class module with its own
feedback loop for threshold tuning.

Levels:
  1. Heuristic fast-path (0ms, ~70%)
  2. LLM binary classify  (~1s, ~30% — only for "uncertain")
  3. /miniagent force override
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from modules.base import ModuleBase
from modules.data_types import TaskRequest, EventBus

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.router")

_MULTI_STEP_MARKERS = ("然后", "接着", "最后", "第一步", "步骤", "分别")
_COMPLEX_KEYWORDS = (
    "写代码", "创建文件", "分析数据", "部署", "重构",
    "测试", "调试", "搜索并", "对比", "生成报告",
)

_ROUTING_PROMPT = (
    "判断以下任务是否需要多步骤工作流来完成。\n"
    "- simple: 可以一次性回答（问答、翻译、简单计算等）\n"
    "- workflow: 需要多步执行（代码编写+测试、数据收集+分析+报告、多工具协作等）\n"
    "只回复 simple 或 workflow。\n\n任务: {task}"
)

from modules.paths import DATA_DIR

_FEEDBACK_PATH = DATA_DIR / ".routing_feedback.json"
_RECALIBRATE_EVERY = 100


class Router(ModuleBase):
    """
    Three-level routing funnel with self-adaptive feedback.

    @method route              Classify a task as simple/workflow/forced.
    @method record_feedback    Record actual outcome for threshold tuning.
    """

    @property
    def name(self) -> str:
        return "router"

    @property
    def version(self) -> str:
        return "1.0"

    @property
    def dependencies(self) -> List[str]:
        return ["llm_service"]

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._llm = registry.get("llm_service")
        self._stats = self._load_stats()
        self._min_length_threshold = self._stats.get(
            "_min_length_threshold", 50,
        )
        self._multi_step_threshold = self._stats.get(
            "_multi_step_threshold", 2,
        )

    # ── public API ────────────────────────────────────────────────

    async def route(self, task: TaskRequest) -> str:
        """
        Three-level routing funnel.

        @returns "forced" | "workflow" | "simple"
        """
        if task.command == "/miniagent":
            return "forced"

        h = self._heuristic_classify(task.content)
        if h == "simple":
            return "simple"
        if h == "complex":
            return "workflow"

        verdict = await self._llm_route_classify(task.content)
        return verdict

    def subscribe_to(self, bus: EventBus) -> None:
        """Subscribe to on_complete events for automatic feedback."""
        bus.subscribe("on_complete", self._on_complete)

    # ── heuristic classification ──────────────────────────────────

    def _heuristic_classify(self, content: str) -> str:
        """Zero-LLM-call heuristic.  Returns "simple" | "complex" | "uncertain"."""
        if sum(1 for m in _MULTI_STEP_MARKERS if m in content) >= self._multi_step_threshold:
            return "complex"
        if any(kw in content for kw in _COMPLEX_KEYWORDS):
            return "complex"
        if len(content) < self._min_length_threshold and \
                any(content.endswith(c) for c in ("?", "？", "吗", "呢")):
            return "simple"
        return "uncertain"

    async def _llm_route_classify(self, content: str) -> str:
        """LLM-based binary classification for uncertain inputs."""
        prompt = _ROUTING_PROMPT.format(task=content[:300])
        answer = await self._llm.chat(prompt, max_tokens=16) if self._llm else ""
        answer = answer.strip().lower()
        if answer in ("simple", "workflow"):
            return answer
        return "workflow"

    # ── feedback + recalibration ──────────────────────────────────

    async def _on_complete(self, data: dict) -> None:
        """EventBus handler for automatic feedback collection."""
        decision = data.get("routing_decision", "")
        steps = len(data.get("steps", []))
        tool_calls = data.get("tool_calls_count", 0)
        success = data.get("success", False)
        planner_fallback = data.get("planner_fallback", False)

        if decision in ("workflow", "forced") and planner_fallback:
            return

        if decision:
            await self.record_feedback(decision, steps, success, tool_calls)

    async def record_feedback(
        self,
        routing_decision: str,
        actual_steps: int,
        success: bool,
        tool_calls_count: int = 0,
    ) -> None:
        """
        Record how a routing decision played out and trigger recalibration.

        @param {str} routing_decision - what the router decided
        @param {int} actual_steps     - how many steps were actually executed
        @param {bool} success         - whether the task succeeded
        @param {int} tool_calls_count - number of MCP tool calls in simple path
        """
        correct = self._was_correct(routing_decision, actual_steps, success, tool_calls_count)
        key = f"{routing_decision}_correct" if correct else f"{routing_decision}_wrong"
        self._stats[key] = self._stats.get(key, 0) + 1
        self._stats["total"] = self._stats.get("total", 0) + 1

        self._recalibrate()
        self._save_stats()

    @staticmethod
    def _was_correct(
        decision: str, actual_steps: int, success: bool, tool_calls_count: int = 0,
    ) -> bool:
        """
        Determine if the routing decision was correct.

        For 'simple' decisions: correct if the task succeeded without needing
        multi-step workflow AND used few tool calls.

        For 'workflow'/'forced' decisions: correct if the task genuinely
        required multiple steps.  A failed workflow is inconclusive (not
        counted as "wrong") because we cannot know whether simple would
        have done better.  Planner-fallback cases are already filtered out
        in ``_on_complete`` before this method is called.
        """
        if decision == "simple":
            if not success:
                return False
            return actual_steps <= 1 and tool_calls_count <= 2
        if not success:
            return True
        return actual_steps > 1

    def _recalibrate(self) -> None:
        """
        Adjust heuristic thresholds based on accumulated feedback.

        Tunes three parameters:
        - _min_length_threshold: short-text "simple" cutoff
        - _multi_step_threshold: how many multi-step markers trigger "complex"
        - _workflow_wrong_streak: consecutive workflow mis-routes relax to simple
        """
        simple_wrong = self._stats.get("simple_wrong", 0)
        simple_correct = self._stats.get("simple_correct", 0)
        simple_total = simple_wrong + simple_correct
        workflow_wrong = self._stats.get("workflow_wrong", 0)
        workflow_correct = self._stats.get("workflow_correct", 0)
        workflow_total = workflow_wrong + workflow_correct

        if simple_total >= 10:
            error_rate = simple_wrong / simple_total
            if error_rate > 0.3:
                self._min_length_threshold = max(30, self._min_length_threshold - 5)
                logger.info(
                    "Router recalibrate: tightened simple threshold to %d chars "
                    "(simple error rate=%.0f%%)",
                    self._min_length_threshold, error_rate * 100,
                )
            elif error_rate < 0.1:
                self._min_length_threshold = min(80, self._min_length_threshold + 5)
                logger.info(
                    "Router recalibrate: relaxed simple threshold to %d chars "
                    "(simple error rate=%.0f%%)",
                    self._min_length_threshold, error_rate * 100,
                )

        if workflow_total >= 10:
            wf_error_rate = workflow_wrong / workflow_total
            if wf_error_rate > 0.4:
                self._multi_step_threshold = min(4, self._multi_step_threshold + 1)
                logger.info(
                    "Router recalibrate: raised multi-step threshold to %d "
                    "(workflow error rate=%.0f%%)",
                    self._multi_step_threshold, wf_error_rate * 100,
                )
            elif wf_error_rate < 0.1 and self._multi_step_threshold > 1:
                self._multi_step_threshold = max(1, self._multi_step_threshold - 1)
                logger.info(
                    "Router recalibrate: lowered multi-step threshold to %d "
                    "(workflow error rate=%.0f%%)",
                    self._multi_step_threshold, wf_error_rate * 100,
                )

        self._stats["_min_length_threshold"] = self._min_length_threshold
        self._stats["_multi_step_threshold"] = self._multi_step_threshold

    def _load_stats(self) -> Dict[str, Any]:
        """Load feedback stats and persisted thresholds."""
        if _FEEDBACK_PATH.exists():
            try:
                return json.loads(_FEEDBACK_PATH.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def _save_stats(self) -> None:
        """Persist feedback stats including calibrated thresholds."""
        self._stats["_min_length_threshold"] = self._min_length_threshold
        self._stats["_multi_step_threshold"] = self._multi_step_threshold
        try:
            _FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
            _FEEDBACK_PATH.write_text(
                json.dumps(self._stats, ensure_ascii=False, indent=2), encoding="utf-8",
            )
        except Exception:
            pass
