"""
Bypass observer for workflow events, breaker state, DLQ, and metrics.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict

from modules.data_types import CircuitBreakerRegistry, DeadLetterQueue, TaskTrace
from modules.paths import DATA_DIR


@dataclass
class MetricsCollector:
    """
    @description 轻量指标收集器。
    """

    counters: Dict[str, int] = field(default_factory=dict)

    def record(self, name: str) -> None:
        """
        @description 记录一次指标事件。
        @param {str} name
        @returns {None}
        """

        self.counters[name] = self.counters.get(name, 0) + 1

    def summary(self) -> Dict[str, int]:
        """
        @description 返回指标快照。
        @returns {dict}
        """

        return dict(self.counters)


class Observer:
    """
    @description 严格旁路系统，只观察不编排。
    """

    def __init__(self, event_bus, dlq_path: Path | None = None):
        self.breakers = CircuitBreakerRegistry()
        self.dlq = DeadLetterQueue(dlq_path or (DATA_DIR / ".workflow_dlq.jsonl"))
        self.metrics = MetricsCollector()
        self.traces: Dict[str, TaskTrace] = {}
        self._subscribe(event_bus)

    def _subscribe(self, event_bus) -> None:
        event_bus.subscribe("step_completed", self._on_step_completed)
        event_bus.subscribe("step_failed", self._on_step_failed)
        event_bus.subscribe("step_cancelled", self._on_step_cancelled)
        event_bus.subscribe("phase_changed", self._on_phase_changed)
        event_bus.subscribe("worker_heartbeat", self._on_heartbeat)
        event_bus.subscribe("delivery_exhausted", self._on_delivery_exhausted)
        event_bus.subscribe("task_cancelled", self._on_cancelled)
        event_bus.subscribe("task_expired", self._on_task_expired)

    async def _on_step_completed(self, data):
        self.breakers.record_success(data.get("service", "agent_runner"))
        self.metrics.record("step_completed")

    async def _on_step_failed(self, data):
        self.breakers.record_failure(data.get("service", "agent_runner"))
        self.metrics.record("step_failed")
        if data.get("error_category") == "permanent":
            await self.dlq.enqueue(
                data.get("task_id", ""),
                data.get("step_name", ""),
                data.get("error", ""),
                data.get("context"),
            )

    async def _on_step_cancelled(self, data):
        self.metrics.record("step_cancelled")

    async def _on_phase_changed(self, data):
        task_id = data.get("task_id", "")
        phase = data.get("phase", "unknown")
        if task_id and task_id not in self.traces:
            self.traces[task_id] = TaskTrace(task_id=task_id)
        self.metrics.record(f"phase:{phase}")

    async def _on_heartbeat(self, data):
        self.metrics.record("worker_heartbeat")

    async def _on_delivery_exhausted(self, data):
        self.metrics.record("delivery_exhausted")
        await self.dlq.enqueue(
            data.get("task_id", ""),
            "delivery",
            data.get("error", "delivery exhausted"),
            data,
        )

    async def _on_cancelled(self, data):
        self.metrics.record("task_cancelled")

    async def _on_task_expired(self, data):
        self.metrics.record("task_expired")

    def breaker_summary(self) -> Dict[str, str]:
        """
        @description 返回断路器状态摘要。
        @returns {dict}
        """

        return self.breakers.summary()

    def metrics_summary(self) -> Dict[str, int]:
        """
        @description 返回指标摘要。
        @returns {dict}
        """

        return self.metrics.summary()

    def trace_summary(self, task_id: str) -> dict:
        """
        @description 返回指定任务的 trace 摘要。
        @param {str} task_id
        @returns {dict}
        """

        trace = self.traces.get(task_id)
        return trace.summary() if trace is not None else {}
