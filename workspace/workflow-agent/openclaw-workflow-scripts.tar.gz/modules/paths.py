"""
Centralised path resolution for the OpenClaw runtime.

All paths are derived from ``OPENCLAW_HOME`` (env-var) which defaults to
``~/.openclaw``.  Modules should import from here instead of hardcoding
absolute paths.
"""

from __future__ import annotations

import os
from pathlib import Path

_home = os.environ.get("OPENCLAW_HOME", "")
OPENCLAW_HOME: Path = Path(_home) if _home else Path.home() / ".openclaw"

USER_HOME: Path = Path.home()
DATA_DIR: Path = OPENCLAW_HOME / "data"
CONFIG_DIR: Path = OPENCLAW_HOME / "config"
MAIN_CONFIG: Path = OPENCLAW_HOME / "openclaw.json"
DLQ_DIR: Path = DATA_DIR
DB_PATH: Path = DATA_DIR / "tasks.db"
