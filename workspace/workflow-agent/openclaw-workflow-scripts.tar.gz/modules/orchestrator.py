"""
Compatibility orchestrator that boots the new workflow architecture.

It preserves the old `create_orchestrator()` and `handle()` API so external
callers such as `openclaw_task_bridge.py` do not need to change.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from modules.data_types import Phase
from modules.controller.classifier import Classifier
from modules.controller.command_handler import ActiveTaskRegistry, CommandHandler
from modules.controller.hook_runner import HookRunner, KnowledgeLoader, ResourcePreflight
from modules.controller.iteration_strategy import IterationStrategy
from modules.controller.reconciler import Reconciler
from modules.controller.task_controller import TaskController
from modules.controller.user_interactor import StateBackedUserInteractor
from modules.data_types import EscalationConfig, EventBus, IterationConfig
from modules.dsl.registry import WorkflowRegistry
from modules.dsl.runtime import WorkflowRuntime
from modules.gateway.gateway import Gateway
from modules.observer.observer import Observer
from modules.paths import CONFIG_DIR, DLQ_DIR
from modules.registry import ModuleRegistry
from modules.scheduler.scheduler import Scheduler
from modules.worker.backends import ClaudeCodeBackend, LLMDirectBackend, MiniAgentBackend
from modules.worker.worker import WorkerPool

logger = logging.getLogger("openclaw.orchestrator")


class _BootstrapRegistry:
    """
    @description 极简注册表适配器，供手动初始化回退模块使用。
    """

    def __init__(self, instances: Dict[str, Any]):
        self._instances = instances

    def get(self, name: str):
        return self._instances.get(name)


class Orchestrator:
    """
    @description 新工作流架构的兼容封装器。
    """

    def __init__(
        self,
        registry: ModuleRegistry,
        gateway: Gateway,
        controller: TaskController,
        observer: Observer,
        state_store,
        error_service=None,
    ):
        self._registry = registry
        self._gateway = gateway
        self._controller = controller
        self._observer = observer
        self._state_store = state_store
        self._error_service = error_service
        self._event_bus = gateway._event_bus

    @property
    def event_bus(self) -> EventBus:
        """
        @description 暴露事件总线给兼容调用方。
        @returns {EventBus}
        """

        return self._event_bus

    async def handle(self, raw_input: Dict[str, Any]) -> Dict[str, Any]:
        """
        @description 端到端任务入口，保持旧桥接层签名不变。
        @param {dict} raw_input
        @returns {dict}
        """

        try:
            envelope = await self._gateway.receive(raw_input, raw_input.get("source", "bridge"))
            result = await self._controller.reconcile(envelope)
            delivered = await self._gateway.deliver(envelope, result)
            if not delivered and envelope.phase != Phase.CANCELLED:
                envelope.phase = Phase.FAILED
                envelope.result = result
                await self._state_store.save(envelope)
                result["success"] = False
                result["error"] = result.get("error") or "delivery_exhausted"
                result["phase"] = Phase.FAILED.value
            await self._event_bus.emit("on_complete", result)
            return result
        except Exception as error:
            logger.exception("handle() unhandled error")
            if self._error_service is not None:
                self._error_service.record(
                    error,
                    context={
                        "task_id": raw_input.get("message_id", ""),
                        "source": "workflow_orchestrator.handle",
                    },
                )
                friendly = self._error_service.translate(str(error))
            else:
                friendly = str(error)
            return {
                "success": False,
                "output": "",
                "raw_output": "",
                "error": friendly,
                "raw_error": str(error),
                "duration": 0,
                "task_id": raw_input.get("message_id", ""),
                "steps": [],
                "routing_decision": "",
            }

    async def scan_dlq(self) -> int:
        """
        @description 兼容旧接口，扫描 DLQ。
        @returns {int}
        """

        return await self._observer.dlq.scan_and_alert()

    async def consume_and_classify_dlq(self) -> Dict[str, Any]:
        """
        @description 兼容旧接口，消费并分类 DLQ。
        @returns {dict}
        """

        return await self._observer.dlq.consume_and_classify()


async def create_orchestrator() -> Orchestrator:
    """
    @description 启动服务注册表并构建兼容 Orchestrator。
    @returns {Orchestrator}
    """

    from modules.logging_config import setup_logging

    setup_logging()
    import workflows  # noqa: F401

    registry = ModuleRegistry()
    await registry.boot()
    boot_instances: Dict[str, Any] = dict(registry.get_all())

    async def ensure_instance(name: str, factory):
        existing = boot_instances.get(name)
        if existing is not None:
            return existing
        instance = factory()
        boot_instances[name] = instance
        await instance.initialize(_BootstrapRegistry(boot_instances))
        return instance

    llm_service = await ensure_instance("llm_service", lambda: __import__("services.llm_service.llm", fromlist=["LLMService"]).LLMService())
    mcp_service = await ensure_instance("mcp_service", lambda: __import__("services.mcp_service.mcp", fromlist=["MCPService"]).MCPService())
    error_service = await ensure_instance("error_service", lambda: __import__("services.error_service.error_adapter", fromlist=["ErrorService"]).ErrorService())
    agent_runner = await ensure_instance("agent_runner", lambda: __import__("modules.agent_runner.runner", fromlist=["AgentRunner"]).AgentRunner())
    direct_llm_handler = await ensure_instance("direct_llm_handler", lambda: __import__("modules.direct_llm_handler.handler", fromlist=["DirectLLMHandler"]).DirectLLMHandler())
    progress_reporter = boot_instances.get("progress_reporter")
    if progress_reporter is None:
        try:
            progress_reporter = await ensure_instance(
                "progress_reporter",
                lambda: __import__("modules.progress_reporter.reporter", fromlist=["ProgressReporter"]).ProgressReporter(),
            )
        except Exception:
            progress_reporter = None

    event_bus = EventBus(fallback_dir=DLQ_DIR)
    observer = Observer(event_bus)

    if progress_reporter is not None and hasattr(progress_reporter, "subscribe_to"):
        progress_reporter.subscribe_to(event_bus)

    if direct_llm_handler is not None and hasattr(direct_llm_handler, "set_event_bus"):
        direct_llm_handler.set_event_bus(event_bus)

    state_store = boot_instances.get("state_store")
    if state_store is None:
        from services.state_store.state_store import StateStore

        state_store = StateStore()
        boot_instances["state_store"] = state_store
        await state_store.initialize(_BootstrapRegistry(boot_instances))

    workflow_registry = WorkflowRegistry()
    classifier = Classifier(llm_service, workflow_registry)
    classifier_cfg = classifier.config
    esc_cfg = EscalationConfig(
        classification_threshold=classifier_cfg.get("escalation", {}).get("classification", {}).get("adaptive_threshold", 0.6),
        classification_timeout_s=classifier_cfg.get("escalation", {}).get("classification", {}).get("timeout_s", 30),
        iteration_threshold=classifier_cfg.get("escalation", {}).get("iteration", {}).get("adaptive_threshold", 0.5),
        iteration_timeout_s=classifier_cfg.get("escalation", {}).get("iteration", {}).get("timeout_s", 30),
        hook_failure_threshold=classifier_cfg.get("escalation", {}).get("hook_failure", {}).get("adaptive_threshold", 0.5),
        hook_failure_timeout_s=classifier_cfg.get("escalation", {}).get("hook_failure", {}).get("timeout_s", 15),
    )
    iter_cfg = IterationConfig(
        reclassify_threshold=classifier_cfg.get("iteration", {}).get("reclassify_threshold", 0.5),
    )

    user_interactor = StateBackedUserInteractor(state_store)
    backends = {
        "mini-agent": MiniAgentBackend(agent_runner),
        "llm-direct": LLMDirectBackend(direct_llm_handler),
        "claude-code": ClaudeCodeBackend(),
    }
    worker_pool = await WorkerPool.from_config(CONFIG_DIR / "workers.yaml", backends, event_bus=event_bus)
    scheduler = Scheduler(worker_pool, observer.breakers.reader(), queue_capacity=20)
    runtime = WorkflowRuntime(
        scheduler=scheduler,
        state_store=state_store,
        event_bus=event_bus,
        llm_service=llm_service,
        user_interactor=user_interactor,
    )
    active_tasks = ActiveTaskRegistry()
    hooks = [
        ResourcePreflight(workflow_registry, worker_pool),
        KnowledgeLoader(),
    ]
    hook_runner = HookRunner(hooks, user_interactor, esc_cfg)
    iteration_strategy = IterationStrategy(iter_cfg, esc_cfg, user_interactor)
    command_handler = CommandHandler(
        state_store=state_store,
        event_bus=event_bus,
        active_tasks=active_tasks,
        worker_pool=worker_pool,
        observer=observer,
    )
    reconciler = Reconciler(
        classifier=classifier,
        workflow_registry=workflow_registry,
        workflow_runtime=runtime,
        state_store=state_store,
        event_bus=event_bus,
        user_interactor=user_interactor,
        active_tasks=active_tasks,
        hook_runner=hook_runner,
        iteration_strategy=iteration_strategy,
        confirmation_mode=classifier_cfg.get("confirmation_mode", "auto"),
        escalation_config=esc_cfg,
    )
    controller = TaskController(command_handler, reconciler, state_store)
    gateway = Gateway(event_bus)

    orch = Orchestrator(
        registry=registry,
        gateway=gateway,
        controller=controller,
        observer=observer,
        state_store=state_store,
        error_service=error_service,
    )
    await orch.event_bus.replay_fallback()
    await reconciler.recover()
    return orch
