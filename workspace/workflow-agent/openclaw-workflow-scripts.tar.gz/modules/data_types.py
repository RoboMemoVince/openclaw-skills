"""
Backward-compatible re-export hub.

All public symbols that previously lived in this monolithic file are now
split across focused modules:

  core_types.py      -- ErrorCategory, SubTaskState, TaskRequest, SubTask, ...
  shared_context.py  -- SharedContext
  scheduling.py      -- ExecutionQueue, AgentSlot, AgentPool
  resilience.py      -- CircuitBreaker, CircuitBreakerRegistry, DeadLetterQueue
  observability.py   -- EventBus, TaskTrace, Span

Import from here for backward compatibility, or import directly from the
new modules for clarity.
"""

# ── core data types ──────────────────────────────────────────────
from modules.core_types import (  # noqa: F401
    Phase,
    Priority,
    ErrorCategory,
    SubTaskState,
    TaskEnvelope,
    TaskRequest,
    TaskStep,
    SubTask,
    Assignment,
    StepResult,
    ReviewedResult,
    WorkflowResult,
    WorkerAssignment,
    ClassifyResult,
    EscalatableDecision,
    EscalationConfig,
    IterationConfig,
    CRASH_MARKERS,
    DEGRADED_PREFIX,
    FAILED_PREFIX,
    make_degraded_value,
    make_failed_value,
    is_degraded_or_failed,
)

# ── shared context ───────────────────────────────────────────────
from modules.shared_context import SharedContext  # noqa: F401

# ── scheduling infrastructure ────────────────────────────────────
from modules.scheduling import (  # noqa: F401
    ExecutionQueue,
    AgentSlot,
    AgentPool,
)

# ── resilience infrastructure ────────────────────────────────────
from modules.resilience import (  # noqa: F401
    BreakerState,
    CircuitBreaker,
    CircuitBreakerRegistry,
    BreakerStateReader,
    DeadLetterQueue,
)

# ── observability ────────────────────────────────────────────────
from modules.observability import (  # noqa: F401
    EventBus,
    TaskTrace,
    Span,
)
