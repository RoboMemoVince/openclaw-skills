"""
Agent backend adapters for the new worker runtime.
"""

from __future__ import annotations

from typing import Any, List, Optional


class AgentBackend:
    """
    @description Agent 执行后端接口。
    """

    name: str = "unknown"

    async def run(
        self,
        task: str,
        workspace: str,
        timeout: int,
        *,
        agent_type: str = "executor",
        mcp_groups: Optional[List[str]] = None,
    ) -> dict:
        raise NotImplementedError


class MiniAgentBackend(AgentBackend):
    """
    @description 包装现有 AgentRunner 的 mini-agent 后端。
    """

    name = "mini-agent"

    def __init__(self, runner: Any):
        self._runner = runner

    async def run(
        self,
        task: str,
        workspace: str,
        timeout: int,
        *,
        agent_type: str = "executor",
        mcp_groups: Optional[List[str]] = None,
    ) -> dict:
        if self._runner is None:
            return {"returncode": -1, "stdout": "", "stderr": "agent runner unavailable", "pid": None}
        if getattr(self._runner, "_mcp", None) is not None and mcp_groups:
            await self._runner._mcp.prepare(task, list(mcp_groups))
        raw = await self._runner._run_subprocess(
            task=f"[{agent_type}] {task}",
            workspace=workspace,
            timeout=timeout,
        )
        raw["stdout"] = self._runner._clean(raw.get("stdout", ""))
        return raw


class LLMDirectBackend(AgentBackend):
    """
    @description 包装现有 DirectLLMHandler 的 LLM 直答后端。
    """

    name = "llm-direct"

    def __init__(self, handler: Any):
        self._handler = handler
        self._tool_cache: Optional[List[dict]] = None

    async def run(
        self,
        task: str,
        workspace: str,
        timeout: int,
        *,
        agent_type: str = "executor",
        mcp_groups: Optional[List[str]] = None,
    ) -> dict:
        if self._handler is None:
            return {"returncode": -1, "stdout": "", "stderr": "llm backend unavailable", "pid": None}

        tools = None
        if getattr(self._handler, "_mcp", None) is not None:
            if self._tool_cache is None:
                try:
                    self._tool_cache = await self._handler._mcp.list_tools()
                except Exception:
                    self._tool_cache = []
            tools = self._tool_cache or None

        result = await self._handler._tool_loop(task, tools)
        output = result.get("output", "")
        if output:
            return {
                "returncode": 0,
                "stdout": output,
                "stderr": "",
                "pid": None,
                "tool_calls_count": result.get("tool_calls_count", 0),
            }
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": result.get("error", "llm backend returned empty output"),
            "pid": None,
            "tool_calls_count": result.get("tool_calls_count", 0),
        }


class ClaudeCodeBackend(AgentBackend):
    """
    @description 预留的 Claude Code 后端。
    """

    name = "claude-code"

    async def run(
        self,
        task: str,
        workspace: str,
        timeout: int,
        *,
        agent_type: str = "executor",
        mcp_groups: Optional[List[str]] = None,
    ) -> dict:
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": "claude-code backend is not implemented",
            "pid": None,
        }
