"""
Worker runtime primitives for the new scheduler.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml
except ImportError:  # pragma: no cover - optional dependency
    yaml = None  # type: ignore

from modules.data_types import ErrorCategory, StepResult, TaskStep

_DEFAULT_OPENCLAW_HOME = Path(os.environ.get("OPENCLAW_HOME", str(Path.home() / ".openclaw")))
_DEFAULT_WORKER_CONFIG = {
    "workers": [
        {
            "id": "alpha",
            "workspace": str(_DEFAULT_OPENCLAW_HOME / "workspace"),
            "backend": "mini-agent",
            "labels": {
                "mcp.file": "true",
                "mcp.bash": "true",
                "mcp.search": "true",
                "mcp.memory": "true",
            },
            "capacity": 2,
        },
        {
            "id": "beta",
            "workspace": str(_DEFAULT_OPENCLAW_HOME / "workspace-worker"),
            "backend": "mini-agent",
            "labels": {
                "mcp.file": "true",
                "mcp.database": "true",
                "mcp.bash": "true",
            },
            "capacity": 2,
        },
        {
            "id": "gamma",
            "workspace": str(_DEFAULT_OPENCLAW_HOME / "workspace-reviewer"),
            "backend": "mini-agent",
            "labels": {"review": "true", "mcp.memory": "true"},
            "capacity": 1,
        },
        {
            "id": "instant",
            "workspace": "",
            "backend": "llm-direct",
            "labels": {"instant": "true"},
            "capacity": 5,
        },
    ]
}


def _classify_error(error: str, returncode: int) -> ErrorCategory:
    """
    @description 按错误文本和退出码推断 ErrorCategory。
    @param {str} error
    @param {int} returncode
    @returns {ErrorCategory}
    """

    low = (error or "").lower()
    if returncode == -1 or "timeout" in low:
        return ErrorCategory.TRANSIENT
    for keyword in ("connection", "429", "503", "econnrefused", "etimedout"):
        if keyword in low:
            return ErrorCategory.TRANSIENT
    for keyword in ("authentication", "unauthorized", "401", "403", "permission denied", "404"):
        if keyword in low:
            return ErrorCategory.PERMANENT
    if "mcp" in low and ("not found" in low or "not installed" in low):
        return ErrorCategory.DEGRADABLE
    return ErrorCategory.TRANSIENT


class WorkerStatus(Enum):
    """
    @description Worker 槽位状态。
    """

    IDLE = "idle"
    BUSY = "busy"
    DRAINING = "draining"
    OFFLINE = "offline"


class Worker:
    """
    @description 纯执行单元，通过 AgentBackend 执行单个步骤。
    """

    def __init__(self, worker_id: str, workspace: str, backend: Any, labels: Dict[str, str]):
        self.id = worker_id
        self.workspace = workspace
        self.backend = backend
        self.labels = labels
        self._success_count = 0
        self._total_count = 0
        self._last_heartbeat = datetime.now()

    @property
    def success_rate(self) -> float:
        """
        @description 返回执行成功率。
        @returns {float}
        """

        if self._total_count <= 0:
            return 1.0
        return self._success_count / self._total_count

    async def execute(self, step: TaskStep) -> StepResult:
        """
        @description 调用 backend.run() 执行步骤。
        @param {TaskStep} step
        @returns {StepResult}
        """

        self._total_count += 1
        started_at = datetime.now()
        raw = await self.backend.run(
            step.prompt,
            self.workspace,
            step.timeout,
            agent_type=step.agent_type,
            mcp_groups=step.mcp_groups,
        )
        duration = (datetime.now() - started_at).total_seconds()
        returncode = int(raw.get("returncode", -1))
        stdout = str(raw.get("stdout", "")).strip()
        stderr = str(raw.get("stderr", "")).strip()
        success = returncode == 0 and bool(stdout)
        if success:
            self._success_count += 1
            passed, feedback = self._extract_review_status(step, stdout)
            return StepResult(
                step_name=step.name,
                agent_type=step.agent_type,
                output=stdout,
                success=True,
                duration=duration,
                mcp_groups=list(step.mcp_groups),
                returncode=returncode,
                passed=passed,
                feedback=feedback,
            )
        return StepResult(
            step_name=step.name,
            agent_type=step.agent_type,
            output="",
            success=False,
            duration=duration,
            error=stderr or "worker execution failed",
            error_category=_classify_error(stderr or "worker execution failed", returncode),
            mcp_groups=list(step.mcp_groups),
            returncode=returncode,
        )

    async def heartbeat(self) -> dict:
        """
        @description 更新并返回心跳信息。
        @returns {dict}
        """

        self._last_heartbeat = datetime.now()
        return {
            "worker_id": self.id,
            "workspace": self.workspace,
            "labels": dict(self.labels),
            "success_rate": self.success_rate,
            "timestamp": self._last_heartbeat.isoformat(),
        }

    @staticmethod
    def _extract_review_status(step: TaskStep, output: str) -> tuple[bool, str]:
        """
        @description 从 reviewer 步骤输出中提取 passed / feedback。
        @param {TaskStep} step
        @param {str} output
        @returns {tuple[bool, str]}
        """

        if step.agent_type != "reviewer":
            return True, ""

        normalized = output.strip()
        first_line = normalized.splitlines()[0].strip().lower() if normalized else ""
        if first_line.startswith("pass"):
            return True, normalized
        if first_line.startswith("fail"):
            return False, normalized
        if "结论: 通过" in normalized or "审核通过" in normalized:
            return True, normalized
        if "结论: 不通过" in normalized or "审核不通过" in normalized:
            return False, normalized
        return True, normalized


class WorkerSlot:
    """
    @description Worker 容量槽位，使用信号量控制并发。
    """

    def __init__(self, worker: Worker, capacity: int = 2):
        self.worker = worker
        self.capacity = max(1, capacity)
        self.status = WorkerStatus.IDLE
        self.active_count = 0
        self._semaphore = asyncio.Semaphore(self.capacity)

    def has_capacity(self) -> bool:
        """
        @description 判断当前槽位是否还有可用容量。
        @returns {bool}
        """

        return self.status not in {WorkerStatus.DRAINING, WorkerStatus.OFFLINE} and self.active_count < self.capacity

    async def acquire(self, timeout: float) -> None:
        """
        @description 获取一个执行容量。
        @param {float} timeout
        @returns {None}
        """

        await asyncio.wait_for(self._semaphore.acquire(), timeout=timeout)
        self.active_count += 1
        self.status = WorkerStatus.BUSY if self.active_count > 0 else WorkerStatus.IDLE

    async def release(self) -> None:
        """
        @description 释放一个执行容量。
        @returns {None}
        """

        if self.active_count > 0:
            self.active_count -= 1
        self._semaphore.release()
        if self.status != WorkerStatus.OFFLINE:
            self.status = WorkerStatus.BUSY if self.active_count > 0 else WorkerStatus.IDLE

    async def execute_and_release(self, step: TaskStep) -> StepResult:
        """
        @description 执行步骤并确保最终释放槽位。
        @param {TaskStep} step
        @returns {StepResult}
        """

        try:
            return await self.worker.execute(step)
        finally:
            await self.release()


class WorkerPool:
    """
    @description WorkerSlot 注册、查询和健康检查。
    """

    def __init__(self, event_bus: Any = None):
        self._slots: Dict[str, WorkerSlot] = {}
        self._heartbeats: Dict[str, datetime] = {}
        self._health_task: Optional[asyncio.Task] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._event_bus = event_bus

    async def register(self, worker: Worker, capacity: int = 2) -> None:
        self._slots[worker.id] = WorkerSlot(worker, capacity=capacity)
        self._heartbeats[worker.id] = datetime.now()

    async def deregister(self, worker_id: str) -> None:
        self._slots.pop(worker_id, None)
        self._heartbeats.pop(worker_id, None)

    def filter_available(self, requirements: Dict[str, str]) -> List[WorkerSlot]:
        """
        @description 标签匹配：状态可用、容量可用、labels 超集。
        @param {dict[str, str]} requirements
        @returns {list[WorkerSlot]}
        """

        candidates = []
        for slot in self._slots.values():
            if slot.status in {WorkerStatus.OFFLINE, WorkerStatus.DRAINING}:
                continue
            if not slot.has_capacity():
                continue
            if all(slot.worker.labels.get(key) == value for key, value in requirements.items()):
                candidates.append(slot)
        return candidates

    def mark_offline(self, worker_id: str) -> None:
        """
        @description 将指定 Worker 标记为离线。
        @param {str} worker_id
        @returns {None}
        """

        slot = self._slots.get(worker_id)
        if slot is not None:
            slot.status = WorkerStatus.OFFLINE

    def record_heartbeat(self, worker_id: str) -> None:
        """
        @description 记录 Worker 心跳时间。
        @param {str} worker_id
        @returns {None}
        """

        self._heartbeats[worker_id] = datetime.now()
        slot = self._slots.get(worker_id)
        if slot is not None and slot.status == WorkerStatus.OFFLINE:
            slot.status = WorkerStatus.IDLE if slot.active_count == 0 else WorkerStatus.BUSY

    def slots(self) -> List[WorkerSlot]:
        """
        @description 返回全部 WorkerSlot。
        @returns {list[WorkerSlot]}
        """

        return list(self._slots.values())

    def summary(self) -> dict:
        """
        @description 返回 WorkerPool 摘要信息。
        @returns {dict}
        """

        offline = sum(1 for slot in self._slots.values() if slot.status == WorkerStatus.OFFLINE)
        active = sum(slot.active_count for slot in self._slots.values())
        return {
            "total": len(self._slots),
            "offline": offline,
            "active": active,
        }

    def start_health_check_loop(self, timeout_s: int = 30) -> None:
        """
        @description 启动后台健康检查循环。
        @param {int} timeout_s
        @returns {None}
        """

        if self._health_task is None or self._health_task.done():
            self._health_task = asyncio.create_task(self._health_check_loop(timeout_s))
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop_health_check_loop(self) -> None:
        """
        @description 停止后台健康检查循环。
        @returns {None}
        """

        if self._health_task is not None and not self._health_task.done():
            self._health_task.cancel()
            try:
                await self._health_task
            except asyncio.CancelledError:
                pass
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

    async def _health_check_loop(self, timeout_s: int) -> None:
        while True:
            await asyncio.sleep(5)
            now = datetime.now()
            for worker_id, heartbeat_at in list(self._heartbeats.items()):
                age = (now - heartbeat_at).total_seconds()
                if age > timeout_s:
                    self.mark_offline(worker_id)
                    if self._event_bus is not None:
                        await self._event_bus.emit("worker_offline", {"worker_id": worker_id, "age": age})

    async def _heartbeat_loop(self) -> None:
        """
        @description 周期性拉取 Worker 心跳并 emit 事件。
        @returns {None}
        """

        while True:
            await asyncio.sleep(10)
            for worker_id, slot in list(self._slots.items()):
                try:
                    info = await slot.worker.heartbeat()
                    self.record_heartbeat(worker_id)
                    if self._event_bus is not None:
                        await self._event_bus.emit("worker_heartbeat", info)
                except Exception:
                    self.mark_offline(worker_id)
                    if self._event_bus is not None:
                        await self._event_bus.emit("worker_offline", {"worker_id": worker_id})

    @classmethod
    async def from_config(cls, config_path: Path, backends: Dict[str, Any], event_bus: Any = None) -> "WorkerPool":
        """
        @description 从 workers.yaml 构建 WorkerPool。
        @param {Path} config_path
        @param {dict[str, Any]} backends
        @returns {WorkerPool}
        """

        pool = cls(event_bus=event_bus)
        if yaml is None or not config_path.exists():
            config = dict(_DEFAULT_WORKER_CONFIG)
        else:
            with open(config_path, "r", encoding="utf-8") as file:
                config = yaml.safe_load(file) or dict(_DEFAULT_WORKER_CONFIG)
        for item in config.get("workers", []):
            backend_name = item.get("backend", "mini-agent")
            backend = backends.get(backend_name)
            if backend is None:
                continue
            worker = Worker(
                worker_id=item["id"],
                workspace=item.get("workspace", str(Path.home())),
                backend=backend,
                labels=item.get("labels", {}),
            )
            await pool.register(worker, capacity=int(item.get("capacity", 1)))
        pool.start_health_check_loop()
        return pool
