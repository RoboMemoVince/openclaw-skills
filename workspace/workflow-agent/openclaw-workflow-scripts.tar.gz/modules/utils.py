"""
Shared utilities used across multiple modules.
"""

from __future__ import annotations

import re
from typing import Set


class SafeDict(dict):
    """``str.format_map`` helper that keeps missing keys as ``{key}``."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


_PLACEHOLDER_RE = re.compile(r"\{(\w+)\}")


def extract_placeholders(template: str) -> Set[str]:
    """Return all ``{name}`` placeholder names found in *template*."""
    return set(_PLACEHOLDER_RE.findall(template))
