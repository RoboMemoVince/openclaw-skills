"""
SharedContext -- orchestrator-level in-process KV store for inter-subtask
data passing, with checkpoint/restore for crash recovery.

**Not** accessible from AgentRunner child processes.  The Orchestrator /
ExecutionEngine reads stdout from child processes and calls ``put()`` on
behalf of each runner.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Set

logger = logging.getLogger("openclaw.shared_context")


class SharedContext:
    """
    In-process key-value store for inter-subtask data passing.

    Concurrency: per-key asyncio.Lock to allow parallel reads while
    serialising writes to the same key.

    @method put        Write a value (notifies waiters).
    @method get        Non-blocking read with default.
    @method wait_for   Block until a key appears (with timeout).
    @method snapshot   Return a shallow copy of the entire store.
    @method checkpoint Persist to disk for crash recovery.
    @method restore    Load from a previous checkpoint file.
    """

    _IDEMPOTENCY_STORE_KEY = "_completed_idempotency_keys"
    _PLAN_SIGNATURE_KEY = "_plan_signature"

    def __init__(self) -> None:
        self._store: Dict[str, Any] = {}
        self._key_locks: Dict[str, asyncio.Lock] = {}
        self._events: Dict[str, asyncio.Event] = {}
        self._global_lock = asyncio.Lock()
        self._completed_idem_keys: Set[str] = set()

    async def _get_or_create_lock(self, key: str) -> asyncio.Lock:
        async with self._global_lock:
            if key not in self._key_locks:
                self._key_locks[key] = asyncio.Lock()
            return self._key_locks[key]

    async def put(self, key: str, value: Any) -> None:
        """Write *value* under *key* and wake any ``wait_for`` waiters."""
        lock = await self._get_or_create_lock(key)
        async with lock:
            self._store[key] = value
        async with self._global_lock:
            if key in self._events:
                self._events[key].set()

    async def get(self, key: str, default: Any = None) -> Any:
        """Non-blocking read."""
        return self._store.get(key, default)

    async def wait_for(self, key: str, timeout: float = 60) -> Optional[Any]:
        """Block until *key* is written.  Returns None on timeout."""
        async with self._global_lock:
            if key in self._store:
                return self._store[key]
            if key not in self._events:
                self._events[key] = asyncio.Event()
            event = self._events[key]
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            return None
        return self._store.get(key)

    def snapshot(self) -> Dict[str, Any]:
        """Shallow copy -- safe for prompt rendering."""
        return dict(self._store)

    def done_keys(self) -> Set[str]:
        """Keys that have been written (used for dependency checks)."""
        return set(self._store.keys())

    def record_completed(self, idempotency_key: str) -> None:
        """Mark a subtask's idempotency key as completed for crash-recovery dedup."""
        if idempotency_key:
            self._completed_idem_keys.add(idempotency_key)

    def is_completed(self, idempotency_key: str) -> bool:
        """Check whether a subtask was already executed (by idempotency key)."""
        return bool(idempotency_key) and idempotency_key in self._completed_idem_keys

    async def checkpoint(
        self, path: Path, *, plan_signature: str = "",
    ) -> None:
        """
        Serialise store + idempotency keys + plan signature to JSON for
        crash recovery.

        @param {Path} path
        @param {str} plan_signature - opaque hash identifying the subtask plan
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        serialisable = {}
        for k, v in self._store.items():
            try:
                json.dumps(v)
                serialisable[k] = v
            except (TypeError, ValueError):
                serialisable[k] = str(v)
        serialisable[self._IDEMPOTENCY_STORE_KEY] = sorted(self._completed_idem_keys)
        if plan_signature:
            serialisable[self._PLAN_SIGNATURE_KEY] = plan_signature
        path.write_text(json.dumps(serialisable, ensure_ascii=False, indent=2), encoding="utf-8")

    async def restore(self, path: Path) -> None:
        """Load a previous checkpoint (including idempotency keys)."""
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            idem_keys = data.pop(self._IDEMPOTENCY_STORE_KEY, [])
            if isinstance(idem_keys, list):
                self._completed_idem_keys.update(idem_keys)
            self._plan_signature = data.pop(self._PLAN_SIGNATURE_KEY, "")
            self._store.update(data)
            for key in data:
                async with self._global_lock:
                    if key in self._events:
                        self._events[key].set()

    @property
    def restored_plan_signature(self) -> str:
        """Plan signature read from the last ``restore()`` call, or empty."""
        return getattr(self, "_plan_signature", "")
