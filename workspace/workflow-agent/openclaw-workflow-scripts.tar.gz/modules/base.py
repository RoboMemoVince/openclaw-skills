"""
Module base class -- every Layer 1 module and Layer 2 service inherits this.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry


class ModuleBase(ABC):
    """
    @abstract
    All modules/services must subclass this and implement *name*, *version*,
    and *initialize*.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique module identifier (must match the key in module-registry.yaml)."""
        ...

    @property
    @abstractmethod
    def version(self) -> str:
        ...

    @property
    def dependencies(self) -> List[str]:
        """Names of modules/services this module depends on."""
        return []

    @abstractmethod
    async def initialize(self, registry: ModuleRegistry) -> None:
        """Called once after all modules are instantiated, in dependency order."""
        ...

    async def shutdown(self) -> None:
        """Optional cleanup hook."""
        pass

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name} v={self.version}>"
