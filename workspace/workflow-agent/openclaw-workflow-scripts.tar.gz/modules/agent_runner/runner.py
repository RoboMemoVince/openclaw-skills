"""
AgentRunner -- unified mini-agent subprocess execution with integrated retry.

Merges the responsibilities of:
  - TaskExecutor   (subprocess launch, MCP pre-check, output cleaning)
  - RetryService   (exponential backoff, error classification, delay calc)

Single entry point: ``run(assignment) -> StepResult``.
"""

from __future__ import annotations

import asyncio
import os
import random
import re
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from modules.base import ModuleBase
from modules.data_types import Assignment, StepResult, ErrorCategory, SubTaskState

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m|\x1b\][^\x1b]*")
_MINI_AGENT = os.getenv("MINI_AGENT_PATH", "mini-agent")

# Retry parameters (previously in RetryService)
_BASE_DELAY = 2.0
_MAX_DELAY = 60.0
_EXP_BASE = 2.0
_JITTER = 0.5
_OUTPUT_MAX_LINES = int(os.getenv("OPENCLAW_OUTPUT_MAX_LINES", "50"))


def _classify_error(error: str, returncode: int) -> ErrorCategory:
    """Map an error string + returncode to an ErrorCategory."""
    low = error.lower()
    if returncode == -1 or "timeout" in low:
        return ErrorCategory.TRANSIENT
    for kw in ("connection", "429", "503", "econnrefused", "etimedout"):
        if kw in low:
            return ErrorCategory.TRANSIENT
    for kw in ("authentication", "unauthorized", "401", "403", "permission denied", "404"):
        if kw in low:
            return ErrorCategory.PERMANENT
    if "mcp" in low and ("not found" in low or "not installed" in low):
        return ErrorCategory.DEGRADABLE
    return ErrorCategory.TRANSIENT


def _retry_delay(attempt: int) -> float:
    """Exponential backoff with jitter.  *attempt* is 1-based."""
    delay = _BASE_DELAY * (_EXP_BASE ** (attempt - 1))
    delay = min(delay, _MAX_DELAY)
    return max(0, delay + random.uniform(-_JITTER, _JITTER))


class AgentRunner(ModuleBase):
    """
    Runs a mini-agent subprocess for a single Assignment, with built-in
    retry (exponential backoff) and error classification.

    @method run  Execute an assignment and return a StepResult.
    """

    @property
    def name(self) -> str:
        return "agent_runner"

    @property
    def version(self) -> str:
        return "1.0"

    @property
    def dependencies(self) -> List[str]:
        return ["mcp_service"]

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._mcp = registry.get("mcp_service")

    async def run(self, assignment: Assignment) -> StepResult:
        """
        Execute the assignment with retry on transient errors.

        @param {Assignment} assignment
        @returns {StepResult}
        """
        st = assignment.subtask

        if self._mcp and st.mcp_groups:
            await self._mcp.prepare(st.prompt, st.mcp_groups)

        max_attempts = st.max_retries + 1
        last_err = ""
        last_cat: Optional[ErrorCategory] = None
        duration = 0.0
        rc = -1
        self._last_pid: Optional[int] = None

        for attempt in range(1, max_attempts + 1):
            if attempt > 1:
                st.state = SubTaskState.RETRY_EXEC
                delay = _retry_delay(attempt)
                await asyncio.sleep(delay)

            start = datetime.now()
            res = await self._run_subprocess(
                task=f"[{st.agent_type}] {st.prompt}",
                workspace=assignment.workspace,
                timeout=st.timeout,
            )
            duration = (datetime.now() - start).total_seconds()

            stdout = res.get("stdout", "")
            stderr = res.get("stderr", "")
            rc = res.get("returncode", -1)
            self._last_pid = res.get("pid")

            success = (
                rc == 0
                or "Session Statistics" in stdout
                or "Session Duration" in stdout
            )
            if success:
                return StepResult(
                    step_name=st.step_name, agent_type=st.agent_type,
                    output_key=st.output_key,
                    output=self._clean(stdout), success=True,
                    duration=duration, mcp_groups=st.mcp_groups, returncode=rc,
                )

            last_err = stderr or stdout[-500:] or "unknown error"
            last_cat = _classify_error(last_err, rc)

            if last_cat in (ErrorCategory.PERMANENT, ErrorCategory.DEGRADABLE):
                break

        return StepResult(
            step_name=st.step_name, agent_type=st.agent_type,
            output_key=st.output_key, output="",
            success=False, duration=duration,
            error=last_err, error_category=last_cat,
            mcp_groups=st.mcp_groups, returncode=rc,
        )

    # ── alias for backward compat with ExecutionEngine ────────────

    async def execute(self, assignment: Assignment) -> StepResult:
        """Backward-compatible alias for ``run()``."""
        return await self.run(assignment)

    # ── subprocess ────────────────────────────────────────────────

    @staticmethod
    async def _run_subprocess(task: str, workspace: str, timeout: int) -> dict:
        """
        Launch mini-agent subprocess.

        @returns {dict} with keys: returncode, stdout, stderr, pid
        """
        cmd = ["uv", "run", "mini-agent", "--workspace", workspace, "--task", task]
        if not os.path.exists(str(Path.home() / ".local" / "bin" / "uv")):
            cmd = [_MINI_AGENT, "--workspace", workspace, "--task", task]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=workspace,
            )
            pid = proc.pid
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout,
            )
            return {
                "returncode": proc.returncode,
                "stdout": stdout.decode("utf-8", errors="ignore"),
                "stderr": stderr.decode("utf-8", errors="ignore"),
                "pid": pid,
            }
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return {"returncode": -1, "stdout": "", "stderr": f"timeout ({timeout}s)", "pid": proc.pid}
        except FileNotFoundError:
            return {"returncode": -2, "stdout": "", "stderr": "mini-agent not found", "pid": None}
        except Exception as e:
            return {"returncode": -3, "stdout": "", "stderr": str(e), "pid": None}

    # ── output cleaning ───────────────────────────────────────────

    @staticmethod
    def _clean(output: str) -> str:
        """Strip ANSI codes and keep only meaningful lines."""
        lines = output.split("\n")
        cleaned = []
        for line in lines:
            stripped = _ANSI_RE.sub("", line)
            if not stripped.strip():
                continue
            if any(stripped.startswith(p) for p in (
                "Loading", "╭─", "╰─", "│", "Step ", "Session ",
                "─", "Traceback", "Warning:", "LLM Request", "LLM Response",
            )):
                continue
            cleaned.append(stripped)
        return "\n".join(cleaned[-_OUTPUT_MAX_LINES:]) if cleaned else ""
