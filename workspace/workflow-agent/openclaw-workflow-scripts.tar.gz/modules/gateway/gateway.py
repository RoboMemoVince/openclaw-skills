"""
Gateway for protocol adaptation, validation, and result delivery.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from modules.data_types import Priority, TaskEnvelope


class Gateway:
    """
    @description 协议适配层 + 结果投递（含自管理重试）。
    """

    def __init__(self, event_bus, channel_dispatchers: Dict[str, Any] | None = None, max_retries: int = 3):
        self._event_bus = event_bus
        self._dispatchers = channel_dispatchers or {}
        self._max_retries = max_retries

    async def receive(self, raw: dict, channel: str | None = None) -> TaskEnvelope:
        """
        @description 接收原始输入并标准化为 TaskEnvelope。
        @param {dict} raw
        @param {str | None} channel
        @returns {TaskEnvelope}
        """

        envelope = self._adapt(raw, channel or raw.get("source", "cli"))
        self._validate(envelope)
        return envelope

    async def deliver(self, envelope: TaskEnvelope, result: dict) -> bool:
        """
        @description 按原渠道回传结果，自带指数退避重试。
        @param {TaskEnvelope} envelope
        @param {dict} result
        @returns {bool}
        """

        last_error = ""
        for attempt in range(self._max_retries + 1):
            try:
                await self._dispatch(envelope.channel, envelope, result)
                return True
            except Exception as error:
                last_error = str(error)
                if attempt < self._max_retries:
                    await asyncio.sleep(2 ** attempt)
        await self._event_bus.emit(
            "delivery_exhausted",
            {
                "task_id": envelope.task_id,
                "channel": envelope.channel,
                "error": last_error,
                "attempts": self._max_retries + 1,
            },
        )
        return False

    @staticmethod
    def _adapt(raw: dict, channel: str) -> TaskEnvelope:
        """
        @description 将外部输入适配为 TaskEnvelope。
        @param {dict} raw
        @param {str} channel
        @returns {TaskEnvelope}
        """

        content = (raw.get("content") or "").strip()
        command = ""
        parsed_args = ""
        if content.startswith("/"):
            parts = content.split(maxsplit=1)
            command = parts[0]
            parsed_args = parts[1] if len(parts) > 1 else ""

        return TaskEnvelope(
            task_id=raw.get("message_id") or raw.get("task_id") or f"task_{uuid.uuid4().hex[:12]}",
            content=content,
            user_id=raw.get("user_id", ""),
            source=channel,
            command=command,
            parsed_args=parsed_args,
            workspace=raw.get("workspace") or str(Path.home()),
            timeout=int(raw.get("timeout", 600)),
            priority=Priority.P0_REALTIME if channel in {"feishu", "bridge", "cli"} else Priority.P1_BACKGROUND,
            metadata={
                key: value
                for key, value in raw.items()
                if key not in {"content", "user_id", "source", "workspace", "timeout", "message_id", "task_id"}
            },
            created_at=datetime.now(),
        )

    @staticmethod
    def _validate(envelope: TaskEnvelope) -> None:
        """
        @description 基础准入校验。
        @param {TaskEnvelope} envelope
        @returns {None}
        """

        if not envelope.content:
            raise ValueError("task content is empty")
        if envelope.timeout <= 0:
            raise ValueError("timeout must be positive")

    async def _dispatch(self, channel: str, envelope: TaskEnvelope, result: dict) -> None:
        """
        @description 调用渠道分发器投递结果，无分发器时视为本地成功。
        @param {str} channel
        @param {TaskEnvelope} envelope
        @param {dict} result
        @returns {None}
        """

        dispatcher = self._dispatchers.get(channel)
        if dispatcher is None:
            return
        if asyncio.iscoroutinefunction(dispatcher):
            await dispatcher(envelope, result)
        else:
            dispatcher(envelope, result)
