"""
ExecutionEngine -- the data-plane that owns the execute→validate→context loop.

Split from Orchestrator (control-plane) per L1.  The Orchestrator dispatches
subtask lists here and receives aggregated round results back.  Iteration
control (plan_iteration) stays in the Orchestrator so the data-plane never
calls back into the control-plane.

Responsibilities:
  - Runtime prompt rendering (L0 data-loop fix)
  - Review-feedback retry loop (L0 control-loop fix)
  - Degraded-context fill (L0 control-loop fix)
  - Dependency-aware batching via ExecutionQueue (L0 logic fix)
  - Timeout budget propagation (L2)
  - Backpressure (L2, delegated to ExecutionQueue)
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from modules.data_types import (
    SubTask, SubTaskState, StepResult, ReviewedResult,
    Assignment, ErrorCategory, SharedContext, ExecutionQueue,
    AgentSlot, AgentPool, CircuitBreakerRegistry, DeadLetterQueue, EventBus,
    make_degraded_value, make_failed_value, is_degraded_or_failed,
)
from modules.utils import SafeDict

logger = logging.getLogger("openclaw.execution_engine")


# ── Failure-handling policy ───────────────────────────────────────

class FailureAction:
    """Enum-like constants returned by FailurePolicy."""
    DEGRADE = "degrade"
    LLM_FALLBACK = "llm_fallback"
    DLQ = "dlq"
    FAIL_SILENT = "fail_silent"
    ABORT = "abort"


class FailurePolicy:
    """
    Pluggable strategy that decides how to handle a failed subtask.

    Override ``decide()`` to implement custom failure-handling logic
    (e.g. always escalate certain agent_types, or skip LLM fallback
    during peak hours).
    """

    def decide(
        self,
        subtask: SubTask,
        reviewed: ReviewedResult,
        *,
        has_llm: bool = False,
    ) -> str:
        """
        Return a FailureAction constant.

        @param {SubTask} subtask
        @param {ReviewedResult} reviewed
        @param {bool} has_llm - whether an LLM service is available for fallback
        @returns {str} one of FailureAction constants
        """
        cat = reviewed.result.error_category
        if cat == ErrorCategory.DEGRADABLE and not subtask.required:
            return FailureAction.DEGRADE
        if subtask.required and has_llm:
            return FailureAction.LLM_FALLBACK
        if not subtask.required:
            return FailureAction.FAIL_SILENT
        return FailureAction.ABORT


class ExecutionEngine:
    """
    Data-plane: execute a list of subtasks, respecting dependencies, and
    return the aggregated results for one round.

    @param executor   TaskExecutor module (runs subprocess).
    @param reviewer   TaskReviewer module (validates result).
    @param agents     Agent config list for the AgentPool.
    @param llm_service  Optional LLM service for fallback on critical step failures.
    @param max_concurrent  Global concurrency cap.
    @param queue_capacity  Max pending+running subtasks before backpressure kicks in.
    """

    def __init__(
        self,
        executor: Any,
        reviewer: Any = None,
        agents: Optional[List[dict]] = None,
        llm_service: Any = None,
        max_concurrent: int = 4,
        queue_capacity: int = 20,
        event_bus: Optional[EventBus] = None,
        dlq_path: str = "",
        failure_policy: Optional[FailurePolicy] = None,
        dlq_consume_callback: Optional[Any] = None,
    ):
        self._executor = executor
        self._reviewer = reviewer
        self._llm = llm_service
        self._failure_policy = failure_policy or FailurePolicy()
        self._pool = AgentPool(agents or [{"id": "main"}], max_concurrent)

        async def _on_breaker_change(service: str, old: str, new: str) -> None:
            if event_bus:
                await event_bus.emit("circuit_breaker_change", {
                    "service": service, "old_state": old, "new_state": new,
                })

        self._breakers = CircuitBreakerRegistry(on_state_change=_on_breaker_change)

        if llm_service and hasattr(llm_service, "health_check"):
            self._breakers.register_probe("llm_service", llm_service.health_check)

        if executor and hasattr(executor, "health_check"):
            self._breakers.register_probe("agent_runner", executor.health_check)
        elif executor:
            async def _agent_runner_probe() -> bool:
                """Lightweight liveness check -- verifies the executor is importable."""
                try:
                    return hasattr(executor, "execute") or hasattr(executor, "run")
                except Exception:
                    return False
            self._breakers.register_probe("agent_runner", _agent_runner_probe)

        self._mcp_service = None
        if hasattr(executor, "_mcp") and executor._mcp:
            self._mcp_service = executor._mcp
        if self._mcp_service and hasattr(self._mcp_service, "health_check"):
            async def _mcp_probe() -> bool:
                """Delegate to MCP service's built-in health check."""
                try:
                    groups = self._mcp_service.get_all_groups()
                    if not groups:
                        return True
                    return await self._mcp_service.health_check(groups[0])
                except Exception:
                    return False
            self._breakers.register_probe("mcp_service", _mcp_probe)

        self._queue_capacity = queue_capacity
        self._event_bus = event_bus
        self._dlq: Optional[DeadLetterQueue] = None
        self._dlq_scan_task: Optional[asyncio.Task] = None
        if dlq_path:
            async def _dlq_alert(msg: str) -> None:
                if event_bus:
                    await event_bus.emit("dlq_alert", {"message": msg})

            self._dlq = DeadLetterQueue(
                Path(dlq_path) / ".openclaw_dlq.jsonl",
                alert_callback=_dlq_alert,
            )
            self._dlq_scan_task = self._dlq.start_periodic_scan(
                interval_seconds=300,
                auto_consume=True,
                consume_callback=dlq_consume_callback,
            )

    # ── public entry point ────────────────────────────────────────

    async def execute_round(
        self,
        subtasks: List[SubTask],
        context: SharedContext,
        *,
        task_id: str = "",
        task_timeout: float = 600,
        checkpoint_dir: str = "",
        plan_signature: str = "",
    ) -> List[ReviewedResult]:
        """
        Execute all *subtasks* for one round, honouring dependencies.

        Returns the list of reviewed results.  The caller (Orchestrator)
        decides whether to iterate.

        @param subtasks       SubTask list for this round.
        @param context        SharedContext (already initialised with ``task`` key).
        @param task_id        For per-task pool quota.
        @param task_timeout   Overall task timeout budget.
        @param checkpoint_dir Directory for crash-recovery checkpoints.
        @param plan_signature Opaque hash for checkpoint consistency verification.
        """
        checkpoint_path: Optional[Path] = None
        if checkpoint_dir and task_id:
            checkpoint_path = Path(checkpoint_dir) / f".openclaw_checkpoint_{task_id}.json"
        elif checkpoint_dir:
            checkpoint_path = Path(checkpoint_dir) / ".openclaw_checkpoint.json"
        self._round_checkpoint_path = checkpoint_path
        self._round_plan_signature = plan_signature
        self._pool.start_watchdog()

        active_subtasks = []
        for st in subtasks:
            if context.is_completed(st.idempotency_key):
                logger.info(
                    "Skipping already-completed subtask %s (idem=%s)",
                    st.step_name, st.idempotency_key,
                )
                continue
            active_subtasks.append(st)

        queue = ExecutionQueue(active_subtasks, max_capacity=self._queue_capacity)
        results: List[ReviewedResult] = []
        start = datetime.now()

        try:
            while not queue.all_done():
                elapsed = (datetime.now() - start).total_seconds()
                remaining = task_timeout - elapsed
                if remaining <= 0:
                    logger.warning("Task timeout budget exhausted (%ss)", task_timeout)
                    break

                try:
                    batch = await queue.next_batch(max_size=self._pool._max_concurrent)
                except RuntimeError as e:
                    logger.error("Deadlock detected: %s", e)
                    break

                if not batch:
                    await asyncio.sleep(0.1)
                    continue

                coros = [
                    self._run_one(st, context, task_id=task_id, budget=remaining)
                    for st in batch
                ]
                batch_results = await asyncio.gather(*coros, return_exceptions=True)

                has_required_failure = False
                for i, item in enumerate(batch_results):
                    st = batch[i]
                    if isinstance(item, Exception):
                        logger.exception("Subtask %s raised: %s", st.step_name, item)
                        reviewed = ReviewedResult(
                            passed=False,
                            feedback=str(item),
                            result=StepResult(
                                step_name=st.step_name, agent_type=st.agent_type,
                                output_key=st.output_key, output="",
                                success=False, duration=0, error=str(item),
                                error_category=ErrorCategory.TRANSIENT,
                            ),
                        )
                    else:
                        reviewed = item

                    results.append(reviewed)

                    if reviewed.passed and reviewed.result.success:
                        await context.put(st.output_key, reviewed.result.output)
                        context.record_completed(st.idempotency_key)
                        st.state = SubTaskState.DONE
                        await queue.mark_done(st)
                        await self._maybe_checkpoint(context)
                    else:
                        action = self._failure_policy.decide(
                            st, reviewed, has_llm=bool(self._llm),
                        )
                        if action == FailureAction.DEGRADE:
                            await context.put(
                                st.output_key,
                                make_degraded_value(st.step_name, reviewed.result.error),
                            )
                            context.record_completed(st.idempotency_key)
                            st.state = SubTaskState.DEGRADED
                            await queue.mark_done(st)
                            await self._maybe_checkpoint(context)
                        elif action == FailureAction.LLM_FALLBACK:
                            fallback = await self._llm_fallback(st, context)
                            results[-1] = fallback
                            if fallback.passed:
                                await context.put(st.output_key, fallback.result.output)
                                context.record_completed(st.idempotency_key)
                                st.state = SubTaskState.DONE
                                await queue.mark_done(st)
                                await self._maybe_checkpoint(context)
                            else:
                                st.state = SubTaskState.ABORTED
                                await queue.mark_done(st)
                                await self._enqueue_dlq(task_id, st.step_name, fallback.result.error, context)
                                has_required_failure = True
                        elif action == FailureAction.FAIL_SILENT:
                            st.state = SubTaskState.FAILED
                            await context.put(
                                st.output_key,
                                make_failed_value(st.step_name, reviewed.result.error),
                            )
                            await queue.mark_done(st)
                        else:
                            st.state = SubTaskState.FAILED
                            await queue.mark_done(st)
                            has_required_failure = True

                if has_required_failure:
                    break

            self._mark_abandoned(queue, results)

        finally:
            await self._pool.stop_watchdog()

        return results

    # ── single-subtask pipeline ───────────────────────────────────

    async def _run_one(
        self,
        subtask: SubTask,
        context: SharedContext,
        *,
        task_id: str = "",
        budget: float = 600,
    ) -> ReviewedResult:
        """
        Full pipeline for one subtask: render → acquire → execute → validate.
        Includes review-feedback retry loop (L0 control-loop fix).
        """
        breaker = self._breakers.get("agent_runner")
        if not breaker.allow_request():
            waited = await self._wait_for_breaker(breaker, max_wait=min(30, budget / 3))
            if not waited:
                return self._circuit_open_result(subtask)

        await self._emit("step_started", {
            "task_id": task_id, "step_name": subtask.step_name,
            "agent_type": subtask.agent_type,
        })

        effective_timeout = min(subtask.timeout, max(30, budget - 10))

        slot = await self._pool.acquire(subtask, task_id=task_id, timeout=effective_timeout)
        try:
            reviewed = await self._execute_with_review_retry(
                subtask, context, slot, effective_timeout,
            )
        finally:
            await self._pool.release(slot)

        if reviewed.result.success:
            breaker.record_success()
        else:
            breaker.record_failure()

        event = "step_completed" if reviewed.passed else "step_failed"
        await self._emit(event, {
            "task_id": task_id, "step_name": subtask.step_name,
            "success": reviewed.result.success,
            "feedback": reviewed.feedback[:200],
        })

        return reviewed

    async def _execute_with_review_retry(
        self,
        subtask: SubTask,
        context: SharedContext,
        slot: AgentSlot,
        timeout: float,
    ) -> ReviewedResult:
        """
        Execute a subtask and, if review fails, inject feedback and retry
        up to ``subtask.max_review_retries`` times.
        """
        saved_timeout = subtask.timeout
        subtask.timeout = int(timeout)

        for review_round in range(subtask.max_review_retries + 1):
            self._render_prompt(subtask, context)
            subtask.state = SubTaskState.RUNNING

            assignment = Assignment(subtask=subtask, workspace=slot.workspace)
            step_result = await self._safe_execute(assignment, slot)

            subtask.state = SubTaskState.VALIDATING
            reviewed = await self._validate(step_result)

            if reviewed.passed:
                subtask.timeout = saved_timeout
                return reviewed

            if review_round < subtask.max_review_retries:
                subtask.state = SubTaskState.RETRY_REVIEW
                logger.info(
                    "Review retry %d/%d for %s: %s",
                    review_round + 1, subtask.max_review_retries,
                    subtask.step_name, reviewed.feedback[:120],
                )
                self._inject_feedback(subtask, context, reviewed.feedback)

        subtask.timeout = saved_timeout
        return reviewed

    # ── prompt rendering (L0 data-loop fix) ───────────────────────

    @staticmethod
    def _render_prompt(subtask: SubTask, context: SharedContext) -> None:
        """
        Re-render ``subtask.prompt`` from its ``input_template`` + live context.

        Degraded/failed upstream values are replaced with a human-readable
        placeholder so downstream prompts don't ingest raw error markers.
        """
        template = subtask.input_template or subtask.prompt
        ctx = context.snapshot()
        for key, val in ctx.items():
            if isinstance(val, str) and is_degraded_or_failed(val):
                ctx[key] = f"(上游步骤 {key} 的输出不可用，请忽略或自行补充)"
        try:
            subtask.prompt = template.format_map(SafeDict(ctx))
        except Exception:
            pass

    @staticmethod
    def _inject_feedback(subtask: SubTask, context: SharedContext, feedback: str) -> None:
        """Append review feedback so the next run incorporates corrections."""
        template = subtask.input_template or subtask.prompt
        ctx = context.snapshot()
        ctx["_review_feedback"] = feedback
        augmented = template + "\n\n[上次审核反馈] {_review_feedback}\n请根据反馈修正。"
        try:
            subtask.prompt = augmented.format_map(SafeDict(ctx))
        except Exception:
            subtask.prompt += f"\n\n[上次审核反馈] {feedback}\n请根据反馈修正。"

    # ── execution + validation ────────────────────────────────────

    async def _safe_execute(
        self, assignment: Assignment, slot: Optional[AgentSlot] = None,
    ) -> StepResult:
        """Call executor with exception guard, recording subprocess PID on slot."""
        if not self._executor:
            return StepResult(
                step_name=assignment.subtask.step_name,
                agent_type=assignment.subtask.agent_type,
                output_key=assignment.subtask.output_key,
                output="", success=False, duration=0,
                error="executor unavailable",
            )
        try:
            result = await self._executor.execute(assignment)
            if slot and hasattr(result, "returncode"):
                slot.pid = getattr(self._executor, "_last_pid", None)
            return result
        except Exception as e:
            return StepResult(
                step_name=assignment.subtask.step_name,
                agent_type=assignment.subtask.agent_type,
                output_key=assignment.subtask.output_key,
                output="", success=False, duration=0,
                error=str(e), error_category=ErrorCategory.TRANSIENT,
            )

    async def _validate(self, result: StepResult) -> ReviewedResult:
        """
        Validate execution output.  TaskReviewer is the canonical owner of
        structural checks (empty output, crash markers) + semantic review.
        When no reviewer is available, fall back to a minimal inline check.
        """
        if not result.success:
            return ReviewedResult(passed=False, feedback=result.error, result=result)
        if self._reviewer:
            try:
                return await self._reviewer.review(result)
            except Exception as e:
                logger.warning("Reviewer error, treating as pass: %s", e)
                return ReviewedResult(passed=True, feedback="reviewer_error", result=result)
        if not result.output.strip():
            return ReviewedResult(passed=False, feedback="empty output", result=result)
        return ReviewedResult(passed=True, feedback="ok", result=result)

    async def _llm_fallback(
        self, subtask: SubTask, context: SharedContext,
    ) -> ReviewedResult:
        """
        Last-resort attempt: use LLM to directly answer the subtask prompt
        when the AgentRunner execution has exhausted all retries.

        Transitions: FAILED → LLM_FALLBACK → (DONE | ABORTED)
        """
        subtask.state = SubTaskState.LLM_FALLBACK
        logger.info("LLM fallback for critical step %s", subtask.step_name)

        llm_breaker = self._breakers.get("llm_service")
        if not llm_breaker.allow_request():
            return self._circuit_open_result(subtask)

        try:
            self._render_prompt(subtask, context)
            output = await self._llm.chat(subtask.prompt, max_tokens=4096)
            if output and output.strip():
                return ReviewedResult(
                    passed=True,
                    feedback="llm_fallback",
                    result=StepResult(
                        step_name=subtask.step_name, agent_type="llm_fallback",
                        output_key=subtask.output_key, output=output.strip(),
                        success=True, duration=0,
                    ),
                )
        except Exception as e:
            logger.warning("LLM fallback failed for %s: %s", subtask.step_name, e)

        return ReviewedResult(
            passed=False,
            feedback="LLM fallback also failed",
            result=StepResult(
                step_name=subtask.step_name, agent_type="llm_fallback",
                output_key=subtask.output_key, output="",
                success=False, duration=0,
                error="LLM fallback exhausted",
                error_category=ErrorCategory.PERMANENT,
            ),
        )

    async def _maybe_checkpoint(self, context: SharedContext) -> None:
        """Persist context to disk after each completed subtask for crash recovery."""
        cp = getattr(self, "_round_checkpoint_path", None)
        if cp:
            try:
                await context.checkpoint(
                    cp,
                    plan_signature=getattr(self, "_round_plan_signature", ""),
                )
            except Exception as e:
                logger.warning("Checkpoint write failed: %s", e)

    async def _emit(self, event: str, data: dict) -> None:
        """Fire an event if an EventBus was provided."""
        if self._event_bus:
            await self._event_bus.emit(event, data)

    async def _enqueue_dlq(
        self, task_id: str, step_name: str, error: str, context: SharedContext,
    ) -> None:
        """Write a permanently failed step to the dead-letter queue."""
        if self._dlq:
            await self._dlq.enqueue(task_id, step_name, error, context.snapshot())

    @staticmethod
    def _mark_abandoned(queue: ExecutionQueue, results: List[ReviewedResult]) -> None:
        """Set terminal state on subtasks that were never executed (timeout / deadlock)."""
        for st in queue.get_incomplete():
            st.state = SubTaskState.ABORTED
            results.append(ReviewedResult(
                passed=False,
                feedback="abandoned due to timeout or deadlock",
                result=StepResult(
                    step_name=st.step_name, agent_type=st.agent_type,
                    output_key=st.output_key, output="",
                    success=False, duration=0,
                    error="abandoned due to timeout or deadlock",
                    error_category=ErrorCategory.TRANSIENT,
                ),
            ))

    @staticmethod
    async def _wait_for_breaker(
        breaker: Any, max_wait: float = 30, poll_interval: float = 2.0,
    ) -> bool:
        """
        Poll the circuit breaker until it allows requests or ``max_wait``
        seconds elapse.

        @param breaker       CircuitBreaker instance.
        @param {float} max_wait       Max seconds to wait.
        @param {float} poll_interval  Seconds between polls.
        @returns {bool} True if the breaker opened up, False if timeout.
        """
        elapsed = 0.0
        while elapsed < max_wait:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval
            if breaker.allow_request():
                logger.info("Circuit breaker recovered after %.1fs wait", elapsed)
                return True
        return False

    @staticmethod
    def _circuit_open_result(subtask: SubTask) -> ReviewedResult:
        return ReviewedResult(
            passed=False,
            feedback="circuit breaker OPEN — service unavailable",
            result=StepResult(
                step_name=subtask.step_name, agent_type=subtask.agent_type,
                output_key=subtask.output_key, output="",
                success=False, duration=0,
                error="circuit breaker open",
                error_category=ErrorCategory.TRANSIENT,
            ),
        )

    # ── public introspection API ──────────────────────────────────

    @property
    def pool_active_count(self) -> int:
        """Number of currently active agent slots."""
        return self._pool.active_count

    @property
    def pool_stats(self) -> dict:
        """Agent pool statistics (spawned, released, peak)."""
        return self._pool.stats

    @property
    def breaker_summary(self) -> Dict[str, str]:
        """Snapshot of all circuit breaker states."""
        return self._breakers.summary()

    async def scan_dlq(self) -> int:
        """
        Scan the dead-letter queue for stale entries and fire alerts.

        @returns {int} number of stale entries found, or 0 if no DLQ
        """
        if self._dlq:
            return await self._dlq.scan_and_alert()
        return 0

    async def list_dlq_pending(self, limit: int = 50) -> List[dict]:
        """
        Return the most recent pending DLQ entries.

        @param {int} limit - max entries to return
        @returns {list[dict]} pending DLQ entries
        """
        if self._dlq:
            return await self._dlq.list_pending(limit)
        return []

    async def consume_dlq(self) -> List[dict]:
        """
        Atomically consume all pending DLQ entries.

        @returns {list[dict]} consumed entries
        """
        if self._dlq:
            return await self._dlq.consume()
        return []

    async def consume_and_classify_dlq(self) -> Dict[str, List[dict]]:
        """
        Consume all DLQ entries and classify them as retryable or escalate.

        @returns {dict} with keys ``retryable`` and ``escalate``
        """
        if self._dlq:
            return await self._dlq.consume_and_classify()
        return {"retryable": [], "escalate": []}
