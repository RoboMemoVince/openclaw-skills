"""
Slash command handling and active-task registry for the workflow controller.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional

from modules.data_types import Phase, TaskEnvelope


class TaskContext:
    """
    @description 单个任务的运行上下文，支持取消传播。
    """

    def __init__(self, envelope: TaskEnvelope, store: Any):
        self.envelope = envelope
        self.task = envelope.content
        self.store = store
        self._cancelled = asyncio.Event()

    def cancel(self) -> None:
        """
        @description 标记任务已取消。
        @returns {None}
        """

        self._cancelled.set()

    @property
    def is_cancelled(self) -> bool:
        """
        @description 返回任务是否已取消。
        @returns {bool}
        """

        return self._cancelled.is_set()


class ActiveTaskRegistry:
    """
    @description 线程安全的活跃任务注册表。
    """

    def __init__(self):
        self._contexts: Dict[str, TaskContext] = {}
        self._lock = asyncio.Lock()

    async def register(self, task_id: str, ctx: TaskContext) -> None:
        async with self._lock:
            self._contexts[task_id] = ctx

    async def unregister(self, task_id: str) -> None:
        async with self._lock:
            self._contexts.pop(task_id, None)

    async def cancel(self, task_id: str) -> bool:
        """
        @description 取消指定任务，返回是否找到活跃上下文。
        @param {str} task_id
        @returns {bool}
        """

        async with self._lock:
            ctx = self._contexts.get(task_id)
        if ctx is None:
            return False
        ctx.cancel()
        return True

    async def get(self, task_id: str) -> TaskContext | None:
        """
        @description 获取指定任务上下文。
        @param {str} task_id
        @returns {TaskContext | None}
        """

        async with self._lock:
            return self._contexts.get(task_id)


class CommandHandler:
    """
    @description 斜杠指令处理器，仅处理即时命令。
    """

    COMMANDS = {"/help", "/status", "/task", "/tasks", "/cancel"}

    def __init__(
        self,
        state_store: Any,
        event_bus: Any,
        active_tasks: ActiveTaskRegistry,
        worker_pool: Any = None,
        observer: Any = None,
    ):
        self._store = state_store
        self._bus = event_bus
        self._active_tasks = active_tasks
        self._worker_pool = worker_pool
        self._observer = observer

    async def handle(self, envelope: TaskEnvelope) -> dict:
        """
        @description 分派斜杠指令到对应处理逻辑。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        match envelope.parsed_command:
            case "/help":
                return self._help(envelope)
            case "/status":
                return await self._status(envelope)
            case "/task":
                return await self._task_detail(envelope.parsed_args, envelope)
            case "/tasks":
                return await self._task_list(envelope.parsed_args, envelope)
            case "/cancel":
                return await self._cancel(envelope.parsed_args, envelope)
        return self._response(envelope, success=False, error=f"未知命令: {envelope.parsed_command}")

    def _help(self, envelope: TaskEnvelope) -> dict:
        """
        @description 返回帮助信息。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        return self._response(
            envelope,
            output=(
                "Available commands:\n"
                "  /help                      -- 显示帮助\n"
                "  /status                    -- 查看系统状态\n"
                "  /task <id>                 -- 查看单个任务\n"
                "  /tasks [status]            -- 查看最近任务\n"
                "  /cancel <id>               -- 取消任务\n"
                "  /run <workflow> <task>     -- 指定工作流执行\n"
                "  /redo <id> [feedback]      -- 带反馈重做任务"
            ),
        )

    async def _status(self, envelope: TaskEnvelope) -> dict:
        """
        @description 返回系统状态。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        lines = ["System status:"]
        if self._worker_pool is not None and hasattr(self._worker_pool, "summary"):
            summary = self._worker_pool.summary()
            lines.append(f"  Workers: {summary.get('total', 0)} total")
            lines.append(f"  Active slots: {summary.get('active', 0)}")
            lines.append(f"  Offline workers: {summary.get('offline', 0)}")
        if self._observer is not None:
            if hasattr(self._observer, "breaker_summary"):
                lines.append(f"  Breakers: {self._observer.breaker_summary()}")
            if hasattr(self._observer, "metrics_summary"):
                lines.append(f"  Metrics: {self._observer.metrics_summary()}")
        recent = await self._store.list_recent(limit=5)
        lines.append(f"  Recent tasks: {len(recent)}")
        return self._response(envelope, output="\n".join(lines))

    async def _task_detail(self, task_id: str, envelope: TaskEnvelope) -> dict:
        """
        @description 返回单任务详情。
        @param {str} task_id
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        task_id = task_id.strip()
        if not task_id:
            return self._response(envelope, success=False, error="请提供任务 ID")
        saved = await self._store.load(task_id)
        if saved is None:
            return self._response(envelope, success=False, error=f"任务不存在: {task_id}")
        output = (
            f"任务: {saved.task_id}\n"
            f"阶段: {saved.phase.value}\n"
            f"工作流: {saved.workflow_name or '-'}\n"
            f"迭代: {saved.iteration}/{saved.max_iterations}\n"
            f"内容: {saved.content[:500]}"
        )
        return self._response(envelope, output=output)

    async def _task_list(self, status: str, envelope: TaskEnvelope) -> dict:
        """
        @description 返回最近任务列表。
        @param {str} status
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        normalized = status.strip().lower() or None
        rows = await self._store.list_recent(status=normalized, limit=10)
        if not rows:
            return self._response(envelope, output="最近没有任务记录")
        lines = []
        for row in rows:
            lines.append(
                f"{row.task_id[:12]}  {row.phase.value:<10}  {row.workflow_name or '-':<12}  {row.content[:60]}"
            )
        return self._response(envelope, output="\n".join(lines))

    async def _cancel(self, target_id: str, envelope: TaskEnvelope) -> dict:
        """
        @description 取消指定任务。
        @param {str} target_id
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        task_id = target_id.strip()
        if not task_id:
            return self._response(envelope, success=False, error="请提供任务 ID")

        found = await self._active_tasks.cancel(task_id)
        await self._store.update_phase(task_id, Phase.CANCELLED)
        if self._bus is not None:
            await self._bus.emit("task_cancelled", {"task_id": task_id})
        if not found:
            return self._response(
                envelope,
                output=f"任务 {task_id[:8]} 已标记为取消（当前未在活跃列表中）",
            )
        return self._response(envelope, output=f"任务 {task_id[:8]} 已取消")

    @staticmethod
    def _response(
        envelope: TaskEnvelope,
        *,
        success: bool = True,
        output: str = "",
        error: str = "",
    ) -> dict:
        """
        @description 统一命令响应结构。
        @param {TaskEnvelope} envelope
        @param {bool} success
        @param {str} output
        @param {str} error
        @returns {dict}
        """

        return {
            "success": success,
            "output": output,
            "error": error,
            "duration": 0,
            "task_id": envelope.task_id,
            "steps": [],
            "routing_decision": "",
        }
