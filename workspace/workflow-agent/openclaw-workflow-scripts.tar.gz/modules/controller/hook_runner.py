"""
Pre-execution hook orchestration for the PREPARING phase.
"""

from __future__ import annotations

import asyncio
from typing import Any, List

from modules.controller.escalation import should_escalate
from modules.data_types import EscalatableDecision, EscalationConfig, TaskEnvelope
from modules.dsl.errors import HookAborted, HookReclassify


class PreExecuteHook:
    """
    @description 预执行钩子接口，支持必需/可选区分和失败策略。
    """

    required: bool = True
    on_fail: str = "abort"
    max_retries: int = 2

    async def run(self, envelope: TaskEnvelope) -> None:
        raise NotImplementedError


class ResourcePreflight(PreExecuteHook):
    """
    @description 预检工作流和 Worker 资源是否可用。
    """

    required = True
    on_fail = "reclassify"

    def __init__(self, workflow_registry: Any, worker_pool: Any = None):
        self._workflow_registry = workflow_registry
        self._worker_pool = worker_pool

    async def run(self, envelope: TaskEnvelope) -> None:
        if not envelope.workflow_name:
            raise RuntimeError("workflow not selected")
        if self._workflow_registry.get_entry(envelope.workflow_name) is None:
            raise RuntimeError(f"workflow not found: {envelope.workflow_name}")
        if self._worker_pool is not None and hasattr(self._worker_pool, "summary"):
            summary = self._worker_pool.summary()
            if summary.get("total", 0) <= 0:
                raise RuntimeError("no worker registered")


class KnowledgeLoader(PreExecuteHook):
    """
    @description 预加载知识库上下文，失败时允许降级。
    """

    required = False
    on_fail = "skip"

    def __init__(self, knowledge_base: Any = None):
        self._knowledge_base = knowledge_base

    async def run(self, envelope: TaskEnvelope) -> None:
        if self._knowledge_base is None or not hasattr(self._knowledge_base, "search"):
            return
        results = await self._knowledge_base.search(envelope.content)
        envelope.metadata["knowledge_context"] = results


class HookRunner:
    """
    @description PREPARING 阶段的钩子编排器。
    """

    def __init__(
        self,
        hooks: List[PreExecuteHook],
        interactor: Any,
        escalation_config: EscalationConfig,
    ):
        self._hooks = hooks
        self._interactor = interactor
        self._config = escalation_config

    async def run(self, envelope: TaskEnvelope, interaction_mode: str) -> None:
        """
        @description 按顺序执行钩子链，区分必需/可选钩子的失败策略。
        @param {TaskEnvelope} envelope
        @param {str} interaction_mode
        @returns {None}
        @throws {HookAborted}
        @throws {HookReclassify}
        """

        for hook in self._hooks:
            attempt = 0
            while True:
                try:
                    await hook.run(envelope)
                    break
                except Exception as error:
                    if not hook.required:
                        envelope.metadata.setdefault("degraded_hooks", []).append(type(hook).__name__)
                        break

                    action = await self._decide_on_failure(hook, envelope, error, interaction_mode)
                    if action == "retry" and attempt < hook.max_retries:
                        attempt += 1
                        await asyncio.sleep(min(2 ** attempt, 5))
                        continue
                    if action == "reclassify":
                        raise HookReclassify(type(hook).__name__) from error
                    raise HookAborted(type(hook).__name__, str(error)) from error

    async def _decide_on_failure(
        self,
        hook: PreExecuteHook,
        envelope: TaskEnvelope,
        error: Exception,
        mode: str,
    ) -> str:
        """
        @description 必需钩子失败时的决策逻辑。
        @param {PreExecuteHook} hook
        @param {TaskEnvelope} envelope
        @param {Exception} error
        @param {str} mode
        @returns {str}
        """

        error_str = str(error).lower()
        is_transient = any(kw in error_str for kw in ("timeout", "connection", "429", "503", "econnrefused"))
        if is_transient:
            return "retry"

        auto_choice = hook.on_fail if hook.on_fail in {"abort", "reclassify", "retry"} else "abort"
        decision = EscalatableDecision(
            auto_choice=auto_choice,
            confidence=0.3 if hook.required else 1.0,
            alternatives=["abort", "reclassify", "retry"],
            reason=f"钩子 {type(hook).__name__} 失败: {error}",
            escalation_prompt=f"预执行钩子 {type(hook).__name__} 失败，请选择处理方式",
        )

        if self._interactor is not None and should_escalate(
            mode,
            decision.confidence,
            self._config.hook_failure_threshold,
        ):
            chosen = await self._interactor.request_decision(
                envelope,
                decision,
                self._config.hook_failure_timeout_s,
            )
            if chosen in {"abort", "reclassify", "retry"}:
                return chosen
        return decision.auto_choice
