"""
Controller entry point that dispatches commands and workflow reconciliation.
"""

from __future__ import annotations

from modules.controller.command_handler import CommandHandler
from modules.data_types import Phase, TaskEnvelope


class TaskController:
    """
    @description Controller 入口，分派即时命令和工作流任务。
    """

    ROUTING_COMMANDS = {"/redo"}

    def __init__(self, command_handler: CommandHandler, reconciler, state_store):
        self._command_handler = command_handler
        self._reconciler = reconciler
        self._store = state_store

    async def reconcile(self, envelope: TaskEnvelope) -> dict:
        """
        @description 驱动任务完成整个生命周期。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        self._parse_command(envelope)

        if envelope.parsed_command in CommandHandler.COMMANDS:
            return await self._command_handler.handle(envelope)

        if envelope.parsed_command in self.ROUTING_COMMANDS:
            await self._apply_routing_command(envelope)

        return await self._reconciler.run(envelope)

    @staticmethod
    def _parse_command(envelope: TaskEnvelope) -> None:
        """
        @description 解析斜杠命令和参数。
        @param {TaskEnvelope} envelope
        @returns {None}
        """

        content = (envelope.content or "").strip()
        if envelope.parsed_command or not content.startswith("/"):
            return
        parts = content.split(maxsplit=1)
        envelope.parsed_command = parts[0]
        envelope.parsed_args = parts[1] if len(parts) > 1 else ""

    async def _apply_routing_command(self, envelope: TaskEnvelope) -> None:
        """
        @description 对 `/redo` 做预处理：加载旧状态、注入反馈、重置阶段、清除幂等缓存、持久化后再进 Reconciler。
        @param {TaskEnvelope} envelope
        @returns {None}
        """

        if envelope.parsed_command != "/redo":
            return
        parts = envelope.parsed_args.split(maxsplit=1)
        target_id = parts[0] if parts else ""
        feedback = parts[1] if len(parts) > 1 else ""
        saved = await self._store.load(target_id)
        if saved is None:
            return
        envelope.task_id = saved.task_id
        envelope.content = saved.content
        envelope.workflow_name = saved.workflow_name
        envelope.metadata["user_feedback"] = feedback
        envelope.phase = Phase.PREPARING
        envelope.iteration = 0

        if hasattr(self._store, "clear_step_checkpoints"):
            await self._store.clear_step_checkpoints(envelope.task_id)
        await self._store.save(envelope)
