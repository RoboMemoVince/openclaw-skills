"""
Decision escalation primitives for the workflow controller.
"""

from __future__ import annotations

from modules.data_types import EscalatableDecision, EscalationConfig


def should_escalate(mode: str, confidence: float, threshold: float) -> bool:
    """
    @description 三种 interaction_mode 的统一升级判定。
    @param {str} mode - interaction_mode（auto / adaptive / confirm）。
    @param {float} confidence - 对 auto_choice 的置信度（0.0-1.0）。
    @param {float} threshold - adaptive 模式的升级阈值。
    @returns {bool}
    """

    if mode == "auto":
        return False
    if mode == "confirm":
        return True
    return confidence < threshold


__all__ = [
    "EscalatableDecision",
    "EscalationConfig",
    "should_escalate",
]
