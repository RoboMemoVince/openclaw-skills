"""
Iteration decision logic for the workflow controller.
"""

from __future__ import annotations

from modules.controller.escalation import should_escalate
from modules.data_types import (
    EscalatableDecision,
    EscalationConfig,
    IterationConfig,
    Phase,
    TaskEnvelope,
    WorkflowResult,
)


class IterationStrategy:
    """
    @description EXECUTING 后的迭代方向决策。
    """

    def __init__(
        self,
        iteration_config: IterationConfig,
        escalation_config: EscalationConfig,
        interactor: object | None,
    ):
        self._iter_config = iteration_config
        self._esc_config = escalation_config
        self._interactor = interactor

    async def decide(
        self,
        result: WorkflowResult,
        envelope: TaskEnvelope,
        interaction_mode: str,
    ) -> Phase:
        """
        @description 根据工作流结果决定下一阶段。
        @param {WorkflowResult} result
        @param {TaskEnvelope} envelope
        @param {str} interaction_mode
        @returns {Phase}
        """

        if result.error == "cancelled":
            return Phase.CANCELLED

        if not result.needs_iteration or envelope.iteration >= envelope.max_iterations:
            return Phase.DELIVERED if result.success else Phase.FAILED

        envelope.iteration += 1
        auto_phase = self._compute_auto(result, envelope)
        confidence = self._compute_confidence(result, envelope)
        decision = EscalatableDecision(
            auto_choice=auto_phase.value,
            confidence=confidence,
            alternatives=["preparing", "classified", "failed"],
            reason=result.iteration_reason or "需要继续迭代",
            escalation_prompt=f"工作流需要迭代（{result.iteration_reason or '未给出原因'}），请选择下一步",
        )

        if self._interactor is not None and should_escalate(
            interaction_mode,
            confidence,
            self._esc_config.iteration_threshold,
        ):
            chosen = await self._interactor.request_decision(
                envelope,
                decision,
                self._esc_config.iteration_timeout_s,
            )
            try:
                return Phase(chosen)
            except Exception:
                return auto_phase
        return auto_phase

    def _compute_auto(self, result: WorkflowResult, envelope: TaskEnvelope) -> Phase:
        """
        @description 计算系统自主选择的迭代方向。
        @param {WorkflowResult} result
        @param {TaskEnvelope} envelope
        @returns {Phase}
        """

        should_reclassify = result.reclassify or (
            not result.success
            and not envelope.reclassified
            and float(envelope.metadata.get("classify_confidence", 1.0))
            < self._iter_config.reclassify_threshold
        )
        if should_reclassify:
            envelope.reclassified = True
            return Phase.CLASSIFIED
        return Phase.PREPARING

    def _compute_confidence(self, result: WorkflowResult, envelope: TaskEnvelope) -> float:
        """
        @description 计算对自动选择的置信度。
        @param {WorkflowResult} result
        @param {TaskEnvelope} envelope
        @returns {float}
        """

        classify_confidence = float(envelope.metadata.get("classify_confidence", 1.0))
        if not result.success and classify_confidence < self._esc_config.iteration_threshold:
            return classify_confidence
        return 1.0
