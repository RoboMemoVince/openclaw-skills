"""
User interaction abstractions for workflow decisions and runtime prompts.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List


class UserInteractor:
    """
    @description Controller / Runtime 与用户交互的抽象接口。
    """

    async def request_decision(
        self,
        envelope: Any,
        decision: Any,
        timeout_s: int,
    ) -> str:
        raise NotImplementedError

    async def request_input(
        self,
        envelope: Any,
        prompt: str,
        timeout_s: int,
        *,
        interaction_key: str = "",
        options: List[str] | None = None,
    ) -> str | None:
        raise NotImplementedError


class StateBackedUserInteractor(UserInteractor):
    """
    @description 通过 StateStore KV + asyncio.Event 实现用户交互。
    每个交互点使用唯一 interaction_key 做读写，保证多次交互不串用。
    """

    def __init__(self, store: Any, notifier: Any = None):
        self._store = store
        self._notifier = notifier
        self._pending: Dict[str, asyncio.Event] = {}

    async def request_decision(
        self,
        envelope: Any,
        decision: Any,
        timeout_s: int,
    ) -> str:
        """
        @description 系统层决策升级，超时返回 auto_choice。
        """

        decision_key = f"{envelope.task_id}:decision:{id(decision)}"
        await self._store.set_kv(
            envelope.task_id,
            f"interaction:{decision_key}:request",
            {
                "prompt": decision.escalation_prompt,
                "auto_choice": decision.auto_choice,
                "alternatives": decision.alternatives,
                "reason": decision.reason,
            },
        )
        if self._notifier is not None and hasattr(self._notifier, "send_decision_request"):
            await self._notifier.send_decision_request(envelope, decision)
        result = await self._wait_response(envelope.task_id, decision_key, timeout_s)
        return result if result is not None else decision.auto_choice

    async def request_input(
        self,
        envelope: Any,
        prompt: str,
        timeout_s: int,
        *,
        interaction_key: str = "",
        options: List[str] | None = None,
    ) -> str | None:
        """
        @description 工作流层交互，使用 interaction_key 隔离多次交互。超时返回 None。
        """

        actual_key = interaction_key or f"input:{id(prompt)}"
        await self._store.set_kv(
            envelope.task_id,
            f"interaction:{actual_key}:request",
            {"prompt": prompt, "options": options},
        )
        if self._notifier is not None and hasattr(self._notifier, "send_input_request"):
            await self._notifier.send_input_request(envelope, prompt)
        return await self._wait_response(envelope.task_id, actual_key, timeout_s)

    async def submit_response(self, task_id: str, key: str, value: str | None) -> None:
        """
        @description Gateway 收到用户响应后调用，唤醒等待方。
        @param {str} task_id
        @param {str} key - 完整 interaction_key
        @param {str | None} value
        @returns {None}
        """

        await self._store.set_kv(task_id, f"interaction:{key}:response", value)
        event = self._pending.get(f"{task_id}:{key}")
        if event is not None:
            event.set()

    async def _wait_response(self, task_id: str, key: str, timeout_s: int) -> str | None:
        event = asyncio.Event()
        event_key = f"{task_id}:{key}"
        self._pending[event_key] = event
        try:
            existing = await self._store.get_kv(task_id, f"interaction:{key}:response")
            if existing is not None:
                return existing
            await asyncio.wait_for(event.wait(), timeout=timeout_s)
            return await self._store.get_kv(task_id, f"interaction:{key}:response")
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending.pop(event_key, None)
