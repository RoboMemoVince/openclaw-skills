"""
Pure state-machine reconciler for task lifecycle progression.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

from modules.controller.command_handler import TaskContext
from modules.controller.escalation import should_escalate
from modules.data_types import (
    EscalatableDecision,
    EscalationConfig,
    Phase,
    TaskEnvelope,
    WorkflowResult,
)
from modules.dsl.errors import HookAborted, HookReclassify


class Reconciler:
    """
    @description 纯状态机循环驱动器，负责推进任务到达终态。
    """

    def __init__(
        self,
        classifier,
        workflow_registry,
        workflow_runtime,
        state_store,
        event_bus,
        user_interactor,
        active_tasks,
        hook_runner,
        iteration_strategy,
        confirmation_mode: str = "auto",
        escalation_config: EscalationConfig | None = None,
    ):
        self._classifier = classifier
        self._registry = workflow_registry
        self._runtime = workflow_runtime
        self._store = state_store
        self._bus = event_bus
        self._interactor = user_interactor
        self._active_tasks = active_tasks
        self._hook_runner = hook_runner
        self._iteration_strategy = iteration_strategy
        self._confirmation_mode = confirmation_mode
        self._esc_config = escalation_config or EscalationConfig()

    async def run(self, envelope: TaskEnvelope) -> dict:
        """
        @description 协调循环主体，每次推进一个阶段直到终态。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        saved = await self._store.load(envelope.task_id)
        if saved is not None:
            incoming_metadata = dict(envelope.metadata)
            incoming_result = envelope.result
            envelope.phase = saved.phase
            envelope.workflow_name = saved.workflow_name
            envelope.content = saved.content
            envelope.user_id = saved.user_id
            envelope.channel = saved.channel
            envelope.priority = saved.priority
            envelope.created_at = saved.created_at
            envelope.scheduled_at = saved.scheduled_at
            envelope.iteration = saved.iteration
            envelope.max_iterations = saved.max_iterations
            envelope.reclassify = saved.reclassify
            envelope.reclassified = saved.reclassified
            envelope.result = incoming_result if incoming_result is not None else saved.result
            envelope.metadata = dict(saved.metadata)
            envelope.metadata.update(incoming_metadata)
        else:
            await self._store.save(envelope)

        terminal = {Phase.DELIVERED, Phase.FAILED, Phase.CANCELLED}
        while envelope.phase not in terminal:
            await self._bus.emit(
                "phase_changed",
                {"task_id": envelope.task_id, "phase": envelope.phase.value},
            )

            match envelope.phase:
                case Phase.RECEIVED:
                    classify_result = await self._classifier.classify(envelope)
                    workflow_name = classify_result.workflow_name
                    if self._registry.get_entry(workflow_name) is None:
                        workflow_name = "general"
                    envelope.workflow_name = workflow_name
                    envelope.metadata["classify_confidence"] = classify_result.confidence
                    envelope.metadata["classify_source"] = classify_result.source
                    envelope.metadata["classify_reason"] = classify_result.reason
                    envelope.phase = Phase.CLASSIFIED
                    await self._store.save(envelope)

                case Phase.CLASSIFIED:
                    workflow_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (workflow_entry.interaction_mode if workflow_entry else None) or self._confirmation_mode
                    confidence = float(envelope.metadata.get("classify_confidence", 1.0))
                    source = str(envelope.metadata.get("classify_source", ""))
                    need_escalate = False
                    if mode == "confirm":
                        need_escalate = True
                    elif mode == "adaptive" and source == "llm" and confidence < self._esc_config.classification_threshold:
                        need_escalate = True
                    if need_escalate:
                        decision = EscalatableDecision(
                            auto_choice=envelope.workflow_name,
                            confidence=confidence,
                            alternatives=self._registry.list_all(),
                            reason=envelope.metadata.get("classify_reason", ""),
                            escalation_prompt=f"将使用 {envelope.workflow_name} 工作流，确认或选择其他工作流",
                        )
                        if self._interactor is not None:
                            chosen = await self._interactor.request_decision(
                                envelope,
                                decision,
                                self._esc_config.classification_timeout_s,
                            )
                            if chosen != envelope.workflow_name and self._registry.get_entry(chosen) is not None:
                                envelope.workflow_name = chosen
                    envelope.phase = Phase.PREPARING
                    await self._store.save(envelope)

                case Phase.PREPARING:
                    workflow_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (workflow_entry.interaction_mode if workflow_entry else None) or self._confirmation_mode
                    try:
                        await self._hook_runner.run(envelope, mode)
                    except HookAborted as error:
                        envelope.phase = Phase.FAILED
                        envelope.result = WorkflowResult(success=False, error=f"prepare_failed:{error.hook_name}")
                        await self._store.save(envelope)
                        continue
                    except HookReclassify:
                        envelope.phase = Phase.CLASSIFIED
                        await self._store.save(envelope)
                        continue
                    envelope.phase = Phase.EXECUTING
                    await self._store.save(envelope)

                case Phase.EXECUTING:
                    workflow_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (workflow_entry.interaction_mode if workflow_entry else None) or self._confirmation_mode
                    if workflow_entry is None:
                        envelope.phase = Phase.FAILED
                        envelope.result = WorkflowResult(success=False, error=f"workflow_not_found:{envelope.workflow_name}")
                        await self._store.save(envelope)
                        continue

                    ctx = TaskContext(envelope, self._store)
                    await self._active_tasks.register(envelope.task_id, ctx)
                    try:
                        result = await self._runtime.run(
                            workflow_entry.fn,
                            ctx,
                            timeout=workflow_entry.timeout,
                            middlewares=workflow_entry.middlewares,
                        )
                    finally:
                        await self._active_tasks.unregister(envelope.task_id)
                    envelope.result = result
                    envelope.phase = await self._iteration_strategy.decide(result, envelope, mode)
                    await self._store.save(envelope)

        return self._build_result(envelope)

    async def recover(self) -> None:
        """
        @description 系统启动时恢复非终态任务。
        @returns {None}
        """

        stale = await self._store.list_non_terminal()
        for envelope in stale:
            created_at = self._coerce_datetime(envelope.created_at)
            age = (datetime.now() - created_at).total_seconds()
            workflow_entry = self._registry.get_entry(envelope.workflow_name)
            ttl = (workflow_entry.timeout if workflow_entry else 300) * 2
            if age > ttl:
                envelope.phase = Phase.FAILED
                envelope.result = WorkflowResult(success=False, error="task_expired")
                await self._store.save(envelope)
                await self._bus.emit(
                    "task_expired",
                    {"task_id": envelope.task_id, "age": age, "ttl": ttl},
                )
            else:
                asyncio.create_task(self.run(envelope))

    @staticmethod
    def _build_result(envelope: TaskEnvelope) -> dict:
        """
        @description 将终态 TaskEnvelope 转为外部响应结构。
        @param {TaskEnvelope} envelope
        @returns {dict}
        """

        result = envelope.result if isinstance(envelope.result, WorkflowResult) else WorkflowResult()
        output = result.output
        if not output and result.steps:
            for step in reversed(result.steps):
                if step.success and step.output:
                    output = step.output
                    break
        is_success = envelope.phase == Phase.DELIVERED and result.success
        is_cancelled = envelope.phase == Phase.CANCELLED
        return {
            "success": is_success,
            "cancelled": is_cancelled,
            "partial": result.partial,
            "output": output,
            "raw_output": output,
            "error": result.error if not is_success else "",
            "raw_error": result.error if not is_success else "",
            "duration": result.total_duration,
            "task_id": envelope.task_id,
            "phase": envelope.phase.value,
            "workflow_name": envelope.workflow_name,
            "steps": [
                {
                    "name": step.step_name,
                    "agent_type": step.agent_type,
                    "success": step.success,
                    "duration": step.duration,
                    "error": step.error,
                }
                for step in result.steps
            ],
        }

    @staticmethod
    def _coerce_datetime(value: Any) -> datetime:
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value)
            except ValueError:
                pass
        return datetime.now()
