"""
Workflow classifier using a configurable strategy chain.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml
except ImportError:  # pragma: no cover - optional dependency
    yaml = None  # type: ignore

from modules.data_types import ClassifyResult, TaskEnvelope
from modules.paths import CONFIG_DIR

_DEFAULT_WORKFLOWS = [
    "instant",
    "general",
    "coding",
    "research",
    "translation",
    "database",
]

_DEFAULT_CONFIG = {
    "rules": [
        {"name": "coding", "keywords": ["代码", "编程", "写代码", "bug", "函数", "重构", "测试", "调试"], "priority": 10},
        {"name": "research", "keywords": ["搜索", "调研", "查找", "论文", "资料", "research"], "priority": 10},
        {"name": "translation", "keywords": ["翻译", "translate", "中译英", "英译中"], "priority": 10},
        {"name": "database", "keywords": ["数据库", "SQL", "查询", "mysql", "postgres", "sqlite"], "priority": 10},
    ],
    "instant_threshold": {
        "max_length": 20,
        "exclude_keywords": ["帮我", "请", "写", "做", "分析", "创建", "修改", "运行"],
    },
    "fallback": "general",
    "confirmation_mode": "adaptive",
    "iteration": {"reclassify_threshold": 0.5},
    "escalation": {
        "classification": {"adaptive_threshold": 0.6, "timeout_s": 30},
        "iteration": {"adaptive_threshold": 0.5, "timeout_s": 30},
        "hook_failure": {"adaptive_threshold": 0.5, "timeout_s": 15},
    },
}


class ClassifyStrategy:
    """
    @description 分类策略接口，返回 ClassifyResult 或 None。
    """

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        raise NotImplementedError


class UserOverrideStrategy(ClassifyStrategy):
    """
    @description L0：用户通过 `/run` 显式指定工作流。
    """

    def __init__(self, workflow_registry: Any):
        self._registry = workflow_registry

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        if envelope.parsed_command != "/run":
            return None

        parts = envelope.parsed_args.split(maxsplit=1)
        workflow_name = parts[0] if parts else "general"
        if self._registry.get(workflow_name) is None:
            workflow_name = "general"
        envelope.content = parts[1] if len(parts) > 1 else envelope.content
        return ClassifyResult(
            workflow_name=workflow_name,
            confidence=1.0,
            source="user_override",
            reason=f"用户通过 /run 显式指定工作流 '{workflow_name}'",
        )


class CommandStrategy(ClassifyStrategy):
    """
    @description L1：旧命令映射为固定工作流。
    """

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        if envelope.parsed_command == "/miniagent":
            return ClassifyResult(
                workflow_name="general",
                confidence=1.0,
                source="command",
                reason="兼容命令 /miniagent 映射到 general 工作流",
            )
        return None


class KeywordStrategy(ClassifyStrategy):
    """
    @description L2：关键词快速匹配。
    """

    def __init__(self, rules: List[dict]):
        self._rules = sorted(rules, key=lambda item: item.get("priority", 0), reverse=True)

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        content = envelope.content.lower()
        for rule in self._rules:
            matched = [keyword for keyword in rule.get("keywords", []) if keyword.lower() in content]
            if matched:
                return ClassifyResult(
                    workflow_name=rule["name"],
                    confidence=0.7,
                    source="keyword",
                    reason=f"匹配关键词: {', '.join(matched)}",
                )
        return None


class InstantStrategy(ClassifyStrategy):
    """
    @description L3：短文本直答判定。
    """

    def __init__(self, config: Dict[str, Any]):
        self._max_length = int(config.get("max_length", 20))
        self._exclude = list(config.get("exclude_keywords", []))

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        content = envelope.content.lower().strip()
        if not content:
            return None
        if len(content) >= self._max_length:
            return None
        if any(keyword.lower() in content for keyword in self._exclude):
            return None
        return ClassifyResult(
            workflow_name="instant",
            confidence=0.5,
            source="instant",
            reason=f"短文本直答（长度 {len(content)} < {self._max_length}）",
        )


class LLMStrategy(ClassifyStrategy):
    """
    @description L4：LLM 语义分类。
    """

    def __init__(self, llm_service: Any, workflow_registry: Any):
        self._llm = llm_service
        self._registry = workflow_registry

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        if self._llm is None:
            return None

        workflow_names = self._registry.list_all() or list(_DEFAULT_WORKFLOWS)
        prompt = (
            "你是工作流分类器。请把用户任务分类到以下工作流之一：\n"
            f"{', '.join(workflow_names)}\n\n"
            "请只返回 JSON："
            '{"workflow":"<name>","confidence":0.0,"reason":"<short reason>"}\n\n'
            f"任务：{envelope.content[:400]}"
        )
        raw = await self._llm.chat(prompt, max_tokens=128)
        if not raw:
            return None

        parsed = self._parse_response(raw, workflow_names)
        if parsed is None:
            return None
        return parsed

    @staticmethod
    def _parse_response(raw: str, workflow_names: List[str]) -> ClassifyResult | None:
        raw = raw.strip()
        try:
            data = json.loads(raw)
            workflow_name = str(data.get("workflow", "")).strip().lower()
            if workflow_name in workflow_names:
                return ClassifyResult(
                    workflow_name=workflow_name,
                    confidence=float(data.get("confidence", 0.5)),
                    source="llm",
                    reason=str(data.get("reason", "LLM 语义分析")),
                )
        except Exception:
            pass

        candidate = raw.splitlines()[0].strip().lower()
        if candidate in workflow_names:
            return ClassifyResult(
                workflow_name=candidate,
                confidence=0.5,
                source="llm",
                reason="LLM 语义分析",
            )
        return None


class FallbackStrategy(ClassifyStrategy):
    """
    @description L5：兜底策略。
    """

    def __init__(self, fallback: str = "general"):
        self._fallback = fallback

    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None:
        return ClassifyResult(
            workflow_name=self._fallback,
            confidence=0.1,
            source="fallback",
            reason="无匹配策略，使用兜底工作流",
        )


class Classifier:
    """
    @description 工作流分类器，采用策略链模式。
    """

    def __init__(
        self,
        llm_service: Any,
        workflow_registry: Any,
        config_path: Path | None = None,
    ):
        self._registry = workflow_registry
        self._config = self._load_config(config_path or CONFIG_DIR / "classifier.yaml")
        self._strategies: List[ClassifyStrategy] = [
            UserOverrideStrategy(workflow_registry),
            CommandStrategy(),
            KeywordStrategy(self._config.get("rules", [])),
            InstantStrategy(self._config.get("instant_threshold", {})),
            LLMStrategy(llm_service, workflow_registry),
            FallbackStrategy(self._config.get("fallback", "general")),
        ]

    @property
    def config(self) -> Dict[str, Any]:
        """
        @description 返回分类器配置。
        @returns {dict}
        """

        return dict(self._config)

    async def classify(self, envelope: TaskEnvelope) -> ClassifyResult:
        """
        @description 按策略链顺序尝试分类，首个命中即返回。
        @param {TaskEnvelope} envelope
        @returns {ClassifyResult}
        """

        alternatives = self._registry.list_all() or list(_DEFAULT_WORKFLOWS)
        for strategy in self._strategies:
            result = await strategy.try_classify(envelope)
            if result is not None:
                if not result.alternatives:
                    result.alternatives = alternatives
                return result
        return ClassifyResult(
            workflow_name="general",
            confidence=0.1,
            source="fallback",
            reason="无匹配策略，使用 general 工作流",
            alternatives=alternatives,
        )

    @staticmethod
    def _load_config(path: Path) -> Dict[str, Any]:
        """
        @description 加载分类器配置文件，不存在时返回默认配置。
        @param {Path} path
        @returns {dict}
        """

        if yaml is None or not path.exists():
            return dict(_DEFAULT_CONFIG)
        with open(path, "r", encoding="utf-8") as file:
            return yaml.safe_load(file) or dict(_DEFAULT_CONFIG)
