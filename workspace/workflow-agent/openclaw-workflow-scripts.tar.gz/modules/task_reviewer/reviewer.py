"""
TaskReviewer -- validate execution results.

For reviewer agent_type steps, uses LLM Service for semantic quality audit.
For other steps, performs basic sanity checks (empty output, crash markers).

The LLM-based deep review decouples the reviewer from AgentRunner so that
runner failures do not cascade into review failures.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, List, Optional

from modules.base import ModuleBase
from modules.data_types import StepResult, ReviewedResult, CRASH_MARKERS

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.task_reviewer")


class TaskReviewer(ModuleBase):

    @property
    def name(self) -> str:
        return "task_reviewer"

    @property
    def version(self) -> str:
        return "1.2"

    @property
    def dependencies(self) -> List[str]:
        return ["llm_service"]

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._llm: Optional[Any] = registry.get("llm_service")

    async def review(self, result: StepResult) -> ReviewedResult:
        """
        @param {StepResult} result
        @returns {ReviewedResult}
        """
        if not result.success:
            return ReviewedResult(passed=False, feedback=result.error, result=result)

        if result.agent_type == "reviewer" and self._llm:
            return await self._deep_review(result)

        return self._basic_check(result)

    def _basic_check(self, result: StepResult) -> ReviewedResult:
        """Non-empty output with no crash markers = pass."""
        output = result.output.strip()
        if not output:
            return ReviewedResult(passed=False, feedback="empty output", result=result)

        for marker in CRASH_MARKERS:
            if marker in output:
                return ReviewedResult(
                    passed=False,
                    feedback=f"crash marker detected: {marker}",
                    result=result,
                )

        return ReviewedResult(passed=True, feedback="ok", result=result)

    async def _deep_review(self, result: StepResult) -> ReviewedResult:
        """
        Use LLM Service directly for semantic quality audit.

        Decoupled from AgentRunner so that executor-level failures
        (subprocess hang, MCP issues) cannot cascade into review.
        """
        audit_prompt = (
            "Review the following output for correctness and completeness. "
            "Reply PASS or FAIL with a one-line reason.\n\n"
            f"{result.output[:2000]}"
        )
        try:
            answer = await self._llm.chat(audit_prompt, max_tokens=128)
        except Exception as e:
            logger.warning("Deep review LLM call failed, treating as pass: %s", e)
            return ReviewedResult(passed=True, feedback="audit skipped (llm error)", result=result)

        if not answer or not answer.strip():
            return ReviewedResult(passed=True, feedback="audit skipped (empty response)", result=result)

        passed = answer.strip().lower().startswith("pass")
        return ReviewedResult(passed=passed, feedback=answer.strip()[:200], result=result)
