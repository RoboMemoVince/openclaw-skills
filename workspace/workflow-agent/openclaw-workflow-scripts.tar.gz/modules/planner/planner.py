"""
Planner -- unified task classification, decomposition, and iteration planning.

Merges the responsibilities of:
  - ClassifyService  (keyword match → LLM fallback → "general")
  - TaskDecomposer   (YAML template expansion into SubTask list)

And adds:
  - plan_iteration() — convergence check + next-round planning in one LLM call

Preserves ``input_template`` on every SubTask and infers ``depends_on`` from
placeholders so ExecutionEngine can render prompts at runtime.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Optional, Set

try:
    import yaml as _yaml
except ImportError:
    _yaml = None  # type: ignore

from modules.base import ModuleBase
from modules.data_types import TaskRequest, SubTask, SharedContext
from modules.utils import SafeDict, extract_placeholders

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

_OPENCLAW_ROOT = Path(__file__).resolve().parent.parent.parent
_TEMPLATES_DIR = _OPENCLAW_ROOT / "config" / "workflow_templates"

_CLASSIFY_PROMPT = (
    "你是一个任务分类器。将以下任务分类为一个工作流类型。\n"
    "可选类型: {ids}\n只返回类型名（英文 ID），不要解释。\n\n任务: {task}"
)

_ITERATION_PROMPT = (
    "任务: {task}\n\n"
    "第 {iteration} 轮已完成的子任务输出:\n{summary}\n\n"
    "请判断:\n"
    "1. 以上结果是否已经满足任务要求?  如果是，回复 DONE\n"
    "2. 如果否，列出下一轮需要改进或补充的子任务。"
    '用 JSON 数组格式: [{{"name": "...", "prompt": "..."}}]\n'
    "只回复 DONE 或 JSON 数组。"
)


class Planner(ModuleBase):
    """
    Unified planner: classify → decompose → iterate.

    @method plan           Initial task decomposition (classify + template expand).
    @method plan_iteration Convergence check + next-round planning (single LLM call).
    """

    @property
    def name(self) -> str:
        return "planner"

    @property
    def version(self) -> str:
        return "1.0"

    @property
    def dependencies(self) -> List[str]:
        return ["llm_service"]

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._llm = registry.get("llm_service")
        self._tag_index = self._build_tag_index()
        self._ids = sorted(self._tag_index.keys()) or ["general"]
        self._template_cache: Dict[str, dict] = {}

    # ── public: plan (initial decomposition) ──────────────────────

    async def plan(self, task: TaskRequest) -> List[SubTask]:
        """
        Classify the task and expand into a SubTask list.

        @param {TaskRequest} task
        @returns {list[SubTask]} with input_template preserved and depends_on inferred
        """
        workflow_id = await self._classify(task.content)
        tpl = self._load_template(workflow_id)

        if not tpl or not tpl.get("steps"):
            return [SubTask(
                step_index=0,
                step_name="direct_execute",
                agent_type="executor",
                prompt=task.content,
                input_template="{task}",
                output_key="result",
                timeout=task.timeout,
            )]

        initial_keys = {"task", "query", "requirement"}
        subtasks: List[SubTask] = []

        for i, step in enumerate(tpl["steps"]):
            raw_template = step.get("input_template", "{task}")
            output_key = step.get("output_key", f"output_{i}")

            placeholders = extract_placeholders(raw_template)
            depends_on = sorted(placeholders - initial_keys - {output_key})

            st = SubTask(
                step_index=i,
                step_name=step.get("name", f"step_{i}"),
                agent_type=step.get("agent_type", "executor"),
                prompt="",
                input_template=raw_template,
                depends_on=depends_on,
                mcp_groups=step.get("mcp_groups", []),
                output_key=output_key,
                parallel=step.get("parallel", False),
                required=step.get("required", True),
                max_retries=step.get("max_retries", 2),
                max_review_retries=step.get("max_review_retries", 2),
                timeout=step.get("timeout", min(300, task.timeout)),
            )
            subtasks.append(st)

        return subtasks

    # ── public: plan_iteration (convergence + next round) ─────────

    async def plan_iteration(
        self,
        task_content: str,
        context: SharedContext,
        iteration: int,
    ) -> List[SubTask]:
        """
        Convergence check + iteration planning in one LLM call.

        Aggregates all completed subtask outputs and asks the LLM
        whether the task is satisfied.  Returns an empty list when
        converged, or a list of new SubTasks for the next round.

        @param {str} task_content
        @param {SharedContext} context
        @param {int} iteration - 1-based round number
        @returns {list[SubTask]} empty = converged
        """
        snapshot = context.snapshot()
        reserved = {"task", "query", "requirement"}
        summary = "\n".join(
            f"- {k}: {str(v)[:300]}"
            for k, v in snapshot.items()
            if k not in reserved and v
        )
        if not summary:
            return []

        prompt = _ITERATION_PROMPT.format(
            task=task_content[:300],
            iteration=iteration,
            summary=summary[:1500],
        )
        answer = await self._llm.chat(prompt, max_tokens=500) if self._llm else ""
        if not answer or answer.upper().startswith("DONE"):
            return []

        return self._parse_iteration_subtasks(answer, iteration)

    # ── classification (keyword-first, LLM fallback) ──────────────

    async def _classify(self, content: str) -> str:
        kw = self._keyword_match(content)
        if kw:
            return kw
        llm = await self._llm_classify(content)
        if llm:
            return llm
        return "general"

    def _keyword_match(self, content: str) -> Optional[str]:
        low = content.lower()
        best_id, best_score = None, 0
        for wf_id, tags in self._tag_index.items():
            score = sum(1 for t in tags if t in low)
            if score > best_score:
                best_score, best_id = score, wf_id
        return best_id if best_score > 0 and best_id != "general" else None

    async def _llm_classify(self, content: str) -> Optional[str]:
        prompt = _CLASSIFY_PROMPT.format(ids=", ".join(self._ids), task=content[:200])
        answer = await self._llm.chat(prompt, max_tokens=32) if self._llm else ""
        answer = answer.strip().lower()
        return answer if answer in self._ids else None

    # ── template loading ──────────────────────────────────────────

    def _load_template(self, workflow_id: str) -> Optional[dict]:
        if workflow_id in self._template_cache:
            return self._template_cache[workflow_id]
        if not _yaml:
            return None
        for path in [
            _TEMPLATES_DIR / f"{workflow_id}.yaml",
            _TEMPLATES_DIR / "extended" / f"{workflow_id}.yaml",
        ]:
            if path.exists():
                with open(path, "r", encoding="utf-8") as f:
                    tpl = _yaml.safe_load(f)
                self._template_cache[workflow_id] = tpl
                return tpl
        return None

    def _build_tag_index(self) -> Dict[str, List[str]]:
        idx: Dict[str, List[str]] = {}
        if not _yaml or not _TEMPLATES_DIR.exists():
            return idx
        for yp in _TEMPLATES_DIR.rglob("*.yaml"):
            try:
                with open(yp, "r", encoding="utf-8") as f:
                    tpl = _yaml.safe_load(f)
                wid = tpl.get("id", yp.stem)
                tags = [t.lower() for t in tpl.get("tags", [])]
                if tags:
                    idx[wid] = tags
            except Exception:
                continue
        return idx

    # ── iteration parsing ─────────────────────────────────────────

    @staticmethod
    def _parse_iteration_subtasks(raw: str, iteration: int) -> List[SubTask]:
        """Parse LLM output into SubTask list for the next iteration round."""
        match = re.search(r"\[\s*\{.*\}\s*\]", raw, re.DOTALL)
        if not match:
            return []
        try:
            items = json.loads(match.group())
        except json.JSONDecodeError:
            return []

        reserved = {"task", "query", "requirement"}
        subtasks: List[SubTask] = []
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            raw_template = item.get("prompt", "")
            output_key = item.get("output_key", f"iter{iteration}_out{i}")
            placeholders = extract_placeholders(raw_template)
            depends_on = sorted(placeholders - reserved - {output_key})

            st = SubTask(
                step_index=i,
                step_name=item.get("name", f"iter{iteration}_step{i}"),
                agent_type=item.get("agent_type", "executor"),
                prompt=raw_template,
                input_template=raw_template,
                depends_on=depends_on,
                output_key=output_key,
                timeout=item.get("timeout", 300),
            )
            if st.input_template:
                subtasks.append(st)
        return subtasks

    def get_available_workflows(self) -> List[str]:
        """Return all known workflow IDs."""
        return list(self._ids)

    async def classify(self, content: str) -> str:
        """
        Public classification entry point for external callers.

        Consolidates keyword-match and LLM-based classification into a
        single API so scripts/workflow_engine.py does not need its own
        TaskClassifier.

        @param {str} content - task description
        @returns {str} workflow_id
        """
        return await self._classify(content)
