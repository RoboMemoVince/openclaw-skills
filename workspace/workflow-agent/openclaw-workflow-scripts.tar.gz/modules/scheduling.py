"""
Scheduling infrastructure -- dependency-aware execution queue and agent pool.

  ExecutionQueue  -- dynamic task queue with dependency resolution and backpressure
  AgentSlot       -- single agent execution slot with lease tracking
  AgentPool       -- manages slots with concurrency control and watchdog
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger("openclaw.scheduling")


# Avoid circular import: SubTask and SubTaskState are imported at runtime.
# Callers must ensure these types are available.
from pathlib import Path

from modules.core_types import SubTask, SubTaskState

_USER_HOME = str(Path.home())


class ExecutionQueue:
    """
    Dynamic task queue with dependency resolution and backpressure.

    ``next_batch()`` only releases subtasks whose ``depends_on`` keys
    are ALL present in the *done* set.

    @param initial       Initial subtask list.
    @param max_capacity  Backpressure limit -- ``add()`` rejects if exceeded.
    """

    def __init__(self, initial: List[SubTask], max_capacity: int = 20):
        self._pending: List[SubTask] = list(initial)
        self._running: Dict[str, SubTask] = {}
        self._done: List[SubTask] = []
        self._done_keys: Set[str] = set()
        self._lock = asyncio.Lock()
        self._max_capacity = max_capacity

    async def next_batch(self, max_size: int = 4) -> List[SubTask]:
        """
        Return up to *max_size* subtasks whose dependencies are satisfied.

        @returns {list[SubTask]} ready batch (may be empty if blocked).
        @raises RuntimeError if deadlock is detected.
        """
        async with self._lock:
            ready: List[SubTask] = []
            for st in self._pending:
                if self._deps_satisfied(st):
                    if st.state == SubTaskState.BLOCKED:
                        st.state = SubTaskState.PENDING
                    ready.append(st)
                elif st.depends_on:
                    st.state = SubTaskState.BLOCKED

            batch = ready[:max_size]
            for st in batch:
                self._pending.remove(st)
                self._running[st.output_key] = st
                st.state = SubTaskState.ACQUIRED
            if not batch and self._pending and not self._running:
                raise RuntimeError(
                    f"Deadlock: {len(self._pending)} pending subtasks but no "
                    f"dependencies can be satisfied.  Unsatisfied keys: "
                    f"{[st.depends_on for st in self._pending]}"
                )
            return batch

    async def add(self, subtask: SubTask) -> bool:
        """Dynamically add a spawned subtask.  Returns False if at capacity."""
        async with self._lock:
            total = len(self._pending) + len(self._running)
            if total >= self._max_capacity:
                logger.warning("ExecutionQueue at capacity (%d), rejecting spawn", self._max_capacity)
                return False
            self._pending.append(subtask)
            return True

    async def mark_done(self, subtask: SubTask) -> None:
        async with self._lock:
            self._running.pop(subtask.output_key, None)
            self._done.append(subtask)
            self._done_keys.add(subtask.output_key)

    def all_done(self) -> bool:
        return not self._pending and not self._running

    @property
    def done_keys(self) -> Set[str]:
        return set(self._done_keys)

    @property
    def total_count(self) -> int:
        return len(self._pending) + len(self._running) + len(self._done)

    def get_incomplete(self) -> List[SubTask]:
        """
        Return all subtasks that were never completed (pending + running).

        Used by ExecutionEngine to mark abandoned tasks after timeout/deadlock
        without reaching into private members.

        @returns {list[SubTask]} incomplete subtasks
        """
        return list(self._pending) + list(self._running.values())

    def _deps_satisfied(self, st: SubTask) -> bool:
        if not st.depends_on:
            return True
        return all(dep in self._done_keys for dep in st.depends_on)


@dataclass
class AgentSlot:
    """A single agent execution slot with lease tracking and process control."""
    slot_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    agent_id: str = ""
    workspace: str = _USER_HOME
    subtask_id: str = ""
    task_id: str = ""
    acquired_at: Optional[datetime] = None
    released_at: Optional[datetime] = None
    lease_timeout: float = 300.0
    pid: Optional[int] = None


class AgentPool:
    """
    Manages a pool of agent execution slots with concurrency control,
    per-task quota, and lease-timeout watchdog.

    @param agents          Agent config dicts (id, workspace, ...).
    @param max_concurrent  Global concurrency limit.
    @param per_task_max    Max slots a single task_id may hold simultaneously.
    """

    def __init__(
        self,
        agents: List[dict],
        max_concurrent: int = 4,
        per_task_max: Optional[int] = None,
    ):
        self._agents = agents or [{"id": "main"}]
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_concurrent = max_concurrent
        self._per_task_max = per_task_max or max(1, max_concurrent // 2)
        self._active: Dict[str, AgentSlot] = {}
        self._task_counts: Dict[str, int] = {}
        self._stats = {"spawned": 0, "released": 0, "peak": 0}
        self._watchdog_task: Optional[asyncio.Task] = None

    async def acquire(self, subtask: SubTask, task_id: str = "", timeout: float = 300) -> AgentSlot:
        """
        Block until a slot becomes available, respecting per-task quota.

        @raises asyncio.TimeoutError if *timeout* seconds elapse.
        """
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise asyncio.TimeoutError(
                    f"AgentPool.acquire timeout ({timeout}s) for subtask {subtask.step_name}"
                )
            try:
                await asyncio.wait_for(self._semaphore.acquire(), timeout=remaining)
            except asyncio.TimeoutError:
                raise asyncio.TimeoutError(
                    f"AgentPool.acquire timeout ({timeout}s) for subtask {subtask.step_name}"
                ) from None
            if task_id and self._task_counts.get(task_id, 0) >= self._per_task_max:
                self._semaphore.release()
                await asyncio.sleep(0.5)
                continue
            break
        agent = self._pick_agent(subtask)
        slot = AgentSlot(
            agent_id=agent["id"],
            workspace=agent.get("workspace", _USER_HOME),
            subtask_id=subtask.output_key,
            task_id=task_id,
            acquired_at=datetime.now(),
            lease_timeout=float(subtask.timeout + 30),
        )
        self._active[slot.slot_id] = slot
        self._task_counts[task_id] = self._task_counts.get(task_id, 0) + 1
        self._stats["spawned"] += 1
        self._stats["peak"] = max(self._stats["peak"], len(self._active))
        return slot

    async def release(self, slot: AgentSlot, kill: bool = False) -> None:
        """
        Release a slot back to the pool.

        @param {bool} kill - if True, send SIGTERM/SIGKILL to the tracked subprocess
        """
        if kill and slot.pid:
            self._terminate_process(slot.pid, slot.slot_id)
        slot.released_at = datetime.now()
        if slot.slot_id in self._active:
            del self._active[slot.slot_id]
        if slot.task_id in self._task_counts:
            self._task_counts[slot.task_id] = max(0, self._task_counts[slot.task_id] - 1)
        self._semaphore.release()
        self._stats["released"] += 1

    @staticmethod
    def _terminate_process(pid: int, slot_id: str) -> None:
        """Send SIGTERM, then SIGKILL after 5s if still alive."""
        try:
            os.kill(pid, signal.SIGTERM)
            logger.info("Sent SIGTERM to pid %d (slot %s)", pid, slot_id)
        except ProcessLookupError:
            return
        except OSError as e:
            logger.warning("Failed to SIGTERM pid %d: %s", pid, e)
            return

        async def _force_kill() -> None:
            await asyncio.sleep(5)
            try:
                os.kill(pid, signal.SIGKILL)
                logger.warning("Sent SIGKILL to pid %d (slot %s)", pid, slot_id)
            except (ProcessLookupError, OSError):
                pass

        try:
            asyncio.ensure_future(_force_kill())
        except RuntimeError:
            pass

    @property
    def active_count(self) -> int:
        return len(self._active)

    @property
    def stats(self) -> dict:
        return dict(self._stats)

    def start_watchdog(self) -> None:
        """Launch background lease-expiry checker."""
        if self._watchdog_task is None or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(self._watchdog())

    async def stop_watchdog(self) -> None:
        if self._watchdog_task and not self._watchdog_task.done():
            self._watchdog_task.cancel()
            try:
                await self._watchdog_task
            except asyncio.CancelledError:
                pass

    async def _watchdog(self) -> None:
        """Periodically reclaim slots that exceeded their lease."""
        while True:
            await asyncio.sleep(30)
            now = datetime.now()
            expired = []
            for sid, slot in list(self._active.items()):
                if slot.acquired_at:
                    elapsed = (now - slot.acquired_at).total_seconds()
                    if elapsed > slot.lease_timeout:
                        expired.append(slot)
            for slot in expired:
                logger.warning(
                    "Slot %s lease expired (subtask=%s, pid=%s)",
                    slot.slot_id, slot.subtask_id, slot.pid,
                )
                self._mark_workspace_dirty(slot)
                await self.release(slot, kill=True)

    @staticmethod
    def _mark_workspace_dirty(slot: AgentSlot) -> None:
        """Write a marker file so future tasks know the workspace may be unclean."""
        try:
            marker = Path(slot.workspace) / ".openclaw_dirty"
            marker.write_text(
                f"slot={slot.slot_id} subtask={slot.subtask_id} "
                f"pid={slot.pid} killed_at={datetime.now().isoformat()}\n",
                encoding="utf-8",
            )
        except Exception:
            pass

    def _pick_agent(self, st: SubTask) -> dict:
        if st.agent_type == "reviewer":
            for a in self._agents:
                if a.get("id") == "worker" or a.get("name") == "worker":
                    return a
        return self._agents[0]
