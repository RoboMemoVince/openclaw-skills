"""
Scheduler for step-to-worker assignment.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import List

from modules.data_types import Priority, TaskStep, WorkerAssignment
from modules.dsl.errors import NoWorkerAvailable, QueueFull, ServiceUnavailable


class Scheduler:
    """
    @description 优先级队列 + 标签匹配调度器。
    """

    def __init__(self, worker_pool, breaker_reader, queue_capacity: int = 20):
        self._pool = worker_pool
        self._breaker = breaker_reader
        self._queue_capacity = queue_capacity
        self._queue: list[tuple[int, "asyncio.Future"]] = []
        self._pending = 0

    async def schedule(self, step: TaskStep, priority: Priority) -> WorkerAssignment:
        """
        @description 为单个步骤匹配最优 WorkerSlot，高优先级先调度。
        @param {TaskStep} step
        @param {Priority} priority
        @returns {WorkerAssignment}
        """

        import asyncio as _asyncio
        import heapq

        if self._breaker is not None and self._breaker.is_open("agent_runner"):
            raise ServiceUnavailable("agent_runner circuit open")
        if self._pending >= self._queue_capacity:
            raise QueueFull(f"scheduler queue full ({self._queue_capacity})")

        future: _asyncio.Future[None] = _asyncio.get_event_loop().create_future()
        entry = (priority.value, id(future), future)
        heapq.heappush(self._queue, entry)
        self._pending += 1
        try:
            while self._queue and self._queue[0][2] is not future:
                await _asyncio.sleep(0)
            heapq.heappop(self._queue)
            future.set_result(None)

            candidates = self._pool.filter_available(step.requirements)
            if not candidates:
                raise NoWorkerAvailable(step.requirements)

            slot = self._score(candidates)[0]
            await slot.acquire(timeout=step.timeout)
            return WorkerAssignment(
                slot=slot,
                step=step,
                priority=priority,
                timeout_at=datetime.now() + timedelta(seconds=step.timeout),
            )
        finally:
            self._pending = max(0, self._pending - 1)

    async def schedule_batch(
        self,
        steps: List[TaskStep],
        priority: Priority,
    ) -> List[WorkerAssignment]:
        """
        @description 批量调度，用于 parallel() 原语。
        @param {list[TaskStep]} steps
        @param {Priority} priority
        @returns {list[WorkerAssignment]}
        """

        import asyncio

        return await asyncio.gather(*[self.schedule(step, priority) for step in steps])

    @staticmethod
    def _score(candidates) -> list:
        """
        @description 排序策略：空闲度优先，然后成功率优先。
        @param {list} candidates
        @returns {list}
        """

        return sorted(
            candidates,
            key=lambda slot: (
                slot.active_count,
                -slot.worker.success_rate,
            ),
        )
