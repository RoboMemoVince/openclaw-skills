"""
ProgressReporter -- subscribes to EventBus lifecycle events and pushes
real-time progress updates to connected channels (console, feishu).

Rich event lifecycle consumed:
  task_received, route_decided, step_started, step_completed,
  step_failed, round_complete, on_complete
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from modules.base import ModuleBase
from modules.data_types import EventBus

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.progress_reporter")


@dataclass
class WorkflowProgress:
    """Tracks real-time progress for a single workflow execution."""

    task_id: str
    phase: str = "received"
    current_step: int = 0
    total_steps: int = 0
    current_step_name: str = ""
    started_at: float = field(default_factory=lambda: datetime.now().timestamp())
    step_durations: List[float] = field(default_factory=list)

    @property
    def percentage(self) -> float:
        if self.total_steps <= 0:
            return 0.0
        return min(100.0, (self.current_step / self.total_steps) * 100)

    @property
    def eta_seconds(self) -> float:
        """Estimate remaining time based on average step duration."""
        if not self.step_durations or self.current_step >= self.total_steps:
            return 0.0
        avg = sum(self.step_durations) / len(self.step_durations)
        remaining_steps = self.total_steps - self.current_step
        return avg * remaining_steps


class ProgressReporter(ModuleBase):
    """
    Subscribes to EventBus events and logs progress.

    External notification channels (feishu) can be wired via additional
    subscribers on the same bus, or by subclassing the ``_notify`` method.
    """

    @property
    def name(self) -> str:
        return "progress_reporter"

    @property
    def version(self) -> str:
        return "1.0"

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._active: Dict[str, WorkflowProgress] = {}

    def subscribe_to(self, bus: EventBus) -> None:
        """Wire all lifecycle events from an EventBus instance."""
        bus.subscribe("task_received", self._on_task_received)
        bus.subscribe("route_decided", self._on_route_decided)
        bus.subscribe("step_started", self._on_step_started)
        bus.subscribe("step_completed", self._on_step_completed)
        bus.subscribe("step_failed", self._on_step_failed)
        bus.subscribe("on_complete", self._on_complete)
        bus.subscribe("dlq_alert", self._on_dlq_alert)
        bus.subscribe("circuit_breaker_change", self._on_circuit_breaker_change)
        bus.subscribe("user_notification", self._on_user_notification)

    # ── event handlers ────────────────────────────────────────────

    async def _on_task_received(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        total = data.get("total_steps", 0)
        self._active[task_id] = WorkflowProgress(
            task_id=task_id, phase="received", total_steps=total,
        )
        await self._notify(task_id, f"任务已接收 ({total} 步)")

    async def _on_route_decided(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        route = data.get("route", "")
        prog = self._active.get(task_id)
        if prog is not None:
            prog.phase = "routing"
        await self._notify(task_id, f"路由决策: {route}")

    async def _on_step_started(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        step_name = data.get("step_name", "")
        prog = self._active.get(task_id)
        if prog:
            prog.phase = "executing"
            prog.current_step_name = step_name
        logger.info(
            "[progress] %s step_started: %s (%.0f%%)",
            task_id[:8], step_name, prog.percentage if prog else 0,
        )

    async def _on_step_completed(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        step_name = data.get("step_name", "")
        prog = self._active.get(task_id)
        if prog:
            prog.current_step += 1
            elapsed = datetime.now().timestamp() - prog.started_at
            prog.step_durations.append(elapsed / max(prog.current_step, 1))
        logger.info(
            "[progress] %s step_completed: %s (%.0f%%, ETA %.0fs)",
            task_id[:8], step_name,
            prog.percentage if prog else 0,
            prog.eta_seconds if prog else 0,
        )

    async def _on_step_failed(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        step_name = data.get("step_name", "")
        feedback = data.get("feedback", "")
        logger.warning("[progress] %s step_failed: %s — %s", task_id[:8], step_name, feedback[:80])

    async def _on_complete(self, data: dict) -> None:
        task_id = data.get("task_id", "")
        success = data.get("success", False)
        duration = data.get("duration", 0)
        self._active.pop(task_id, None)
        status = "成功" if success else "失败"
        await self._notify(task_id, f"任务{status} (耗时 {duration:.1f}s)")

    async def _on_dlq_alert(self, data: dict) -> None:
        """Handle dead-letter queue alerts."""
        message = data.get("message", "DLQ 告警")
        logger.warning("[progress] DLQ ALERT: %s", message)
        await self._notify("system", f"[DLQ 告警] {message}")

    async def _on_circuit_breaker_change(self, data: dict) -> None:
        """Handle circuit breaker state changes."""
        service = data.get("service", "unknown")
        old_state = data.get("old_state", "")
        new_state = data.get("new_state", "")
        msg = f"熔断器 {service}: {old_state} -> {new_state}"
        if new_state == "open":
            logger.warning("[progress] CIRCUIT BREAKER: %s", msg)
        else:
            logger.info("[progress] CIRCUIT BREAKER: %s", msg)
        await self._notify("system", f"[熔断器] {msg}")

    async def _on_user_notification(self, data: dict) -> None:
        """Push a notification to the user about an escalated or failed task."""
        task_id = data.get("task_id", "")
        message = data.get("message", "")
        logger.warning("[progress] USER NOTIFICATION %s: %s", task_id[:8], message)
        await self._notify(task_id, f"[通知] {message}")

    # ── notification dispatch ─────────────────────────────────────

    async def _notify(self, task_id: str, message: str) -> None:
        """Override or extend for feishu / webhook channels."""
        logger.info("[progress] %s: %s", task_id[:8], message)

    def get_progress(self, task_id: str) -> Optional[WorkflowProgress]:
        """Return live progress for an active task."""
        return self._active.get(task_id)
