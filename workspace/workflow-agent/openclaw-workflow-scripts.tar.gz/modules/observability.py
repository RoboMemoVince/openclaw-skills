"""
Observability infrastructure -- event bus and tracing.

  EventBus   -- lightweight in-process async event bus
  TaskTrace  -- end-to-end trace for a single task
  Span       -- a single timed operation within a trace
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

logger = logging.getLogger("openclaw.observability")


_CRITICAL_EVENTS = frozenset({
    "dlq_alert", "dlq_retry", "dlq_escalate",
    "dlq_retry_completed", "circuit_breaker_change",
    "phase_changed", "task_cancelled", "task_expired", "delivery_exhausted",
})

_CRITICAL_MAX_RETRIES = 3
_CRITICAL_RETRY_DELAY = 2.0


class EventBus:
    """
    Lightweight in-process event bus.  Callbacks are launched as tasks
    and will not block the main execution loop.

    Critical events (DLQ alerts, circuit breaker changes) get at-least-once
    delivery with automatic retry.  If all retries fail, the event is written
    to a local fallback file so it is never silently lost.

    @param hook_timeout        Max seconds a single callback may run.
    @param fallback_dir        Directory for the critical-event fallback JSONL file.
    """

    def __init__(
        self,
        hook_timeout: float = 5.0,
        fallback_dir: Optional[Path] = None,
    ):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._hook_timeout = hook_timeout
        self._fallback_path: Optional[Path] = None
        if fallback_dir:
            fallback_dir.mkdir(parents=True, exist_ok=True)
            self._fallback_path = fallback_dir / ".eventbus_fallback.jsonl"

    def subscribe(self, event: str, callback: Callable) -> None:
        self._subscribers.setdefault(event, []).append(callback)

    async def emit(self, event: str, data: dict) -> None:
        """Fire-and-forget: launch each subscriber as a background task."""
        is_critical = event in _CRITICAL_EVENTS
        for cb in self._subscribers.get(event, []):
            if is_critical:
                asyncio.create_task(self._safe_call_with_retry(cb, data, event))
            else:
                asyncio.create_task(self._safe_call(cb, data))

    async def _safe_call(self, callback: Callable, data: dict) -> None:
        try:
            await asyncio.wait_for(callback(data), timeout=self._hook_timeout)
        except asyncio.TimeoutError:
            logger.warning("EventBus hook timeout: %s", getattr(callback, "__name__", "?"))
        except Exception:
            logger.exception("EventBus hook error: %s", getattr(callback, "__name__", "?"))

    async def _safe_call_with_retry(
        self, callback: Callable, data: dict, event: str,
    ) -> None:
        """At-least-once delivery for critical events with exponential backoff."""
        for attempt in range(_CRITICAL_MAX_RETRIES):
            try:
                await asyncio.wait_for(callback(data), timeout=self._hook_timeout)
                return
            except asyncio.TimeoutError:
                logger.warning(
                    "EventBus critical hook timeout (attempt %d/%d): event=%s cb=%s",
                    attempt + 1, _CRITICAL_MAX_RETRIES, event,
                    getattr(callback, "__name__", "?"),
                )
            except Exception:
                logger.exception(
                    "EventBus critical hook error (attempt %d/%d): event=%s cb=%s",
                    attempt + 1, _CRITICAL_MAX_RETRIES, event,
                    getattr(callback, "__name__", "?"),
                )
            if attempt < _CRITICAL_MAX_RETRIES - 1:
                await asyncio.sleep(_CRITICAL_RETRY_DELAY * (attempt + 1))
        logger.error(
            "EventBus critical event delivery FAILED after %d attempts: event=%s cb=%s",
            _CRITICAL_MAX_RETRIES, event, getattr(callback, "__name__", "?"),
        )
        self._write_fallback(event, data)

    def _write_fallback(self, event: str, data: dict) -> None:
        """
        Last-resort persistence for critical events whose delivery failed.
        Appends to a local JSONL file so ops tooling can pick them up later.
        """
        if not self._fallback_path:
            return
        entry = {
            "event": event,
            "data": {k: str(v)[:500] for k, v in data.items()},
            "timestamp": datetime.now().isoformat(),
        }
        try:
            with open(self._fallback_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            logger.warning("EventBus fallback write also failed for event=%s", event)

    async def replay_fallback(self) -> int:
        """
        Re-emit events that were previously written to the fallback file.

        Successfully replayed entries are removed; entries that still fail
        remain in the file for the next startup attempt.

        @returns {int} number of entries successfully replayed
        """
        if not self._fallback_path or not self._fallback_path.exists():
            return 0

        try:
            raw = self._fallback_path.read_text(encoding="utf-8").strip()
        except Exception:
            logger.warning("Failed to read EventBus fallback file")
            return 0

        if not raw:
            return 0

        entries = []
        for line in raw.splitlines():
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        if not entries:
            return 0

        logger.info("EventBus replay: %d entries from fallback file", len(entries))
        remaining = []
        replayed = 0

        for entry in entries:
            event = entry.get("event", "")
            data = entry.get("data", {})
            subscribers = self._subscribers.get(event, [])
            if not subscribers:
                remaining.append(entry)
                continue

            success = False
            for cb in subscribers:
                try:
                    await asyncio.wait_for(cb(data), timeout=self._hook_timeout)
                    success = True
                except (asyncio.TimeoutError, Exception) as e:
                    logger.warning(
                        "EventBus replay failed for event=%s: %s", event, e,
                    )

            if success:
                replayed += 1
            else:
                remaining.append(entry)

        try:
            if remaining:
                with open(self._fallback_path, "w", encoding="utf-8") as f:
                    for entry in remaining:
                        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            else:
                self._fallback_path.write_text("", encoding="utf-8")
        except Exception:
            logger.warning("Failed to update EventBus fallback file after replay")

        if replayed:
            logger.info("EventBus replay: %d/%d events replayed successfully", replayed, len(entries))
        if remaining:
            logger.warning("EventBus replay: %d events still pending", len(remaining))

        return replayed


@dataclass
class Span:
    """A single timed operation within a task trace."""
    name: str
    start: float = field(default_factory=time.monotonic)
    end: float = 0.0
    status: str = "running"
    error: str = ""
    parent_id: str = ""

    def finish(self, status: str = "ok", error: str = "") -> None:
        self.end = time.monotonic()
        self.status = status
        self.error = error

    @property
    def duration(self) -> float:
        e = self.end if self.end else time.monotonic()
        return e - self.start


@dataclass
class TaskTrace:
    """
    End-to-end trace for a single task.  Every subtask execution creates
    a child span.  Traces can be exported via EventBus hooks.
    """
    task_id: str
    start: float = field(default_factory=time.monotonic)
    spans: List[Span] = field(default_factory=list)

    def start_span(self, name: str) -> Span:
        span = Span(name=name, parent_id=self.task_id)
        self.spans.append(span)
        return span

    @property
    def duration(self) -> float:
        return time.monotonic() - self.start

    def summary(self) -> dict:
        return {
            "task_id": self.task_id,
            "total_duration": self.duration,
            "spans": [
                {"name": s.name, "duration": s.duration, "status": s.status, "error": s.error}
                for s in self.spans
            ],
        }
