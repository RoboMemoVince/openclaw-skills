"""
DirectLLMHandler -- handles the "simple" routing path where tasks are
answered directly via LLM + optional MCP tool calls.

Now a first-class ModuleBase citizen: discoverable via Registry, protected
by CircuitBreaker, and sharing CRASH_MARKERS with TaskReviewer.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from modules.base import ModuleBase
from modules.data_types import TaskRequest, EventBus, TaskTrace, CRASH_MARKERS

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.direct_llm_handler")


class DirectLLMHandler(ModuleBase):
    """
    Handles simple tasks via LLM direct-answer with MCP tool loop.

    @method handle  Execute the simple-path LLM call with optional MCP tools.
    """

    @property
    def name(self) -> str:
        return "direct_llm_handler"

    @property
    def version(self) -> str:
        return "1.1"

    @property
    def dependencies(self) -> List[str]:
        return ["llm_service", "mcp_service"]

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._llm = registry.get("llm_service")
        self._mcp = registry.get("mcp_service")
        self._event_bus: Optional[EventBus] = None
        self._max_retries = 3
        self._max_tool_rounds = 5

    def set_event_bus(self, bus: EventBus) -> None:
        """
        Attach an EventBus after initialization (bus is owned by Orchestrator).

        @param {EventBus} bus
        """
        self._event_bus = bus

    async def handle(
        self, task: TaskRequest, trace: TaskTrace,
    ) -> Dict[str, Any]:
        """
        Execute the simple-path: LLM API call with optional MCP tool loop + retry.

        @param {TaskRequest} task
        @param {TaskTrace} trace
        @returns {dict} result with success, output, error, duration, etc.
        """
        span = trace.start_span("direct_llm")
        start = datetime.now()

        await self._emit("step_started", {
            "task_id": task.task_id, "step_name": "direct_llm",
            "agent_type": "llm_direct",
        })

        tools = None
        if self._mcp:
            try:
                tools = await self._mcp.list_tools() or None
            except Exception:
                pass

        for attempt in range(self._max_retries):
            try:
                result = await self._tool_loop(task.content, tools)
                output = result["output"]
                if output and output.strip():
                    validation_err = self._validate_output(output)
                    if validation_err:
                        logger.warning("direct_llm validation failed: %s", validation_err)
                        continue

                    span.finish("ok")
                    await self._emit("step_completed", {
                        "task_id": task.task_id, "step_name": "direct_llm",
                        "success": True, "feedback": "",
                    })
                    return {
                        "success": True, "output": output,
                        "raw_output": output, "error": "",
                        "duration": (datetime.now() - start).total_seconds(),
                        "task_id": task.task_id, "steps": [],
                        "tool_calls_count": result["tool_calls_count"],
                    }
            except Exception as e:
                logger.warning("direct_llm attempt %d failed: %s", attempt + 1, e)

            if attempt < self._max_retries - 1:
                await asyncio.sleep(2 ** attempt)

        span.finish("error", "all attempts failed")
        await self._emit("step_failed", {
            "task_id": task.task_id, "step_name": "direct_llm",
            "success": False, "feedback": "all attempts failed",
        })
        return {
            "success": False, "output": "",
            "raw_output": "", "error": "LLM 服务暂时不可用",
            "duration": (datetime.now() - start).total_seconds(),
            "task_id": task.task_id, "steps": [],
            "tool_calls_count": 0,
        }

    async def _tool_loop(
        self, content: str, tools: Optional[List[dict]],
    ) -> Dict[str, Any]:
        """
        LLM chat with up to ``max_tool_rounds`` rounds of MCP tool calls.

        @param {str} content - user query
        @param {list|None} tools - MCP tool descriptors
        @returns {dict} with keys: output (str), tool_calls_count (int)
        """
        messages: List[Dict[str, Any]] = [{"role": "user", "content": content}]
        tool_calls_count = 0
        resp: Dict[str, Any] = {}

        for _ in range(self._max_tool_rounds):
            resp = await self._llm.chat_messages(messages, tools=tools) if self._llm else {}

            tool_use = resp.get("tool_use")
            if tool_use and tools and self._mcp:
                tool_calls_count += 1
                try:
                    tool_result = await self._mcp.invoke(
                        tool_use["name"], tool_use.get("arguments", {}),
                    )
                except Exception as mcp_err:
                    logger.warning(
                        "MCP invoke failed for tool %s: %s",
                        tool_use.get("name"), mcp_err,
                    )
                    tool_result = {"error": f"Tool call failed: {str(mcp_err)[:200]}"}
                messages.append({
                    "role": "assistant",
                    "content": json.dumps(tool_use),
                })
                messages.append({
                    "role": "user",
                    "content": f"[tool result] {json.dumps(tool_result)[:2000]}",
                })
                continue

            output = resp.get("output", "")
            if output:
                return {"output": output, "tool_calls_count": tool_calls_count}

        return {
            "output": resp.get("output", "") if resp else "",
            "tool_calls_count": tool_calls_count,
        }

    @staticmethod
    def _validate_output(output: str) -> str:
        """
        Lightweight validation for simple-path output.

        @param {str} output
        @returns {str} empty if valid, error description if invalid
        """
        for marker in CRASH_MARKERS:
            if marker in output:
                return f"crash marker detected: {marker}"
        return ""

    async def _emit(self, event: str, data: dict) -> None:
        if self._event_bus:
            await self._event_bus.emit(event, data)
