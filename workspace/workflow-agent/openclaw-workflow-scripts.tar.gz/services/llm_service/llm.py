"""
LLMService -- pure LLM API wrapper with no side effects.

Provides single-turn and multi-turn chat, with optional tool-use support
for function-calling integrations.

Uses ``aiohttp`` for async HTTP with connection pooling when available;
falls back to ``urllib.request`` via ``run_in_executor`` otherwise.

This module is depended on by Orchestrator and Planner; it has zero
dependencies itself.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from modules.base import ModuleBase

try:
    import aiohttp as _aiohttp
except ImportError:
    _aiohttp = None  # type: ignore

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.llm_service")

_OPENCLAW_JSON = Path(__file__).resolve().parent.parent.parent / "openclaw.json"


class LLMService(ModuleBase):
    """
    Stateless LLM API facade.

    @method chat           Single-turn prompt -> str.
    @method chat_messages  Multi-turn messages -> dict (supports tool_use).
    """

    @property
    def name(self) -> str:
        return "llm_service"

    @property
    def version(self) -> str:
        return "1.1"

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._cfg = self._load_config()
        self._session: Optional[Any] = None
        if _aiohttp and self._cfg and self._cfg.get("base_url"):
            self._session = _aiohttp.ClientSession(
                base_url=self._cfg["base_url"],
                timeout=_aiohttp.ClientTimeout(total=60),
                connector=_aiohttp.TCPConnector(limit=10, keepalive_timeout=30),
            )

    async def shutdown(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    @property
    def available(self) -> bool:
        """Whether the service has valid credentials."""
        return bool(
            self._cfg
            and self._cfg.get("base_url")
            and os.environ.get("MINIMAX_API_KEY")
        )

    # ── public API ────────────────────────────────────────────────

    async def chat(self, prompt: str, max_tokens: int = 100) -> str:
        """
        Single-turn LLM call.

        @param {str} prompt
        @param {int} max_tokens
        @returns {str} response text, or empty string on failure
        """
        if not self.available:
            return ""
        try:
            body = await self._post({
                "model": "MiniMax-M2.5", "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            }, timeout=15)
            return self._extract_text(body)
        except Exception:
            logger.debug("LLMService.chat failed", exc_info=True)
            return ""

    async def chat_messages(
        self,
        messages: List[Dict[str, Any]],
        max_tokens: int = 8192,
        tools: Optional[List[dict]] = None,
    ) -> dict:
        """
        Multi-turn LLM call with optional tool-use.

        @param {list} messages - chat message history
        @param {int} max_tokens
        @param {list|None} tools - function-calling tool descriptors
        @returns {dict} with ``output`` and optionally ``tool_use``
        """
        if not self.available:
            return {"output": "", "error": "LLM service unavailable"}
        payload: Dict[str, Any] = {
            "model": "MiniMax-M2.5",
            "max_tokens": max_tokens,
            "messages": messages,
        }
        if tools:
            payload["tools"] = tools
        try:
            body = await self._post(payload, timeout=60)
            return self._parse_chat_response(body)
        except Exception as e:
            logger.debug("LLMService.chat_messages failed: %s", e)
            return {"output": "", "error": str(e)}

    # ── HTTP layer (aiohttp preferred, urllib fallback) ────────────

    async def _post(self, payload: dict, timeout: float = 60) -> dict:
        """POST to /v1/messages; returns parsed JSON body."""
        if self._session and not self._session.closed:
            return await self._post_aiohttp(payload, timeout)
        return await self._post_urllib(payload, timeout)

    async def _post_aiohttp(self, payload: dict, timeout: float) -> dict:
        """Async HTTP via aiohttp with connection pooling."""
        api_key = os.environ["MINIMAX_API_KEY"]
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
        async with self._session.post(
            "/v1/messages", json=payload, headers=headers,
            timeout=_aiohttp.ClientTimeout(total=timeout),
        ) as resp:
            return await resp.json()

    async def _post_urllib(self, payload: dict, timeout: float) -> dict:
        """Blocking HTTP via urllib, dispatched through run_in_executor."""
        base_url = self._cfg["base_url"]
        api_key = os.environ["MINIMAX_API_KEY"]
        loop = asyncio.get_event_loop()
        return await asyncio.wait_for(
            loop.run_in_executor(
                None, self._sync_post, base_url, api_key, payload, timeout,
            ),
            timeout=timeout + 5,
        )

    @staticmethod
    def _sync_post(base_url: str, api_key: str, payload: dict, timeout: float) -> dict:
        """Blocking POST helper for run_in_executor."""
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{base_url}/v1/messages", data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
        )
        with urllib.request.urlopen(req, timeout=int(timeout)) as resp:
            return json.loads(resp.read().decode())

    # ── response parsing ──────────────────────────────────────────

    @staticmethod
    def _extract_text(body: dict) -> str:
        """Extract plain text from an API response."""
        content = body.get("content", "")
        if isinstance(content, list) and content:
            return content[0].get("text", "").strip()
        if isinstance(content, str):
            return content.strip()
        return ""

    @staticmethod
    def _parse_chat_response(body: dict) -> dict:
        """Parse multi-turn response, extracting text + optional tool_use."""
        result: Dict[str, Any] = {"output": ""}
        content = body.get("content", "")
        if isinstance(content, list):
            for block in content:
                if block.get("type") == "tool_use":
                    result["tool_use"] = {
                        "id": block.get("id", ""),
                        "name": block.get("name", ""),
                        "arguments": block.get("input", {}),
                    }
                elif block.get("type") == "text":
                    result["output"] = block.get("text", "").strip()
                elif isinstance(block.get("text"), str):
                    result["output"] = block["text"].strip()
        elif isinstance(content, str):
            result["output"] = content.strip()
        return result

    # ── config ─────────────────────────────────────────────────────

    @staticmethod
    def _load_config() -> Optional[dict]:
        """Load LLM provider config from openclaw.json."""
        try:
            with open(_OPENCLAW_JSON, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            url = (cfg.get("models", {}).get("providers", {})
                   .get("minimax-cn", {}).get("baseUrl", ""))
            return {"base_url": url} if url else None
        except Exception:
            return None
