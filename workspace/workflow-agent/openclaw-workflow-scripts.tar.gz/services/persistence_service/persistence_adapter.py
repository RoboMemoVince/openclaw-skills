"""
PersistenceService -- ModuleBase adapter for SQLite task persistence.

Wraps TaskPersistence and TaskRecovery singletons, aligning the adapter
API with the underlying ``create``/``get``/``update`` method signatures.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from modules.base import ModuleBase

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.persistence_service")


class PersistenceService(ModuleBase):
    """
    Registry-managed wrapper around task persistence and recovery.

    @method save_task       Persist a task record.
    @method get_task        Retrieve a task by ID.
    @method update_status   Update task status.
    @method recover_pending Recover tasks that were interrupted.
    @method get_stats       Get persistence statistics.
    """

    @property
    def name(self) -> str:
        return "persistence_service"

    @property
    def version(self) -> str:
        return "1.1"

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, registry: "ModuleRegistry") -> None:
        from services.persistence_service.task_persistence import (
            get_task_persistence,
            get_task_recovery,
        )
        self._persistence = get_task_persistence()
        self._recovery = get_task_recovery()

    def save_task(self, task_id: str, content: str, **kwargs: Any) -> None:
        """
        Persist a new task record.

        @param {str} task_id - unique task identifier
        @param {str} content - task content / description
        @param {str} name    - optional task name (defaults to task_id)
        """
        name = kwargs.pop("name", task_id)
        input_data = kwargs.pop("input_data", None)
        self._persistence.create(task_id, name, content, input_data=input_data)

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a task record by ID.

        @param {str} task_id
        @returns {dict|None} task record as dict, or None
        """
        record = self._persistence.get(task_id)
        if record is None:
            return None
        from dataclasses import asdict
        return asdict(record)

    def update_status(self, task_id: str, status: str, **kwargs: Any) -> None:
        """
        Update the status (and optional fields) of an existing task.

        @param {str} task_id
        @param {str} status - new status value
        """
        self._persistence.update(task_id, status=status, **kwargs)

    def recover_pending(self) -> List[Dict[str, Any]]:
        """
        Recover tasks that were in-progress when the system went down.

        @returns {list[dict]} recoverable task records
        """
        records = self._recovery.get_recoverable_tasks()
        from dataclasses import asdict
        return [asdict(r) for r in records]

    def get_stats(self) -> Dict[str, Any]:
        """
        Return persistence statistics.

        @returns {dict} with keys: total, by_status, today
        """
        return self._persistence.get_stats()

    async def shutdown(self) -> None:
        if hasattr(self._persistence, "close"):
            self._persistence.close()
