"""
OpenClaw 任务持久化与恢复
提供任务状态持久化和中断恢复能力
"""

import json
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from threading import Lock

from modules.paths import DB_PATH as _DEFAULT_DB_PATH


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"          # 待处理
    RUNNING = "running"          # 执行中
    WAITING = "waiting"          # 等待中
    COMPLETED = "completed"     # 已完成
    FAILED = "failed"            # 失败
    CANCELLED = "cancelled"      # 已取消
    PAUSED = "paused"            # 已暂停


@dataclass
class TaskRecord:
    """任务记录"""
    task_id: str
    name: str
    status: str
    content: str
    input_data: Dict = field(default_factory=dict)
    output_data: Dict = field(default_factory=dict)
    error: str = ""
    progress: int = 0
    current_step: str = ""
    created_at: str = ""
    started_at: str = ""
    completed_at: str = ""
    metadata: Dict = field(default_factory=dict)


class TaskPersistence:
    """任务持久化存储"""
    
    DB_PATH = _DEFAULT_DB_PATH
    
    def __init__(self):
        self.db_path = self.DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()
        self._init_db()
    
    def _init_db(self):
        """初始化数据库"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    name TEXT,
                    status TEXT,
                    content TEXT,
                    input_data TEXT,
                    output_data TEXT,
                    error TEXT,
                    progress INTEGER DEFAULT 0,
                    current_step TEXT,
                    created_at TEXT,
                    started_at TEXT,
                    completed_at TEXT,
                    metadata TEXT
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_status ON tasks(status)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_created ON tasks(created_at)
            """)
            
            conn.commit()
            conn.close()
    
    def create(self, task_id: str, name: str, content: str, input_data: Dict = None) -> TaskRecord:
        """创建任务记录"""
        now = datetime.now().isoformat()
        
        record = TaskRecord(
            task_id=task_id,
            name=name,
            status=TaskStatus.PENDING.value,
            content=content,
            input_data=input_data or {},
            created_at=now
        )
        
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO tasks (task_id, name, status, content, input_data, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (record.task_id, record.name, record.status, record.content,
                  json.dumps(record.input_data, ensure_ascii=False), record.created_at))
            
            conn.commit()
            conn.close()
        
        return record
    
    def update(self, task_id: str, **kwargs) -> bool:
        """更新任务"""
        allowed_fields = {
            'status', 'output_data', 'error', 'progress', 
            'current_step', 'started_at', 'completed_at', 'metadata'
        }
        
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}
        if not updates:
            return False
        
        # 序列化复杂字段
        for key in ['output_data', 'metadata']:
            if key in updates and isinstance(updates[key], dict):
                updates[key] = json.dumps(updates[key], ensure_ascii=False)
        
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
            values = list(updates.values()) + [task_id]
            
            cursor.execute(f"UPDATE tasks SET {set_clause} WHERE task_id = ?", values)
            conn.commit()
            success = cursor.rowcount > 0
            conn.close()
        
        return success
    
    def get(self, task_id: str) -> Optional[TaskRecord]:
        """获取任务"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,))
            row = cursor.fetchone()
            conn.close()
        
        if not row:
            return None
        
        return self._row_to_record(row)
    
    def _row_to_record(self, row) -> TaskRecord:
        """行转记录"""
        return TaskRecord(
            task_id=row['task_id'],
            name=row['name'],
            status=row['status'],
            content=row['content'],
            input_data=json.loads(row['input_data'] or '{}'),
            output_data=json.loads(row['output_data'] or '{}'),
            error=row['error'] or '',
            progress=row['progress'],
            current_step=row['current_step'] or '',
            created_at=row['created_at'] or '',
            started_at=row['started_at'] or '',
            completed_at=row['completed_at'] or '',
            metadata=json.loads(row['metadata'] or '{}')
        )
    
    def list(self, status: str = None, limit: int = 100, offset: int = 0) -> List[TaskRecord]:
        """列出任务"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if status:
                cursor.execute(
                    "SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                    (status, limit, offset)
                )
            else:
                cursor.execute(
                    "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ? OFFSET ?",
                    (limit, offset)
                )
            
            rows = cursor.fetchall()
            conn.close()
        
        return [self._row_to_record(row) for row in rows]
    
    def get_pending(self) -> List[TaskRecord]:
        """获取待处理任务"""
        return self.list(status=TaskStatus.PENDING.value)
    
    def get_running(self) -> List[TaskRecord]:
        """获取运行中任务"""
        return self.list(status=TaskStatus.RUNNING.value)
    
    def delete(self, task_id: str) -> bool:
        """删除任务"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks WHERE task_id = ?", (task_id,))
            conn.commit()
            success = cursor.rowcount > 0
            conn.close()
        return success
    
    def clear_completed(self, days: int = 30) -> int:
        """清理已完成任务"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # 保留最近N天的记录
            cursor.execute("""
                DELETE FROM tasks 
                WHERE status IN (?, ?, ?) 
                AND completed_at < datetime('now', '-' || ? || ' days')
            """, (TaskStatus.COMPLETED.value, TaskStatus.FAILED.value, 
                  TaskStatus.CANCELLED.value, days))
            
            deleted = cursor.rowcount
            conn.commit()
            conn.close()
        
        return deleted
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            stats = {}
            
            # 总数
            cursor.execute("SELECT COUNT(*) FROM tasks")
            stats['total'] = cursor.fetchone()[0]
            
            # 按状态统计
            cursor.execute("""
                SELECT status, COUNT(*) as count 
                FROM tasks 
                GROUP BY status
            """)
            stats['by_status'] = {row[0]: row[1] for row in cursor.fetchall()}
            
            # 今日统计
            cursor.execute("""
                SELECT COUNT(*) FROM tasks 
                WHERE date(created_at) = date('now')
            """)
            stats['today'] = cursor.fetchone()[0]
            
            conn.close()
        
        return stats


class TaskRecovery:
    """任务恢复"""
    
    def __init__(self, persistence: TaskPersistence = None):
        self.persistence = persistence or TaskPersistence()
    
    def get_recoverable_tasks(self) -> List[TaskRecord]:
        """获取可恢复的任务"""
        # 查找运行中但超时的任务
        # 这里简化处理，返回所有非终态任务
        return self.persistence.list(status=TaskStatus.RUNNING.value)
    
    def recover(self, task_id: str) -> Optional[TaskRecord]:
        """恢复任务"""
        task = self.persistence.get(task_id)
        if not task:
            return None
        
        # 检查是否可以恢复
        if task.status in [TaskStatus.COMPLETED.value, TaskStatus.CANCELLED.value]:
            return None
        
        # 更新状态为待处理
        self.persistence.update(
            task_id,
            status=TaskStatus.PENDING.value,
            metadata={**task.metadata, 'recovered_at': datetime.now().isoformat()}
        )
        
        return self.persistence.get(task_id)


# 全局实例
_task_persistence: Optional[TaskPersistence] = None
_task_recovery: Optional[TaskRecovery] = None


def get_task_persistence() -> TaskPersistence:
    """获取任务持久化实例"""
    global _task_persistence
    if _task_persistence is None:
        _task_persistence = TaskPersistence()
    return _task_persistence


def get_task_recovery() -> TaskRecovery:
    """获取任务恢复实例"""
    global _task_recovery
    if _task_recovery is None:
        _task_recovery = TaskRecovery(get_task_persistence())
    return _task_recovery


# 导出
__all__ = [
    'TaskStatus', 'TaskRecord', 
    'TaskPersistence', 'TaskRecovery',
    'get_task_persistence', 'get_task_recovery'
]
