#!/usr/bin/env python3
"""
Unified Error Handling - Consistent error codes, exceptions, and error recovery
"""

import os
import sys
import traceback
import json
import uuid
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging


# 错误码定义
class ErrorCode(Enum):
    # 系统错误 (E1000-E1999)
    E1000 = "E1000"  # 未知错误
    E1001 = "E1001"  # 超时
    E1002 = "E1002"  # 认证失败
    E1003 = "E1003"  # 权限不足
    E1004 = "E1004"  # 资源不足
    
    # MCP错误 (E2000-E2999)
    E2000 = "E2000"  # MCP未找到
    E2001 = "E2001"  # MCP连接失败
    E2002 = "E2002"  # MCP调用失败
    E2003 = "E2003"  # MCP响应无效
    
    # 任务错误 (E3000-E3999)
    E3000 = "E3000"  # 任务执行失败
    E3001 = "E3001"  # 任务参数无效
    E3002 = "E3002"  # 任务超时
    E3003 = "E3003"  # 任务被取消
    
    # Agent错误 (E4000-E4999)
    E4000 = "E4000"  # Agent初始化失败
    E4001 = "E4001"  # Agent响应无效
    E4002 = "E4002"  # Agent超时
    
    # 配置错误 (E5000-E5999)
    E5000 = "E5000"  # 配置缺失
    E5001 = "E5001"  # 配置无效
    E5002 = "E5002"  # 配置无法加载


# 错误严重级别
class ErrorSeverity(Enum):
    LOW = "low"       # 低 - 仅记录
    MEDIUM = "medium" # 中 - 需要关注
    HIGH = "high"     # 高 - 需要处理
    CRITICAL = "critical"  # 严重 - 需要立即处理


@dataclass
class ErrorDetail:
    code: ErrorCode
    message: str
    severity: ErrorSeverity
    context: Dict = field(default_factory=dict)
    traceback: Optional[str] = None
    timestamp: float = field(default_factory=lambda: datetime.now().timestamp())
    error_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    recoverable: bool = True
    suggestion: Optional[str] = None


class OpenClawException(Exception):
    """OpenClaw统一异常基类"""
    
    def __init__(
        self, 
        code: ErrorCode, 
        message: str, 
        severity: ErrorSeverity = ErrorSeverity.MEDIUM,
        context: Optional[Dict] = None,
        recoverable: bool = True,
        suggestion: Optional[str] = None
    ):
        self.code = code
        self.message = message
        self.severity = severity
        self.context = context or {}
        self.recoverable = recoverable
        self.suggestion = suggestion
        self.error_id = str(uuid.uuid4())[:8]
        
        super().__init__(f"[{code.value}] {message}")
    
    def to_dict(self) -> Dict:
        return {
            "error_id": self.error_id,
            "code": self.code.value,
            "message": self.message,
            "severity": self.severity.value,
            "context": self.context,
            "recoverable": self.recoverable,
            "suggestion": self.suggestion,
            "timestamp": datetime.now().timestamp()
        }


# 专用异常类
class SystemException(OpenClawException):
    def __init__(self, code: ErrorCode, message: str, **kwargs):
        super().__init__(code, message, **kwargs)


class MCPException(OpenClawException):
    def __init__(self, code: ErrorCode, message: str, **kwargs):
        super().__init__(code, message, **kwargs)


class TaskException(OpenClawException):
    def __init__(self, code: ErrorCode, message: str, **kwargs):
        super().__init__(code, message, **kwargs)


class AgentException(OpenClawException):
    def __init__(self, code: ErrorCode, message: str, **kwargs):
        super().__init__(code, message, **kwargs)


class ConfigException(OpenClawException):
    def __init__(self, code: ErrorCode, message: str, **kwargs):
        super().__init__(code, message, **kwargs)


class ErrorHandler:
    """统一错误处理器"""
    
    def __init__(self):
        self.errors: List[ErrorDetail] = []
        self.handlers: Dict[ErrorCode, Callable] = {}
        self.recovery_strategies: Dict[ErrorCode, Callable] = {}
        self._init_error_category_bridge()

    def _init_error_category_bridge(self) -> None:
        """Build the ErrorCode -> modules-layer ErrorCategory mapping."""
        try:
            from modules.core_types import ErrorCategory
            self._ErrorCategory = ErrorCategory
        except ImportError:
            self._ErrorCategory = None

    def to_error_category(self, code: ErrorCode) -> Optional[Any]:
        """
        Bridge an ErrorCode to the modules-layer ErrorCategory.

        @param {ErrorCode} code
        @returns {ErrorCategory|None} TRANSIENT / PERMANENT / DEGRADABLE
        """
        if self._ErrorCategory is None:
            return None
        return self._ErrorCategory.from_error_code(code.value)
        
    def register_handler(self, code: ErrorCode, handler: Callable):
        """注册错误处理器"""
        self.handlers[code] = handler
    
    def register_recovery(self, code: ErrorCode, recovery: Callable):
        """注册恢复策略"""
        self.recovery_strategies[code] = recovery
    
    def handle(self, error: Exception, context: Optional[Dict] = None) -> ErrorDetail:
        """处理错误"""
        # 转换为ErrorDetail
        if isinstance(error, OpenClawException):
            detail = ErrorDetail(
                code=error.code,
                message=error.message,
                severity=error.severity,
                context=error.context or context or {},
                recoverable=error.recoverable,
                suggestion=error.suggestion
            )
        else:
            # 未知错误
            detail = ErrorDetail(
                code=ErrorCode.E1000,
                message=str(error),
                severity=ErrorSeverity.MEDIUM,
                context=context or {},
                traceback=traceback.format_exc(),
                recoverable=False
            )
        
        # 记录错误
        self.errors.append(detail)
        
        # 调用注册的处理器
        if detail.code in self.handlers:
            try:
                self.handlers[detail.code](detail)
            except Exception as e:
                print(f"[ErrorHandler] Handler error: {e}")
        
        # 打印错误信息
        self._log_error(detail)
        
        return detail
    
    _logger = logging.getLogger("openclaw.error_handler")

    _TRANSLATIONS: Dict[str, str] = {
        "circuit breaker open": "服务暂时过载，请稍后重试",
        "executor unavailable": "执行引擎暂不可用，请稍后重试",
        "timeout": "任务执行超时，请缩小任务范围或增加超时时间",
        "mini-agent not found": "执行环境未就绪，请联系管理员",
        "llm fallback exhausted": "AI 服务繁忙，请稍后重试",
        "llm 服务暂时不可用": "AI 服务暂时不可用，请稍后重试",
        "abandoned due to timeout or deadlock": "任务因超时被终止，请缩小任务范围",
        "connection": "网络连接失败，请检查网络后重试",
        "permission": "权限不足，请检查配置",
    }

    def translate_error(self, error: str) -> str:
        """
        Translate a raw technical error string into a user-friendly Chinese
        message using pattern matching.

        @param {str} error - raw error string
        @returns {str} user-friendly message
        """
        if not error:
            return ""
        low = error.lower()
        for pattern, friendly in self._TRANSLATIONS.items():
            if pattern in low:
                return friendly
        if "connection" in low or "econnrefused" in low:
            return "网络连接失败，请检查网络后重试"
        if "permission" in low or "401" in low or "403" in low:
            return "权限不足，请检查配置"
        if any(kw in low for kw in ("traceback", "exception", "error")):
            return f"执行出错: {error[:150]}"
        return error[:200]

    def _log_error(self, detail: ErrorDetail):
        """记录错误日志"""
        level = {
            ErrorSeverity.LOW: logging.INFO,
            ErrorSeverity.MEDIUM: logging.WARNING,
            ErrorSeverity.HIGH: logging.ERROR,
            ErrorSeverity.CRITICAL: logging.CRITICAL
        }.get(detail.severity, logging.ERROR)

        log_msg = f"[{detail.code.value}] {detail.message}"
        if detail.context:
            log_msg += f" | Context: {json.dumps(detail.context, default=str)}"
        if detail.suggestion:
            log_msg += f" | Suggestion: {detail.suggestion}"

        self._logger.log(level, log_msg)
    
    def recover(self, error: Exception) -> Optional[Any]:
        """尝试恢复"""
        if isinstance(error, OpenClawException) and error.code in self.recovery_strategies:
            try:
                return self.recovery_strategies[error.code](error)
            except Exception as e:
                print(f"[ErrorHandler] Recovery failed: {e}")
        return None
    
    def get_error_summary(self) -> Dict:
        """获取错误摘要"""
        if not self.errors:
            return {"total": 0, "by_severity": {}, "by_code": {}}
        
        by_severity = {}
        by_code = {}
        
        for error in self.errors:
            # 按严重级别统计
            sev = error.severity.value
            by_severity[sev] = by_severity.get(sev, 0) + 1
            
            # 按错误码统计
            code = error.code.value
            by_code[code] = by_code.get(code, 0) + 1
        
        return {
            "total": len(self.errors),
            "by_severity": by_severity,
            "by_code": by_code,
            "recent": [
                {
                    "error_id": e.error_id,
                    "code": e.code.value,
                    "message": e.message,
                    "timestamp": e.timestamp
                }
                for e in self.errors[-10:]
            ]
        }
    
    def clear(self):
        """清除错误历史"""
        self.errors.clear()


# 全局错误处理器
_error_handler: Optional[ErrorHandler] = None


def get_error_handler() -> ErrorHandler:
    """获取全局错误处理器"""
    global _error_handler
    if _error_handler is None:
        _error_handler = ErrorHandler()
    return _error_handler


# 便捷函数
def raise_error(
    code: ErrorCode, 
    message: str, 
    severity: ErrorSeverity = ErrorSeverity.MEDIUM,
    context: Optional[Dict] = None,
    recoverable: bool = True,
    suggestion: Optional[str] = None
):
    """抛出统一异常"""
    if code.value.startswith("E1"):
        raise SystemException(code, message, severity, context, recoverable, suggestion)
    elif code.value.startswith("E2"):
        raise MCPException(code, message, severity, context, recoverable, suggestion)
    elif code.value.startswith("E3"):
        raise TaskException(code, message, severity, context, recoverable, suggestion)
    elif code.value.startswith("E4"):
        raise AgentException(code, message, severity, context, recoverable, suggestion)
    elif code.value.startswith("E5"):
        raise ConfigException(code, message, severity, context, recoverable, suggestion)
    else:
        raise OpenClawException(code, message, severity, context, recoverable, suggestion)


if __name__ == "__main__":
    # 测试统一错误处理
    print("=" * 50)
    print("Testing Unified Error Handling")
    print("=" * 50)
    
    handler = get_error_handler()
    
    # 注册恢复策略
    handler.register_recovery(ErrorCode.E3001, lambda e: "使用默认参数重试")
    
    # 测试抛出异常
    print("\n1. 测试抛出异常:")
    try:
        raise_error(
            ErrorCode.E3001,
            "任务参数无效",
            severity=ErrorSeverity.HIGH,
            context={"param": "task_id", "value": None},
            suggestion="请提供有效的任务ID"
        )
    except OpenClawException as e:
        detail = handler.handle(e)
        print(f"  Error ID: {detail.error_id}")
        print(f"  Code: {detail.code.value}")
        print(f"  Recoverable: {detail.recoverable}")
    
    # 测试错误摘要
    print("\n2. 错误摘要:")
    summary = handler.get_error_summary()
    print(json.dumps(summary, indent=2))
