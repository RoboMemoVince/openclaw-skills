"""
ErrorService -- ModuleBase adapter for the unified error handling system.

Wraps the ErrorHandler singleton and exposes it through the module registry.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from modules.base import ModuleBase

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry


class ErrorService(ModuleBase):
    """
    Registry-managed wrapper around the unified error handler.

    @method translate      Translate a technical error to a user-friendly message.
    @method record         Record an exception via the handler and return an ErrorDetail.
    @method get_summary    Get aggregated error statistics.
    @method handler        Return the global ErrorHandler instance.
    """

    @property
    def name(self) -> str:
        return "error_service"

    @property
    def version(self) -> str:
        return "1.1"

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, registry: "ModuleRegistry") -> None:
        from services.error_service.unified_error import get_error_handler
        self._handler = get_error_handler()

    @property
    def handler(self):
        """Return the global ErrorHandler instance."""
        return self._handler

    def translate(self, error: str) -> str:
        """
        Translate a technical error string to a user-friendly message.

        @param {str} error - raw technical error
        @returns {str} user-friendly message in Chinese
        """
        return self._handler.translate_error(error)

    def record(self, error: Exception, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Record an exception via the unified handler.

        @param {Exception} error
        @param {dict|None} context - optional contextual info
        @returns {dict} ErrorDetail as dict
        """
        from dataclasses import asdict
        detail = self._handler.handle(error, context=context)
        return asdict(detail)

    def get_summary(self) -> Dict[str, Any]:
        """
        Get aggregated error statistics.

        @returns {dict} with total, by_severity, by_code, recent
        """
        return self._handler.get_error_summary()
