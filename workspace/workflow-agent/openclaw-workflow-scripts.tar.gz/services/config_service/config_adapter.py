"""
ConfigService -- ModuleBase adapter for the unified configuration manager.

Wraps the ConfigManager singleton and exposes it through the module registry.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from modules.base import ModuleBase

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry


class ConfigService(ModuleBase):
    """
    Registry-managed wrapper around the config manager.

    @method get      Retrieve a config value by dotted path.
    @method reload   Force-reload all config files.
    """

    @property
    def name(self) -> str:
        return "config_service"

    @property
    def version(self) -> str:
        return "1.0"

    @property
    def dependencies(self) -> List[str]:
        return []

    async def initialize(self, registry: "ModuleRegistry") -> None:
        from services.config_service.config_manager import get_config
        self._config = get_config()

    def get(self, path: str, default: Any = None) -> Any:
        """
        Retrieve a config value by dotted path (e.g. 'main.gateway.host').

        @param {str} path - dotted config path
        @param default - fallback value
        @returns config value or default
        """
        return self._config.get(path, default)

    def reload(self) -> None:
        """Force-reload all config files."""
        if hasattr(self._config, "reload"):
            self._config.reload()

    async def shutdown(self) -> None:
        if hasattr(self._config, "stop"):
            self._config.stop()
