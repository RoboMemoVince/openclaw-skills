"""
OpenClaw 统一配置中心
提供配置的加载、验证、热重载能力
"""

import json
import yaml
import time
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from threading import Lock
try:
    from watchdog.observers import Observer as _WatchdogObserver
    from watchdog.events import FileSystemEventHandler as _FileSystemEventHandler
except ImportError:
    _WatchdogObserver = None
    _FileSystemEventHandler = object

from modules.paths import CONFIG_DIR as _DEFAULT_CONFIG_DIR, MAIN_CONFIG as _DEFAULT_MAIN_CONFIG


@dataclass
class ConfigSection:
    """配置区块"""
    name: str
    data: Dict[str, Any]
    file_path: str = ""
    reloadable: bool = True


class ConfigChangeHandler(_FileSystemEventHandler):
    """配置变更监听器"""
    
    def __init__(self, config_manager, config_file: str):
        self.config_manager = config_manager
        self.config_file = config_file
        self.last_reload = 0
        self.debounce_seconds = 1
    
    def on_modified(self, event):
        if event.src_path.endswith(self.config_file.replace("/", "\\")):
            # 防抖
            now = time.time()
            if now - self.last_reload > self.debounce_seconds:
                self.last_reload = now
                print(f"检测到配置变更: {self.config_file}")
                self.config_manager.reload()


class ConfigManager:
    """统一配置管理器"""
    
    CONFIG_DIR = _DEFAULT_CONFIG_DIR
    
    def __init__(self):
        self.config_dir = self.CONFIG_DIR
        self.configs: Dict[str, ConfigSection] = {}
        self._lock = Lock()
        self._observers: Dict[str, Observer] = {}
        self._listeners: list = []
        
        # 确保配置目录存在
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载配置
        self._load_all_configs()
    
    def _load_all_configs(self):
        """加载所有配置文件"""
        # 主配置
        main_config = self.config_dir / "main.yaml"
        if main_config.exists():
            self._load_config_file("main", main_config)
        
        # MCP配置
        mcp_config = self.config_dir / "mcp.yaml"
        if mcp_config.exists():
            self._load_config_file("mcp", mcp_config)
        
        # Agent配置
        agent_config = self.config_dir / "agents.yaml"
        if agent_config.exists():
            self._load_config_file("agents", agent_config)
        
        # 通知配置
        notification_config = self.config_dir / "notification.yaml"
        if notification_config.exists():
            self._load_config_file("notification", notification_config)
        
        # 工作流配置
        workflow_config = self.config_dir / "workflow.yaml"
        if workflow_config.exists():
            self._load_config_file("workflow", workflow_config)
        
        # 插件配置
        plugins_config = self.config_dir / "plugins.yaml"
        if plugins_config.exists():
            self._load_config_file("plugins", plugins_config)
        
        # 加载遗留配置（兼容）
        self._load_legacy_configs()
    
    def _load_config_file(self, name: str, file_path: Path):
        """加载单个配置文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                if file_path.suffix == '.yaml':
                    data = yaml.safe_load(f) or {}
                else:
                    data = json.load(f)
                
                self.configs[name] = ConfigSection(
                    name=name,
                    data=data,
                    file_path=str(file_path),
                    reloadable=True
                )
                print(f"加载配置: {name}")
        except Exception as e:
            print(f"加载配置失败 {name}: {e}")
    
    def _load_legacy_configs(self):
        """加载遗留配置文件"""
        # 兼容旧的openclaw.json
        legacy_config = _DEFAULT_MAIN_CONFIG
        if legacy_config.exists():
            try:
                with open(legacy_config, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # 映射到新配置
                    if 'agents' in data:
                        self.configs['agents'] = ConfigSection(
                            name='agents',
                            data=data['agents'],
                            file_path=str(legacy_config)
                        )
                    if 'channels' in data:
                        self.configs['channels'] = ConfigSection(
                            name='channels',
                            data=data['channels'],
                            file_path=str(legacy_config)
                        )
            except Exception as e:
                print(f"加载遗留配置失败: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值 (支持点号访问)"""
        with self._lock:
            parts = key.split(".")
            if not parts:
                return default
            
            # 查找配置区块
            section = self.configs.get(parts[0])
            if not section:
                return default
            
            # 逐层获取
            value = section.data
            for part in parts[1:]:
                if isinstance(value, dict):
                    value = value.get(part)
                    if value is None:
                        return default
                else:
                    return default
            
            return value
    
    def get_section(self, name: str) -> Optional[Dict]:
        """获取配置区块"""
        with self._lock:
            section = self.configs.get(name)
            return section.data if section else None
    
    def set(self, key: str, value: Any):
        """设置配置值"""
        with self._lock:
            parts = key.split(".")
            if not parts:
                return
            
            section_name = parts[0]
            if section_name not in self.configs:
                self.configs[section_name] = ConfigSection(
                    name=section_name,
                    data={}
                )
            
            # 逐层设置
            data = self.configs[section_name].data
            for part in parts[1:-1]:
                if part not in data:
                    data[part] = {}
                data = data[part]
            
            data[parts[-1]] = value
    
    def save(self, section: str = None):
        """保存配置"""
        with self._lock:
            if section:
                sections = [self.configs.get(section)]
            else:
                sections = self.configs.values()
            
            for sec in sections:
                if not sec or not sec.file_path:
                    continue
                
                file_path = Path(sec.file_path)
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        if file_path.suffix == '.yaml':
                            yaml.dump(sec.data, f, allow_unicode=True, default_flow_style=False)
                        else:
                            json.dump(sec.data, f, indent=2, ensure_ascii=False)
                    print(f"保存配置: {sec.name}")
                except Exception as e:
                    print(f"保存配置失败 {sec.name}: {e}")
    
    def reload(self):
        """重新加载配置"""
        print("重新加载配置...")
        self._load_all_configs()
        
        # 通知监听器
        for listener in self._listeners:
            try:
                listener(self.configs)
            except Exception as e:
                print(f"配置变更通知失败: {e}")
    
    def watch(self, section: str = None):
        """监听配置变更"""
        if section:
            sections = [section]
        else:
            sections = list(self.configs.keys())
        
        for sec in sections:
            config = self.configs.get(sec)
            if not config or not config.file_path:
                continue
            
            if sec in self._observers:
                continue
            
            # 创建观察者
            file_path = Path(config.file_path)
            if not file_path.exists():
                continue
            
            if _WatchdogObserver is None:
                continue
            observer = _WatchdogObserver()
            handler = ConfigChangeHandler(self, str(file_path))
            observer.schedule(handler, str(file_path.parent), recursive=False)
            observer.start()
            self._observers[sec] = observer
            print(f"监听配置变更: {sec}")
    
    def stop_watch(self):
        """停止监听"""
        for observer in self._observers.values():
            observer.stop()
        self._observers.clear()
    
    def on_change(self, listener):
        """注册配置变更监听器"""
        self._listeners.append(listener)
    
    def to_dict(self) -> Dict:
        """导出所有配置"""
        with self._lock:
            return {name: sec.data for name, sec in self.configs.items()}


# 全局配置管理器实例
_config_manager: Optional[ConfigManager] = None


def get_config() -> ConfigManager:
    """获取配置管理器实例"""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


# 导出
__all__ = ['ConfigManager', 'ConfigSection', 'get_config']
