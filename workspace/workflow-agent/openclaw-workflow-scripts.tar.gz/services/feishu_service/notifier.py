"""
Shared Feishu notification builder used by scripts and MCP server.
"""

from __future__ import annotations

from datetime import datetime

from services.feishu_service.client import FeishuClient


class FeishuNotifierService:
    """
    @description 飞书通知服务，封装任务开始/结束消息卡片。
    """

    def __init__(self, app_id: str | None = None, app_secret: str | None = None):
        self.client = FeishuClient(app_id=app_id, app_secret=app_secret)

    def send_message(
        self,
        receive_id: str,
        receive_id_type: str = "open_id",
        msg_type: str = "interactive",
        content: dict | None = None,
    ) -> bool:
        """
        @description 发送底层飞书消息。
        @returns {bool}
        """

        return self.client.send_message(
            receive_id=receive_id,
            receive_id_type=receive_id_type,
            msg_type=msg_type,
            content=content,
        )

    def build_task_start_card(
        self,
        task_name: str,
        task_target: str = "",
        executor: str = "OpenClaw",
    ) -> dict:
        """
        @description 构建任务开始卡片。
        @returns {dict}
        """

        return {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": "任务正在处理"},
                "template": "blue",
            },
            "elements": [
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**任务名称:** {task_name[:100]}"}},
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**任务目标:** {task_target[:150]}"}},
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**执行者:** {executor}"}},
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**开始时间:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    },
                },
                {"tag": "div", "text": {"tag": "lark_md", "content": "正在执行中，请稍候..."}},
            ],
        }

    def build_task_complete_card(
        self,
        task_name: str,
        result: str,
        status: str = "success",
        duration: int = 0,
        mcp_used: list | None = None,
    ) -> dict:
        """
        @description 构建任务结束卡片。
        @returns {dict}
        """

        status_icon = "✅" if status == "success" else "❌"
        status_text = "任务完成" if status == "success" else "任务失败"
        template = "green" if status == "success" else "red"
        result_preview = (result or "")[:300].replace("\n", "\n\n")
        mcp_info = f"\n\n**使用工具:** {', '.join(mcp_used)}" if mcp_used else ""
        card = {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": f"{status_icon} {status_text}"},
                "template": template,
            },
            "elements": [
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**任务名称:** {task_name[:100]}"}},
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**耗时:** {duration} 秒"}},
                {"tag": "div", "text": {"tag": "lark_md", "content": f"**结果:**\n{result_preview}{mcp_info}"}},
            ],
        }
        if len(result or "") > 300:
            card["elements"].append(
                {"tag": "div", "text": {"tag": "lark_md", "content": "...\n\n结果过长，已截断显示。"}}
            )
        return card

    def send_task_start(
        self,
        receive_id: str,
        task_name: str,
        task_target: str = "",
        receive_id_type: str = "open_id",
    ) -> bool:
        """
        @description 发送任务开始通知。
        @returns {bool}
        """

        return self.send_message(
            receive_id=receive_id,
            receive_id_type=receive_id_type,
            msg_type="interactive",
            content=self.build_task_start_card(task_name, task_target),
        )

    def send_task_complete(
        self,
        receive_id: str,
        task_name: str,
        result: str,
        status: str = "success",
        duration: int = 0,
        mcp_used: list | None = None,
        receive_id_type: str = "open_id",
    ) -> bool:
        """
        @description 发送任务完成通知。
        @returns {bool}
        """

        return self.send_message(
            receive_id=receive_id,
            receive_id_type=receive_id_type,
            msg_type="interactive",
            content=self.build_task_complete_card(task_name, result, status, duration, mcp_used),
        )

    def send_text_message(
        self,
        receive_id: str,
        text: str,
        receive_id_type: str = "open_id",
    ) -> bool:
        """
        @description 发送文本消息。
        @returns {bool}
        """

        return self.send_message(
            receive_id=receive_id,
            receive_id_type=receive_id_type,
            msg_type="text",
            content={"text": text},
        )
