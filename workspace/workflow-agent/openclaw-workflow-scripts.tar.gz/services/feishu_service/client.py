"""
Shared Feishu API client used by workflow entrypoints and MCP helpers.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any, Dict, Optional

import requests


class FeishuClient:
    """
    @description 轻量 Feishu API 客户端，负责 token、消息发送、消息读取和用户信息查询。
    """

    def __init__(self, app_id: str | None = None, app_secret: str | None = None):
        self.app_id = app_id or os.getenv("FEISHU_APP_ID", "")
        self.app_secret = app_secret or os.getenv("FEISHU_APP_SECRET", "")
        self._token: str | None = None
        self._token_expires_at: float | None = None

    def get_tenant_access_token(self) -> Optional[str]:
        """
        @description 获取并缓存 tenant_access_token。
        @returns {str | None}
        """

        if self._token and self._token_expires_at:
            if datetime.now().timestamp() < self._token_expires_at:
                return self._token

        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        payload = {"app_id": self.app_id, "app_secret": self.app_secret}
        try:
            response = requests.post(url, json=payload, timeout=10)
            result = response.json()
        except Exception:
            return None

        if result.get("code") != 0:
            return None

        self._token = result.get("tenant_access_token")
        expire_seconds = result.get("expire", 7200)
        self._token_expires_at = datetime.now().timestamp() + expire_seconds - 300
        return self._token

    def send_message(
        self,
        receive_id: str,
        receive_id_type: str = "open_id",
        msg_type: str = "interactive",
        content: dict | None = None,
    ) -> bool:
        """
        @description 发送飞书消息。
        @param {str} receive_id
        @param {str} receive_id_type
        @param {str} msg_type
        @param {dict | None} content
        @returns {bool}
        """

        token = self.get_tenant_access_token()
        if not token:
            return False

        url = "https://open.feishu.cn/open-apis/im/v1/messages"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
        }
        params = {"receive_id_type": receive_id_type}
        message_content = content or {}
        if msg_type == "text":
            message_content = {"text": message_content.get("text", "")}
        payload = {
            "receive_id": receive_id,
            "msg_type": msg_type,
            "content": json.dumps(message_content, ensure_ascii=False),
        }
        try:
            response = requests.post(url, params=params, headers=headers, json=payload, timeout=10)
            result = response.json()
            return result.get("code") == 0
        except Exception:
            return False

    def get_message_content(self, message_id: str) -> Optional[str]:
        """
        @description 通过消息 ID 获取消息体内容。
        @param {str} message_id
        @returns {str | None}
        """

        token = self.get_tenant_access_token()
        if not token:
            return None

        url = f"https://open.feishu.cn/open-apis/im/v1/messages/{message_id}"
        headers = {"Authorization": f"Bearer {token}"}
        try:
            response = requests.get(url, headers=headers, timeout=10)
            result = response.json()
        except Exception:
            return None

        if result.get("code") != 0:
            return None

        data = result.get("data", {})
        msg_type = data.get("msg_type", "text")
        body = data.get("body", {})
        if msg_type == "text":
            return body.get("content", "")
        return json.dumps(body, ensure_ascii=False)

    def get_user_info(self, user_id: str) -> Dict[str, str]:
        """
        @description 获取用户基本信息。
        @param {str} user_id
        @returns {dict[str, str]}
        """

        token = self.get_tenant_access_token()
        if not token:
            return {"name": "未知用户", "open_id": user_id}

        url = f"https://open.feishu.cn/open-apis/auth/v3/user_info/{user_id}"
        headers = {"Authorization": f"Bearer {token}"}
        try:
            response = requests.get(url, headers=headers, timeout=10)
            result = response.json()
        except Exception:
            return {"name": "未知用户", "open_id": user_id}

        if result.get("code") != 0:
            return {"name": "未知用户", "open_id": user_id}

        data = result.get("data", {})
        return {
            "name": data.get("name", "未知用户"),
            "open_id": data.get("open_id", user_id),
            "union_id": data.get("union_id", ""),
            "avatar": data.get("avatar", ""),
        }
