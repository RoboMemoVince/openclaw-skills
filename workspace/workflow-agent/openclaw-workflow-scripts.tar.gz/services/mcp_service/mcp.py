"""
MCPService -- unified MCP management.

Capabilities:
  - Static: resolve groups + write mcp.json for mini-agent subprocesses
  - Dynamic: hot-reload additional groups at runtime
  - Direct: invoke MCP tools via stdio JSON-RPC (with initialize handshake)
  - Discovery: list_tools() for LLM function-calling integration
  - Process pool: reuse long-lived MCP server connections (L3)
"""

from __future__ import annotations

import asyncio
import dataclasses
import hashlib
import json
import logging
import os
import shutil
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set

try:
    import yaml as _yaml
except ImportError:
    _yaml = None  # type: ignore

from modules.base import ModuleBase

if TYPE_CHECKING:
    from modules.registry import ModuleRegistry

logger = logging.getLogger("openclaw.mcp_service")

_OPENCLAW_ROOT = Path(__file__).resolve().parent.parent.parent
_GROUPS_PATH = _OPENCLAW_ROOT / "config" / "mcp-groups.yaml"
_REGISTRY_PATH = _OPENCLAW_ROOT / "config" / "mcp-registry.yaml"
_MCP_JSON = Path.home() / ".mini-agent" / "config" / "mcp.json"
_JSONRPC_ID = 0
_POOL_IDLE_TIMEOUT = 120.0
_POOL_CHECK_INTERVAL = 30.0

_DEFAULT_GROUPS_CONFIG = {
    "default": {
        "mcps": [
            {
                "name": "minimax",
                "package": "minimax-coding-plan-mcp",
                "command": "uvx",
                "args": ["minimax-coding-plan-mcp"],
                "env": {
                    "MINIMAX_API_KEY": "${MINIMAX_API_KEY}",
                    "MINIMAX_API_HOST": "https://api.minimaxi.com",
                },
                "disabled": False,
            },
            {
                "name": "sqlite",
                "package": "mcp-server-sqlite",
                "command": "uvx",
                "args": ["mcp-server-sqlite", "--db-path", "/home/lkx/data.db"],
                "disabled": False,
            },
        ]
    },
    "browser": {
        "mcps": [
            {
                "name": "puppeteer",
                "package": "puppeteer-mcp-server",
                "command": "npx",
                "args": ["-y", "puppeteer-mcp-server"],
                "disabled": False,
            }
        ]
    },
    "file": {
        "mcps": [
            {
                "name": "filesystem",
                "package": "@modelcontextprotocol/server-filesystem",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-filesystem", "/home/lkx"],
                "disabled": False,
            }
        ]
    },
    "memory": {
        "mcps": [
            {
                "name": "memory",
                "package": "@modelcontextprotocol/server-memory",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-memory"],
                "disabled": False,
            }
        ]
    },
    "search": {
        "mcps": [
            {
                "name": "brave-search",
                "package": "@brave/brave-search-mcp-server",
                "command": "npx",
                "args": ["-y", "@brave/brave-search-mcp-server"],
                "env": {"BRAVE_API_KEY": "${BRAVE_SEARCH_API_KEY}"},
                "disabled": False,
            }
        ]
    },
    "github": {
        "mcps": [
            {
                "name": "github",
                "package": "@modelcontextprotocol/server-github",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-github"],
                "env": {"GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"},
                "disabled": False,
            }
        ]
    },
    "database": {
        "mcps": [
            {
                "name": "postgres",
                "package": "@modelcontextprotocol/server-postgres",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-postgres"],
                "env": {"DATABASE_URL": "${DATABASE_URL}"},
                "disabled": False,
            }
        ]
    },
    "analysis": {
        "mcps": [
            {
                "name": "sequential-thinking",
                "package": "@modelcontextprotocol/server-sequential-thinking",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-sequential-thinking"],
                "disabled": False,
            }
        ]
    },
    "pdf": {
        "mcps": [
            {
                "name": "pdf",
                "package": "@modelcontextprotocol/server-pdf",
                "command": "npx",
                "args": ["-y", "@modelcontextprotocol/server-pdf"],
                "disabled": False,
            }
        ]
    },
    "keyword_mappings": {
        "browser": ["浏览器", "网页", "自动化", "browser", "automation", "scrap", "抓取"],
        "file": ["文件", "目录", "读取", "写入", "read", "write"],
        "memory": ["记忆", "知识库", "memory", "knowledge", "kb"],
        "search": ["搜索", "search", "查找", "google"],
        "github": ["github", "git", "仓库", "pr", "issue"],
        "database": ["数据库", "sql", "postgres", "mysql", "database"],
        "analysis": ["思考", "分析", "think", "analyze", "reasoning"],
        "pdf": ["pdf", "文档", "document"],
    },
}


@dataclasses.dataclass
class _PooledConnection:
    """A long-lived MCP server process kept for reuse."""
    key: str
    proc: asyncio.subprocess.Process
    reader: Any
    writer: Any
    lock: asyncio.Lock
    last_used: float = dataclasses.field(default_factory=time.monotonic)


class MCPService(ModuleBase):

    @property
    def name(self) -> str:
        return "mcp_service"

    @property
    def version(self) -> str:
        return "2.0"

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._config = self._load_groups_config()
        self._registry_config = self._load_registry_config()
        self._last_hash = ""
        self._unhealthy: Set[str] = set()
        self._tool_catalog: Optional[List[dict]] = None
        self._pool: Dict[str, _PooledConnection] = {}
        self._pool_lock = asyncio.Lock()
        self._reaper_task: Optional[asyncio.Task] = None
        asyncio.create_task(self._warm_default_pool())

    async def _warm_default_pool(self) -> None:
        """Pre-start MCP server connections for the *default* group at boot time."""
        grp = self._config.get("default")
        if not grp or not isinstance(grp, dict):
            return
        for mcp in grp.get("mcps", []):
            if mcp.get("disabled"):
                continue
            entry = self._build_entry(mcp)
            try:
                await self._acquire_connection(entry)
            except Exception as e:
                logger.debug("Warm pool: skipped %s — %s", mcp.get("name", "?"), e)

    async def shutdown(self) -> None:
        """Close all pooled MCP server connections."""
        if self._reaper_task and not self._reaper_task.done():
            self._reaper_task.cancel()
            try:
                await self._reaper_task
            except asyncio.CancelledError:
                pass
        for conn in list(self._pool.values()):
            await self._close_connection(conn)
        self._pool.clear()

    def _load_groups_config(self) -> dict:
        if not _yaml or not _GROUPS_PATH.exists():
            return dict(_DEFAULT_GROUPS_CONFIG)
        with open(_GROUPS_PATH, "r", encoding="utf-8") as f:
            return _yaml.safe_load(f) or dict(_DEFAULT_GROUPS_CONFIG)

    # ── public API ────────────────────────────────────────────────

    async def prepare(self, task: str, workflow_groups: List[str] = None) -> List[str]:
        """
        Resolve groups (two-level + degradation) and write mcp.json.

        @param {str} task - task description for keyword detection
        @param {list} workflow_groups - static groups from YAML template
        @returns {list} final group list
        """
        groups = self._resolve(task, workflow_groups)
        self._save(groups)
        return groups

    async def health_check(self, group: str) -> bool:
        """Check whether all commands in a group are available on PATH."""
        grp = self._config.get(group)
        if not grp or not isinstance(grp, dict):
            return False
        for mcp in grp.get("mcps", []):
            cmd = mcp.get("command", "")
            if cmd and not shutil.which(cmd):
                self._unhealthy.add(group)
                return False
        self._unhealthy.discard(group)
        return True

    def get_all_groups(self) -> List[str]:
        return [k for k in self._config if k != "keyword_mappings"]

    # ── dynamic mode (runtime) ────────────────────────────────────

    def find_group(self, tool_name: str) -> Optional[str]:
        """
        Look up which group contains a tool by name.

        @param {str} tool_name
        @returns {str|None} group name
        """
        for group_name, group_cfg in self._config.items():
            if group_name == "keyword_mappings" or not isinstance(group_cfg, dict):
                continue
            for mcp in group_cfg.get("mcps", []):
                if mcp.get("name") == tool_name:
                    return group_name
        return None

    async def hot_reload(self, additional_groups: List[str]) -> None:
        """
        Append MCP groups to the live mcp.json (takes effect on next subprocess).

        @param {list} additional_groups
        """
        existing: Dict[str, Any] = {}
        if _MCP_JSON.exists():
            try:
                existing = json.loads(_MCP_JSON.read_text(encoding="utf-8"))
            except Exception:
                pass
        servers = existing.get("mcpServers", {})
        for g in additional_groups:
            grp = self._config.get(g)
            if not grp or not isinstance(grp, dict):
                continue
            for mcp in grp.get("mcps", []):
                servers[mcp["name"]] = self._build_entry(mcp)
        config = {"mcpServers": servers}
        _MCP_JSON.parent.mkdir(parents=True, exist_ok=True)
        _MCP_JSON.write_text(
            json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8",
        )

    # ── direct invoke (pooled stdio JSON-RPC) ───────────────────

    async def invoke(self, tool_name: str, arguments: dict) -> dict:
        """
        Directly call an MCP tool via stdio JSON-RPC.

        Reuses a pooled long-lived server process when available; falls back
        to a fresh process if the pooled one is dead.

        @param {str} tool_name
        @param {dict} arguments
        @returns {dict} tool result or {"error": ...}
        """
        mcp_entry = self._find_tool_entry(tool_name)
        if not mcp_entry:
            return {"error": f"tool '{tool_name}' not found in any group"}

        conn = await self._acquire_connection(mcp_entry)
        if not conn:
            return {"error": f"failed to start MCP server for '{tool_name}'"}

        async with conn.lock:
            try:
                await self._jsonrpc_send(conn.writer, "tools/call", {
                    "name": tool_name,
                    "arguments": arguments,
                })
                result = await self._jsonrpc_read(conn.reader)
                conn.last_used = time.monotonic()

                if "error" in result:
                    return {"error": result["error"]}
                content = result.get("result", {}).get("content", [])
                texts = [c.get("text", "") for c in content if c.get("type") == "text"]
                return {"result": "\n".join(texts) if texts else json.dumps(content)}

            except Exception as e:
                logger.warning("MCP invoke(%s) failed on pooled conn, evicting: %s", tool_name, e)
                await self._evict_connection(conn)
                return {"error": str(e)}

    # ── process pool management (L3) ──────────────────────────────

    async def _acquire_connection(self, entry: dict) -> Optional[_PooledConnection]:
        """Get or create a long-lived connection to an MCP server."""
        key = f"{entry['command']}|{'|'.join(entry.get('args', []))}"

        async with self._pool_lock:
            conn = self._pool.get(key)
            if conn and conn.proc.returncode is None:
                return conn

            if conn:
                del self._pool[key]

        conn = await self._create_connection(key, entry)
        if conn:
            async with self._pool_lock:
                self._pool[key] = conn
                self._ensure_reaper()
        return conn

    async def _create_connection(self, key: str, entry: dict) -> Optional[_PooledConnection]:
        """Start an MCP server process and perform the initialize handshake."""
        cmd = [entry["command"]] + entry.get("args", [])
        env = {**os.environ, **entry.get("env", {})}

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )

            await self._jsonrpc_send(proc.stdin, "initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "openclaw", "version": "1.0"},
            })
            await self._jsonrpc_read(proc.stdout)
            await self._jsonrpc_notify(proc.stdin, "notifications/initialized", {})

            return _PooledConnection(
                key=key, proc=proc,
                reader=proc.stdout, writer=proc.stdin,
                lock=asyncio.Lock(),
            )
        except Exception as e:
            logger.warning("Failed to create MCP connection for %s: %s", key, e)
            return None

    async def _evict_connection(self, conn: _PooledConnection) -> None:
        """Remove a broken connection from the pool and kill its process."""
        async with self._pool_lock:
            self._pool.pop(conn.key, None)
        await self._close_connection(conn)

    @staticmethod
    async def _close_connection(conn: _PooledConnection) -> None:
        """Gracefully shut down a pooled MCP server process."""
        try:
            if conn.writer and not conn.writer.is_closing():
                conn.writer.close()
            if conn.proc.returncode is None:
                try:
                    await asyncio.wait_for(conn.proc.wait(), timeout=3)
                except asyncio.TimeoutError:
                    conn.proc.kill()
                    await conn.proc.wait()
        except Exception:
            pass

    def _ensure_reaper(self) -> None:
        """Start the idle-connection reaper if not already running."""
        if self._reaper_task is None or self._reaper_task.done():
            self._reaper_task = asyncio.create_task(self._reap_idle())

    async def _reap_idle(self) -> None:
        """Periodically close connections that have been idle too long."""
        while True:
            await asyncio.sleep(_POOL_CHECK_INTERVAL)
            now = time.monotonic()
            to_close: List[_PooledConnection] = []

            async with self._pool_lock:
                for key, conn in list(self._pool.items()):
                    if now - conn.last_used > _POOL_IDLE_TIMEOUT:
                        to_close.append(conn)
                        del self._pool[key]
                    elif conn.proc.returncode is not None:
                        to_close.append(conn)
                        del self._pool[key]

            for conn in to_close:
                logger.debug("Reaping idle MCP connection: %s", conn.key)
                await self._close_connection(conn)

    async def list_tools(self) -> List[dict]:
        """
        Return all available MCP tools in function-calling format.

        Scans groups config; does NOT start processes (returns static metadata).

        @returns {list[dict]} each with name, description, parameters
        """
        if self._tool_catalog is not None:
            return self._tool_catalog

        tools: List[dict] = []
        for group_name, group_cfg in self._config.items():
            if group_name == "keyword_mappings" or not isinstance(group_cfg, dict):
                continue
            for mcp in group_cfg.get("mcps", []):
                for tool_def in mcp.get("tools", []):
                    tools.append({
                        "name": tool_def.get("name", mcp["name"]),
                        "description": tool_def.get("description", f"Tool from {mcp['name']}"),
                        "input_schema": tool_def.get("input_schema", {"type": "object"}),
                    })
        self._tool_catalog = tools
        return tools

    # ── JSON-RPC helpers ──────────────────────────────────────────

    @staticmethod
    async def _jsonrpc_send(writer: Any, method: str, params: dict) -> None:
        """Send a JSON-RPC request."""
        global _JSONRPC_ID
        _JSONRPC_ID += 1
        msg = json.dumps({
            "jsonrpc": "2.0", "id": _JSONRPC_ID,
            "method": method, "params": params,
        })
        writer.write((msg + "\n").encode())
        await writer.drain()

    @staticmethod
    async def _jsonrpc_notify(writer: Any, method: str, params: dict) -> None:
        """Send a JSON-RPC notification (no id, no response expected)."""
        msg = json.dumps({"jsonrpc": "2.0", "method": method, "params": params})
        writer.write((msg + "\n").encode())
        await writer.drain()

    @staticmethod
    async def _jsonrpc_read(reader: Any, timeout: float = 30) -> dict:
        """Read one JSON-RPC response line."""
        raw = await asyncio.wait_for(reader.readline(), timeout=timeout)
        if not raw:
            return {"error": "empty response"}
        return json.loads(raw.decode())

    def _find_tool_entry(self, tool_name: str) -> Optional[dict]:
        """Locate the MCP server config that provides *tool_name*."""
        for group_name, group_cfg in self._config.items():
            if group_name == "keyword_mappings" or not isinstance(group_cfg, dict):
                continue
            for mcp in group_cfg.get("mcps", []):
                if mcp.get("name") == tool_name:
                    return self._build_entry(mcp)
                for tool_def in mcp.get("tools", []):
                    if tool_def.get("name") == tool_name:
                        return self._build_entry(mcp)
        return None

    # ── internals ─────────────────────────────────────────────────

    def _resolve(self, task: str, workflow_groups: Optional[List[str]]) -> List[str]:
        """Two-level MCP decision + degradation filtering."""
        static = list(workflow_groups or [])
        dynamic = self._detect(task)
        merged = ["default"] + [g for g in (static + dynamic) if g != "default"]
        unique = list(dict.fromkeys(merged))
        if self._unhealthy:
            unique = [g for g in unique if g not in self._unhealthy or g == "default"]
        return unique

    def _detect(self, task: str) -> List[str]:
        task_lower = task.lower()
        kw_map = self._config.get("keyword_mappings", {})
        found: List[str] = []
        for group, keywords in kw_map.items():
            if any(kw.lower() in task_lower for kw in (keywords or [])):
                found.append(group)
        return found

    def _save(self, groups: List[str]) -> None:
        servers: Dict[str, dict] = {}
        for g in groups:
            grp = self._config.get(g)
            if not grp or not isinstance(grp, dict):
                continue
            for mcp in grp.get("mcps", []):
                servers[mcp["name"]] = self._build_entry(mcp)

        config = {"mcpServers": servers}
        blob = json.dumps(config, sort_keys=True, ensure_ascii=False)
        h = hashlib.md5(blob.encode()).hexdigest()
        if h == self._last_hash:
            return
        _MCP_JSON.parent.mkdir(parents=True, exist_ok=True)
        _MCP_JSON.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
        self._last_hash = h

    @staticmethod
    def _build_entry(mcp: dict) -> dict:
        env = {}
        for k, v in mcp.get("env", {}).items():
            if isinstance(v, str) and v.startswith("${") and v.endswith("}"):
                env[k] = os.environ.get(v[2:-1], "")
            else:
                env[k] = v
        return {
            "type": "stdio",
            "command": mcp["command"],
            "args": mcp.get("args", []),
            "env": env,
            "disabled": mcp.get("disabled", False),
        }

    @staticmethod
    def _load_registry_config() -> dict:
        """Load the unified MCP registry (mcp-registry.yaml)."""
        if not _yaml or not _REGISTRY_PATH.exists():
            return {}
        try:
            with open(_REGISTRY_PATH, "r", encoding="utf-8") as f:
                return _yaml.safe_load(f) or {}
        except Exception:
            return {}
