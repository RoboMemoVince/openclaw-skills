"""
Unified state store backed by SQLite.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

from modules.base import ModuleBase
from modules.core_types import (
    ErrorCategory,
    Phase,
    Priority,
    StepResult,
    TaskEnvelope,
    WorkflowResult,
)
from modules.paths import DB_PATH


def _json_default(value: Any) -> Any:
    """
    @description 将复杂对象转换为可 JSON 序列化的结构。
    @param {Any} value
    @returns {Any}
    """

    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, (Phase, Priority, ErrorCategory)):
        return value.value
    if is_dataclass(value):
        return {key: _json_default(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: _json_default(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_default(item) for item in value]
    return value


def _parse_datetime(value: Any) -> Any:
    """
    @description 解析 ISO 时间字符串，不可解析时原样返回。
    @param {Any} value
    @returns {Any}
    """

    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return value
    return value


def _step_result_from_dict(data: Dict[str, Any]) -> StepResult:
    """
    @description 从字典恢复 StepResult。
    @param {dict} data
    @returns {StepResult}
    """

    error_category = data.get("error_category")
    if isinstance(error_category, str) and error_category:
        try:
            data["error_category"] = ErrorCategory(error_category)
        except ValueError:
            data["error_category"] = None
    return StepResult(**data)


def _workflow_result_from_dict(data: Dict[str, Any]) -> WorkflowResult:
    """
    @description 从字典恢复 WorkflowResult。
    @param {dict} data
    @returns {WorkflowResult}
    """

    steps = data.get("steps", [])
    reviewed = data.get("reviewed", [])
    data["steps"] = [
        _step_result_from_dict(item) if isinstance(item, dict) else item
        for item in steps
    ]
    for item in reviewed:
        if isinstance(item, dict) and isinstance(item.get("result"), dict):
            item["result"] = _step_result_from_dict(item["result"])
    return WorkflowResult(**data)


class StateStore(ModuleBase):
    """
    @description 统一状态存储，负责任务状态、步骤幂等和 KV。
    """

    @property
    def name(self) -> str:
        return "state_store"

    @property
    def version(self) -> str:
        return "1.0"

    async def initialize(self, registry: "ModuleRegistry") -> None:
        self._db_path = DB_PATH
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS task_state (
                    task_id TEXT PRIMARY KEY,
                    phase TEXT NOT NULL,
                    workflow_name TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    envelope_json TEXT NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS step_checkpoints (
                    task_id TEXT NOT NULL,
                    checkpoint_key TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, checkpoint_key)
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS kv_store (
                    task_id TEXT NOT NULL,
                    kv_key TEXT NOT NULL,
                    value_json TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (task_id, kv_key)
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    name TEXT,
                    status TEXT,
                    content TEXT,
                    input_data TEXT,
                    output_data TEXT,
                    error TEXT,
                    progress INTEGER DEFAULT 0,
                    current_step TEXT,
                    created_at TEXT,
                    started_at TEXT,
                    completed_at TEXT,
                    metadata TEXT
                )
                """
            )
            conn.commit()
            conn.close()

    async def save(self, envelope: TaskEnvelope) -> None:
        """
        @description 保存完整任务状态。
        @param {TaskEnvelope} envelope
        @returns {None}
        """

        now = datetime.now().isoformat()
        if isinstance(envelope.created_at, datetime):
            created_at = envelope.created_at.isoformat()
        else:
            created_at = str(envelope.created_at)
        payload = json.dumps(_json_default(envelope), ensure_ascii=False)
        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO task_state (task_id, phase, workflow_name, created_at, updated_at, envelope_json)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(task_id) DO UPDATE SET
                    phase=excluded.phase,
                    workflow_name=excluded.workflow_name,
                    updated_at=excluded.updated_at,
                    envelope_json=excluded.envelope_json
                """,
                (
                    envelope.task_id,
                    envelope.phase.value,
                    envelope.workflow_name,
                    created_at,
                    now,
                    payload,
                ),
            )
            cursor.execute(
                """
                INSERT INTO tasks (task_id, name, status, content, input_data, output_data, error, created_at, started_at, completed_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(task_id) DO UPDATE SET
                    status=excluded.status,
                    content=excluded.content,
                    output_data=excluded.output_data,
                    error=excluded.error,
                    metadata=excluded.metadata,
                    completed_at=excluded.completed_at
                """,
                (
                    envelope.task_id,
                    (envelope.content or "")[:80] or envelope.task_id,
                    self._legacy_status(envelope.phase),
                    envelope.content,
                    json.dumps(_json_default(envelope.metadata), ensure_ascii=False),
                    json.dumps(_json_default(envelope.result), ensure_ascii=False),
                    getattr(envelope.result, "error", "") if envelope.result else "",
                    created_at,
                    now if envelope.phase != Phase.RECEIVED else "",
                    now if envelope.phase in {Phase.DELIVERED, Phase.FAILED, Phase.CANCELLED} else "",
                    json.dumps({"workflow_name": envelope.workflow_name}, ensure_ascii=False),
                ),
            )
            conn.commit()
            conn.close()

    async def load(self, task_id: str) -> TaskEnvelope | None:
        """
        @description 读取任务状态。
        @param {str} task_id
        @returns {TaskEnvelope | None}
        """

        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute("SELECT envelope_json FROM task_state WHERE task_id = ?", (task_id,))
            row = cursor.fetchone()
            conn.close()
        if row is None:
            return None
        data = json.loads(row["envelope_json"])
        return self._restore_envelope(data)

    async def update_phase(self, task_id: str, phase: Phase) -> None:
        """
        @description 仅更新任务阶段。
        @param {str} task_id
        @param {Phase} phase
        @returns {None}
        """

        envelope = await self.load(task_id)
        if envelope is None:
            return
        envelope.phase = phase
        await self.save(envelope)

    async def list_recent(self, status: str = None, limit: int = 10) -> List[TaskEnvelope]:
        """
        @description 列出最近任务。
        @param {str | None} status
        @param {int} limit
        @returns {list[TaskEnvelope]}
        """

        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            if status:
                cursor.execute(
                    """
                    SELECT envelope_json FROM task_state
                    WHERE phase = ?
                    ORDER BY updated_at DESC
                    LIMIT ?
                    """,
                    (status, limit),
                )
            else:
                cursor.execute(
                    """
                    SELECT envelope_json FROM task_state
                    ORDER BY updated_at DESC
                    LIMIT ?
                    """,
                    (limit,),
                )
            rows = cursor.fetchall()
            conn.close()
        return [self._restore_envelope(json.loads(row["envelope_json"])) for row in rows]

    async def list_non_terminal(self) -> List[TaskEnvelope]:
        """
        @description 列出所有非终态任务。
        @returns {list[TaskEnvelope]}
        """

        terminal = {Phase.DELIVERED.value, Phase.FAILED.value, Phase.CANCELLED.value}
        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT envelope_json FROM task_state
                WHERE phase NOT IN (?, ?, ?)
                ORDER BY updated_at ASC
                """,
                tuple(terminal),
            )
            rows = cursor.fetchall()
            conn.close()
        return [self._restore_envelope(json.loads(row["envelope_json"])) for row in rows]

    async def cancel(self, task_id: str) -> bool:
        """
        @description 将任务标记为取消。
        @param {str} task_id
        @returns {bool}
        """

        envelope = await self.load(task_id)
        if envelope is None:
            return False
        envelope.phase = Phase.CANCELLED
        await self.save(envelope)
        return True

    async def clear_step_checkpoints(self, task_id: str) -> None:
        """
        @description 清除指定任务的全部步骤幂等缓存（/redo 场景）。
        @param {str} task_id
        @returns {None}
        """

        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM step_checkpoints WHERE task_id = ?", (task_id,))
            conn.commit()
            conn.close()

    async def checkpoint_step(self, task_id: str, idempotency_key: str, result: StepResult) -> None:
        """
        @description 记录步骤幂等检查点。
        @param {str} task_id
        @param {str} idempotency_key
        @param {StepResult} result
        @returns {None}
        """

        if not idempotency_key:
            return
        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO step_checkpoints (task_id, checkpoint_key, result_json, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(task_id, checkpoint_key) DO UPDATE SET
                    result_json=excluded.result_json,
                    created_at=excluded.created_at
                """,
                (
                    task_id,
                    idempotency_key,
                    json.dumps(_json_default(result), ensure_ascii=False),
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
            conn.close()

    async def is_step_completed(self, task_id: str, idempotency_key: str) -> bool:
        """
        @description 判断步骤是否已有幂等结果。
        @param {str} task_id
        @param {str} idempotency_key
        @returns {bool}
        """

        return (await self.load_step_result(task_id, idempotency_key)) is not None

    async def load_step_result(self, task_id: str, idempotency_key: str) -> StepResult | None:
        """
        @description 读取步骤幂等结果。
        @param {str} task_id
        @param {str} idempotency_key
        @returns {StepResult | None}
        """

        if not idempotency_key:
            return None
        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT result_json FROM step_checkpoints
                WHERE task_id = ? AND checkpoint_key = ?
                """,
                (task_id, idempotency_key),
            )
            row = cursor.fetchone()
            conn.close()
        if row is None:
            return None
        return _step_result_from_dict(json.loads(row["result_json"]))

    async def set_kv(self, task_id: str, key: str, value: Any) -> None:
        """
        @description 写入任务级 KV。
        @param {str} task_id
        @param {str} key
        @param {Any} value
        @returns {None}
        """

        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO kv_store (task_id, kv_key, value_json, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(task_id, kv_key) DO UPDATE SET
                    value_json=excluded.value_json,
                    updated_at=excluded.updated_at
                """,
                (
                    task_id,
                    key,
                    json.dumps(_json_default(value), ensure_ascii=False),
                    datetime.now().isoformat(),
                ),
            )
            conn.commit()
            conn.close()

    async def get_kv(self, task_id: str, key: str) -> Any | None:
        """
        @description 读取任务级 KV。
        @param {str} task_id
        @param {str} key
        @returns {Any | None}
        """

        with self._lock:
            conn = self._connect()
            cursor = conn.cursor()
            cursor.execute(
                "SELECT value_json FROM kv_store WHERE task_id = ? AND kv_key = ?",
                (task_id, key),
            )
            row = cursor.fetchone()
            conn.close()
        if row is None:
            return None
        return json.loads(row["value_json"])

    @staticmethod
    def _legacy_status(phase: Phase) -> str:
        """
        @description 将新阶段映射为旧 tasks 表状态。
        @param {Phase} phase
        @returns {str}
        """

        if phase == Phase.DELIVERED:
            return "completed"
        if phase == Phase.FAILED:
            return "failed"
        if phase == Phase.CANCELLED:
            return "cancelled"
        return "running"

    @staticmethod
    def _restore_envelope(data: Dict[str, Any]) -> TaskEnvelope:
        """
        @description 从 JSON 数据恢复 TaskEnvelope。
        @param {dict} data
        @returns {TaskEnvelope}
        """

        restored = dict(data)
        restored["phase"] = Phase(restored.get("phase", Phase.RECEIVED.value))
        priority = restored.get("priority", Priority.P0_REALTIME.value)
        restored["priority"] = Priority(priority)
        restored["created_at"] = _parse_datetime(restored.get("created_at"))
        scheduled_at = restored.get("scheduled_at")
        restored["scheduled_at"] = _parse_datetime(scheduled_at) if scheduled_at else None
        result = restored.get("result")
        if isinstance(result, dict):
            restored["result"] = _workflow_result_from_dict(result)
        return TaskEnvelope(**restored)
