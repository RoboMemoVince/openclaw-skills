# OpenClaw 工作流代理实现规格

> 本文档是可落地的完整实现参考，包含所有数据结构、组件接口和实现代码。架构设计思路见 [WORKFLOW_DESIGN.md](WORKFLOW_DESIGN.md)。

---

## 目录

1. [核心数据结构](#1-核心数据结构)
2. [决策升级原语](#2-决策升级原语)
3. [主路径组件](#3-主路径组件)
   - 3.1 Gateway
   - 3.2 Controller（TaskController / CommandHandler / Classifier / HookRunner / IterationStrategy / Reconciler）
   - 3.3 Scheduler
   - 3.4 Worker
4. [旁路系统](#4-旁路系统)
5. [基础设施](#5-基础设施)
6. [工作流 DSL](#6-工作流-dsl)
7. [WorkflowRuntime 执行引擎](#7-workflowruntime-执行引擎)
8. [中间件链](#8-中间件链)
9. [错误处理策略](#9-错误处理策略)
10. [配置汇总](#10-配置汇总)
11. [目录结构](#11-目录结构)
12. [实施路径](#12-实施路径)

---

## 1. 核心数据结构

### 1.1 Phase / Priority 枚举

```python
from enum import Enum


class Phase(Enum):
    """
    @description 任务生命周期阶段
    """
    RECEIVED = "received"
    CLASSIFIED = "classified"
    PREPARING = "preparing"
    EXECUTING = "executing"
    DELIVERED = "delivered"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Priority(Enum):
    """
    @description 任务优先级，数值越小优先级越高
    """
    P0_REALTIME = 0     # 用户实时任务（飞书消息）
    P1_BACKGROUND = 1   # 后台业务任务（批量处理）
    P2_OPS = 2          # 运维任务（心跳、同步）
```

### 1.2 TaskEnvelope

```python
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class TaskEnvelope:
    """
    @description 贯穿全生命周期的标准化任务容器
    """
    task_id: str
    content: str
    user_id: str = ""
    channel: str = "cli"
    phase: Phase = Phase.RECEIVED
    priority: Priority = Priority.P0_REALTIME
    metadata: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    scheduled_at: datetime | None = None

    # CLASSIFIED 阶段填充（全部可序列化，支持崩溃恢复）
    parsed_command: str = ""
    parsed_args: str = ""
    workflow_name: str = ""

    # EXECUTING 阶段填充
    result: Any = None
    iteration: int = 0
    max_iterations: int = 3

    # 迭代控制
    reclassify: bool = False
    reclassified: bool = False
```

### 1.3 TaskStep

```python
@dataclass
class TaskStep:
    """
    @description DSL step() 原语产生的步骤声明
    """
    name: str
    prompt: str
    requirements: dict[str, str] = field(default_factory=dict)
    timeout: int = 300
    required: bool = True
    max_retries: int = 2
    on_fail: str = "auto"       # "auto" | "skip" | "abort" | "llm_fallback"
    idempotency_key: str = ""
```

### 1.4 StepResult + ErrorCategory

```python
class ErrorCategory(Enum):
    """
    @description 错误分类，决定自动处理策略
    """
    TRANSIENT = "transient"       # 超时、连接断、429 → 自动重试
    PERMANENT = "permanent"       # 认证失败、404 → 立即中止
    DEGRADABLE = "degradable"     # MCP 不可用但非关键 → 跳过


@dataclass
class StepResult:
    """
    @description Worker 执行单步后返回的结果
    """
    step_name: str
    output: str = ""
    success: bool = False
    passed: bool = False          # review 是否通过（reviewer 步骤用）
    feedback: str = ""            # review 反馈（reviewer 步骤用）
    duration: float = 0
    error: str = ""
    error_category: ErrorCategory | None = None
    degraded: bool = False
    skipped: bool = False
    cached: bool = False
    items: list | None = None     # parallel 结果分项（research 工作流用）
```

### 1.5 WorkflowResult

```python
@dataclass
class WorkflowResult:
    """
    @description 工作流整体执行结果
    """
    success: bool = False
    output: str = ""
    error: str = ""
    needs_iteration: bool = False
    reclassify: bool = False
    iteration_reason: str = ""
    steps: list[StepResult] = field(default_factory=list)
    degraded_steps: list[str] = field(default_factory=list)
```

### 1.6 WorkerAssignment

```python
@dataclass
class WorkerAssignment:
    """
    @description Scheduler 分配的 WorkerSlot-Step 绑定
    """
    slot: "WorkerSlot"
    step: TaskStep
    priority: Priority
    assigned_at: datetime = field(default_factory=datetime.now)
    timeout_at: datetime | None = None
```

### 1.7 ClassifyResult

```python
@dataclass
class ClassifyResult:
    """
    @description 分类结果，携带置信度、来源与决策理由
    """
    workflow_name: str
    confidence: float      # 0.0-1.0
    source: str            # "user_override" / "command" / "keyword" / "instant" / "llm" / "fallback"
    reason: str = ""
    alternatives: list[str] = field(default_factory=list)
```

### 1.8 EscalatableDecision

```python
@dataclass
class EscalatableDecision:
    """
    @description 系统层可升级决策——描述系统的自主选择及可选替代方案。
    由 HookRunner / IterationStrategy / Reconciler 产生，
    经 should_escalate() 判定后可升级为用户确认。
    """
    auto_choice: str
    confidence: float
    alternatives: list[str]
    reason: str
    escalation_prompt: str
```

---

## 2. 决策升级原语

### 2.1 should_escalate() 纯函数

```python
def should_escalate(mode: str, confidence: float, threshold: float) -> bool:
    """
    @description 三种 interaction_mode 的统一升级判定——纯函数，无副作用。
    auto 模式永不升级，confirm 模式始终升级，adaptive 模式按置信度判定。
    @param {str} mode - interaction_mode（auto / adaptive / confirm）
    @param {float} confidence - 对 auto_choice 的置信度（0.0-1.0）
    @param {float} threshold - adaptive 模式的升级阈值
    @returns {bool} 是否需要升级为用户决策
    """
    if mode == "auto":
        return False
    if mode == "confirm":
        return True
    return confidence < threshold
```

### 2.2 EscalationConfig

```python
@dataclass
class EscalationConfig:
    """
    @description 各决策点的升级行为配置
    """
    classification_threshold: float = 0.6
    classification_timeout_s: int = 30
    iteration_threshold: float = 0.5
    iteration_timeout_s: int = 30
    hook_failure_threshold: float = 0.5
    hook_failure_timeout_s: int = 15
```

---

## 3. 主路径组件

### 3.1 Gateway

```python
class Gateway:
    """
    @description 协议适配层 + 结果投递（含自管理重试）
    """
    def __init__(self, event_bus: "EventBus", max_retries: int = 3):
        self._event_bus = event_bus
        self._max_retries = max_retries

    async def receive(self, raw: dict, channel: str) -> TaskEnvelope:
        """
        @description 接收原始输入，标准化为 TaskEnvelope
        @param {dict} raw - 原始输入
        @param {str} channel - 来源渠道（feishu / api / cli）
        @returns {TaskEnvelope}
        @throws {RejectedError} 准入校验失败
        """
        envelope = self._adapt(raw, channel)
        self._validate(envelope)
        return envelope

    async def deliver(self, envelope: TaskEnvelope, result: dict) -> bool:
        """
        @description 按原渠道回传结果，自带指数退避重试
        @returns {bool} 投递是否成功
        """
        for attempt in range(self._max_retries + 1):
            try:
                await self._dispatch(envelope.channel, envelope, result)
                return True
            except Exception as e:
                if attempt < self._max_retries:
                    await asyncio.sleep(2 ** attempt)

        await self._event_bus.emit("delivery_exhausted", {
            "task_id": envelope.task_id,
            "channel": envelope.channel,
            "error": str(e),
            "attempts": self._max_retries + 1,
        })
        return False
```

---

### 3.2 Controller

Controller 内部拆分为 6 个职责单一的子组件。

#### 3.2.1 TaskController

```python
class TaskController:
    """
    @description Controller 入口，分派给子组件处理。
    命令分为三类：即时命令（直接返回）、路由命令（预处理后进入工作流）、
    普通输入（直接进入 Reconciler 状态机）。
    """
    ROUTING_COMMANDS = {"/redo"}

    def __init__(
        self,
        command_handler: "CommandHandler",
        reconciler: "Reconciler",
        state_store: "StateStore",
    ):
        self._command_handler = command_handler
        self._reconciler = reconciler
        self._store = state_store

    async def reconcile(self, envelope: TaskEnvelope) -> dict:
        """
        @description 驱动任务完成整个生命周期
        @param {TaskEnvelope} envelope
        @returns {dict} 最终结果
        """
        self._parse_command(envelope)

        if envelope.parsed_command in CommandHandler.COMMANDS:
            return await self._command_handler.handle(envelope)

        if envelope.parsed_command in self.ROUTING_COMMANDS:
            await self._apply_routing_command(envelope)

        return await self._reconciler.run(envelope)

    def _parse_command(self, envelope: TaskEnvelope):
        content = envelope.content.strip()
        if content.startswith("/"):
            parts = content.split(maxsplit=1)
            envelope.parsed_command = parts[0]
            envelope.parsed_args = parts[1] if len(parts) > 1 else ""

    async def _apply_routing_command(self, envelope: TaskEnvelope):
        """
        @description 路由命令预处理——加载已有任务状态并重置阶段
        """
        if envelope.parsed_command == "/redo":
            parts = envelope.parsed_args.split(maxsplit=1)
            target_id = parts[0] if parts else ""
            feedback = parts[1] if len(parts) > 1 else ""
            saved = await self._store.load(target_id)
            if saved:
                envelope.task_id = saved.task_id
                envelope.content = saved.content
                envelope.workflow_name = saved.workflow_name
                envelope.metadata["user_feedback"] = feedback
                envelope.phase = Phase.PREPARING
                envelope.iteration = 0
```

#### 3.2.2 CommandHandler

```python
class CommandHandler:
    """
    @description 斜杠指令处理器——仅处理即时命令（不触发工作流执行）
    """
    COMMANDS = {"/help", "/status", "/task", "/tasks", "/cancel"}

    def __init__(
        self,
        state_store: "StateStore",
        event_bus: "EventBus",
        active_tasks: "ActiveTaskRegistry",
    ):
        self._store = state_store
        self._bus = event_bus
        self._active_tasks = active_tasks

    async def handle(self, envelope: TaskEnvelope) -> dict:
        """
        @description 分派到对应指令方法
        """
        match envelope.parsed_command:
            case "/help":
                return self._help()
            case "/status":
                return await self._status()
            case "/task":
                return await self._task_detail(envelope.parsed_args)
            case "/tasks":
                return await self._task_list(envelope.parsed_args)
            case "/cancel":
                return await self._cancel(envelope.parsed_args)

    async def _cancel(self, target_id: str) -> dict:
        await self._active_tasks.cancel(target_id)
        await self._store.update_phase(target_id, Phase.CANCELLED)
        await self._bus.emit("task_cancelled", {"task_id": target_id})
        return {"success": True, "output": f"任务 {target_id[:8]} 已取消"}
```

**即时命令**（不进入工作流生命周期）：

| 指令 | 功能 | 实现要点 |
|------|------|---------|
| `/help` | 帮助信息 | 直接返回文本 |
| `/status` | 系统状态 | 读取 WorkerPool 健康 + Observer 指标 |
| `/task <id>` | 查询单任务 | 从 State Store 读取 |
| `/tasks [status]` | 列出最近任务 | State Store.list_recent() |
| `/cancel <id>` | 取消任务 | 标记 CANCELLED + 传播 CancellationToken |

**路由命令**（预处理后进入工作流完整生命周期）：

| 指令 | 功能 | 实现要点 |
|------|------|---------|
| `/run <workflow> <task>` | 强制指定工作流执行 | 由 Classifier 策略链 UserOverrideStrategy（L0）处理 |
| `/redo <id> [feedback]` | 用户反馈重做 | 加载目标任务，注入 user_feedback，重置为 PREPARING |

#### 3.2.3 Classifier + 策略链

**分类配置**

```yaml
# config/classifier.yaml
rules:
  - name: coding
    keywords: ["代码", "编程", "写代码", "bug", "函数", "重构"]
    priority: 10
  - name: research
    keywords: ["搜索", "调研", "查找", "论文"]
    priority: 10
  - name: translation
    keywords: ["翻译", "translate"]
    priority: 10
  - name: database
    keywords: ["数据库", "SQL", "查询"]
    priority: 10

instant_threshold:
  max_length: 20
  exclude_keywords: ["帮我", "请", "写", "做", "分析"]

fallback: "general"

confirmation_mode: adaptive
confirm_threshold: 0.6

iteration:
  reclassify_threshold: 0.5

escalation:
  classification:
    adaptive_threshold: 0.6
    timeout_s: 30
  iteration:
    adaptive_threshold: 0.5
    timeout_s: 30
  hook_failure:
    adaptive_threshold: 0.5
    timeout_s: 15
```

**策略链接口**

```python
class ClassifyStrategy:
    """
    @description 分类策略接口，返回 ClassifyResult 携带置信度与来源
    """
    async def try_classify(self, envelope: TaskEnvelope) -> ClassifyResult | None: ...


class UserOverrideStrategy(ClassifyStrategy):
    """
    @description L0: 用户通过 /run 显式指定工作流（最高优先级），confidence=1.0
    """
    def __init__(self, registry: "WorkflowRegistry"):
        self._registry = registry

    async def try_classify(self, envelope):
        if envelope.parsed_command == "/run":
            parts = envelope.parsed_args.split(maxsplit=1)
            wf_name = parts[0] if parts else "general"
            if self._registry.get(wf_name) is None:
                wf_name = "general"
            envelope.content = parts[1] if len(parts) > 1 else ""
            return ClassifyResult(
                wf_name, confidence=1.0, source="user_override",
                reason=f"用户通过 /run 显式指定工作流 '{wf_name}'",
            )
        return None


class CommandStrategy(ClassifyStrategy):
    """
    @description L1: 斜杠命令直接映射，confidence=1.0
    """
    async def try_classify(self, envelope):
        if envelope.parsed_command == "/miniagent":
            return ClassifyResult(
                "general", confidence=1.0, source="command",
                reason=f"命令 {envelope.parsed_command} 映射到 general 工作流",
            )
        return None


class KeywordStrategy(ClassifyStrategy):
    """
    @description L2: 关键词快速匹配（0 token），规则从配置加载，confidence=0.7
    """
    def __init__(self, rules: list[dict]):
        self._rules = rules

    async def try_classify(self, envelope):
        content = envelope.content.lower()
        for rule in self._rules:
            matched = [kw for kw in rule["keywords"] if kw in content]
            if matched:
                return ClassifyResult(
                    rule["name"], confidence=0.7, source="keyword",
                    reason=f"匹配关键词: {', '.join(matched)}",
                )
        return None


class InstantStrategy(ClassifyStrategy):
    """
    @description L3: 短文本直答判定，confidence=0.5（启发式）
    """
    def __init__(self, config: dict):
        self._max_length = config["max_length"]
        self._exclude = config["exclude_keywords"]

    async def try_classify(self, envelope):
        content = envelope.content.lower()
        if len(content) < self._max_length and not any(kw in content for kw in self._exclude):
            return ClassifyResult(
                "instant", confidence=0.5, source="instant",
                reason=f"短文本直答（长度 {len(content)} < {self._max_length}）",
            )
        return None


class LLMStrategy(ClassifyStrategy):
    """
    @description L4: LLM 分类（~100 token），confidence 由模型输出（0.0-1.0）
    """
    def __init__(self, llm_service: "LLMService"):
        self._llm = llm_service

    async def try_classify(self, envelope):
        if self._llm:
            raw = await self._llm.classify(envelope.content)
            name = raw.get("workflow", "general") if isinstance(raw, dict) else raw
            conf = raw.get("confidence", 0.5) if isinstance(raw, dict) else 0.5
            reason = raw.get("reason", "LLM 语义分析") if isinstance(raw, dict) else "LLM 语义分析"
            return ClassifyResult(name, confidence=conf, source="llm", reason=reason)
        return None


class FallbackStrategy(ClassifyStrategy):
    """
    @description L5: 兜底策略，confidence=0.1
    """
    def __init__(self, fallback: str = "general"):
        self._fallback = fallback

    async def try_classify(self, envelope):
        return ClassifyResult(
            self._fallback, confidence=0.1, source="fallback",
            reason="无匹配策略，使用兜底工作流",
        )
```

**各策略置信度约定**：

| 策略 | confidence | 理由 |
|------|-----------|------|
| UserOverrideStrategy (L0) | **1.0** | 用户明确指定，无歧义 |
| CommandStrategy (L1) | **1.0** | 命令映射，无歧义 |
| KeywordStrategy (L2) | **0.7** | 规则匹配，准确度有限 |
| InstantStrategy (L3) | **0.5** | 启发式判定 |
| LLMStrategy (L4) | **由模型输出** | 0.0-1.0，唯一动态置信度 |
| FallbackStrategy (L5) | **0.1** | 兜底猜测 |

**Classifier 主体**

```python
class Classifier:
    """
    @description 任务分类器，采用策略链模式，规则从配置加载。
    添加新工作流只需加配置 + 写工作流文件，无需修改 Classifier 源码。
    """
    def __init__(
        self,
        llm_service: "LLMService",
        rules_config: dict,
        workflow_registry: "WorkflowRegistry",
    ):
        self._strategies: list[ClassifyStrategy] = [
            UserOverrideStrategy(workflow_registry),
            CommandStrategy(),
            KeywordStrategy(rules_config["rules"]),
            InstantStrategy(rules_config["instant_threshold"]),
            LLMStrategy(llm_service),
            FallbackStrategy(rules_config.get("fallback", "general")),
        ]

    async def classify(self, envelope: TaskEnvelope) -> ClassifyResult:
        """
        @description 按策略链顺序尝试分类，首个非 None 结果即为最终结果
        @returns {ClassifyResult} 含工作流名称、置信度、来源
        """
        for strategy in self._strategies:
            result = await strategy.try_classify(envelope)
            if result is not None:
                return result
        return ClassifyResult("general", confidence=0.1, source="fallback")
```

#### 3.2.4 HookRunner

```python
class HookRunner:
    """
    @description PREPARING 阶段的钩子编排——执行预执行钩子链，
    区分必需/可选钩子的失败处理，支持决策升级。
    """
    def __init__(
        self,
        hooks: list["PreExecuteHook"],
        interactor: "UserInteractor | None",
        escalation_config: EscalationConfig,
    ):
        self._hooks = hooks
        self._interactor = interactor
        self._config = escalation_config

    async def run(self, envelope: TaskEnvelope, interaction_mode: str) -> None:
        """
        @description 按顺序执行钩子链，区分必需/可选钩子的失败策略
        @throws {HookAborted} 必需钩子最终失败（abort）
        @throws {HookReclassify} 必需钩子失败且决定 reclassify
        """
        for hook in self._hooks:
            try:
                await hook.run(envelope)
            except Exception as e:
                if not hook.required:
                    envelope.metadata.setdefault("degraded_hooks", []).append(
                        type(hook).__name__,
                    )
                    continue

                action = await self._decide_on_failure(
                    hook, envelope, e, interaction_mode,
                )
                match action:
                    case "reclassify":
                        raise HookReclassify(type(hook).__name__)
                    case "abort":
                        raise HookAborted(type(hook).__name__, str(e))
                    case "retry":
                        continue

    async def _decide_on_failure(
        self,
        hook: "PreExecuteHook",
        envelope: TaskEnvelope,
        error: Exception,
        mode: str,
    ) -> str:
        """
        @description 必需钩子失败时的决策——产生 EscalatableDecision，
        根据 interaction_mode 决定是否升级为用户决策
        @returns {str} 决策结果："abort" / "reclassify" / "retry"
        """
        decision = EscalatableDecision(
            auto_choice=hook.on_fail,
            confidence=0.3 if hook.required else 1.0,
            alternatives=["abort", "reclassify", "retry"],
            reason=f"钩子 {type(hook).__name__} 失败: {error}",
            escalation_prompt=f"预执行钩子 {type(hook).__name__} 失败，请选择处理方式",
        )

        if (
            self._interactor is not None
            and should_escalate(mode, decision.confidence, self._config.hook_failure_threshold)
        ):
            chosen = await self._interactor.request_decision(
                envelope, decision, self._config.hook_failure_timeout_s,
            )
            return chosen

        return decision.auto_choice
```

#### 3.2.5 IterationStrategy + IterationConfig

```python
@dataclass
class IterationConfig:
    """
    @description 迭代策略的自主行为配置（与升级行为阈值分离）
    """
    reclassify_threshold: float = 0.5


class IterationStrategy:
    """
    @description EXECUTING 后的迭代方向决策——根据执行结果和置信度
    决定下一阶段（PREPARING / CLASSIFIED / 终态），支持决策升级。
    """
    def __init__(
        self,
        iteration_config: IterationConfig,
        escalation_config: EscalationConfig,
        interactor: "UserInteractor | None",
    ):
        self._iter_config = iteration_config
        self._esc_config = escalation_config
        self._interactor = interactor

    async def decide(
        self,
        result: WorkflowResult,
        envelope: TaskEnvelope,
        interaction_mode: str,
    ) -> Phase:
        """
        @description 根据执行结果决定下一阶段，可独立单元测试
        @param {WorkflowResult} result - 工作流执行结果
        @param {TaskEnvelope} envelope - 当前任务
        @param {str} interaction_mode - 用户参与策略
        @returns {Phase} 下一阶段
        """
        if not result.needs_iteration or envelope.iteration >= envelope.max_iterations:
            return Phase.DELIVERED if result.success else Phase.FAILED

        envelope.iteration += 1
        auto_phase = self._compute_auto(result, envelope)
        confidence = self._compute_confidence(result, envelope)

        decision = EscalatableDecision(
            auto_choice=auto_phase.value,
            confidence=confidence,
            alternatives=["preparing", "classified", "failed"],
            reason=result.iteration_reason or "需要迭代",
            escalation_prompt=f"工作流需要迭代（{result.iteration_reason}），请选择下一步",
        )

        if (
            self._interactor is not None
            and should_escalate(interaction_mode, confidence, self._esc_config.iteration_threshold)
        ):
            chosen = await self._interactor.request_decision(
                envelope, decision, self._esc_config.iteration_timeout_s,
            )
            return Phase(chosen)

        return auto_phase

    def _compute_auto(self, result: WorkflowResult, envelope: TaskEnvelope) -> Phase:
        """
        @description 计算系统自主选择的迭代方向
        """
        should_reclassify = result.reclassify or (
            not result.success
            and not envelope.reclassified
            and envelope.metadata.get("classify_confidence", 1.0)
                < self._iter_config.reclassify_threshold
        )
        if should_reclassify:
            envelope.reclassified = True
            return Phase.CLASSIFIED
        return Phase.PREPARING

    def _compute_confidence(self, result: WorkflowResult, envelope: TaskEnvelope) -> float:
        """
        @description 计算对 auto_choice 的置信度（用于决策升级判定）
        """
        if (
            not result.success
            and envelope.metadata.get("classify_confidence", 1.0)
                < self._esc_config.iteration_threshold
        ):
            return envelope.metadata["classify_confidence"]
        return 1.0
```

#### 3.2.6 Reconciler

```python
class Reconciler:
    """
    @description 纯状态机循环驱动器——驱动任务到达终态。
    分类由 Classifier 负责，钩子编排由 HookRunner 负责，
    迭代决策由 IterationStrategy 负责，本类只做阶段转换和状态持久化。
    """
    def __init__(
        self,
        classifier: "Classifier",
        workflow_registry: "WorkflowRegistry",
        workflow_runtime: "WorkflowRuntime",
        state_store: "StateStore",
        event_bus: "EventBus",
        user_interactor: "UserInteractor | None",
        active_tasks: "ActiveTaskRegistry",
        hook_runner: "HookRunner",
        iteration_strategy: "IterationStrategy",
        confirmation_mode: str = "auto",
        escalation_config: "EscalationConfig | None" = None,
    ):
        self._classifier = classifier
        self._registry = workflow_registry
        self._runtime = workflow_runtime
        self._store = state_store
        self._bus = event_bus
        self._interactor = user_interactor
        self._active_tasks = active_tasks
        self._hook_runner = hook_runner
        self._iteration_strategy = iteration_strategy
        self._confirmation_mode = confirmation_mode
        self._esc_config = escalation_config or EscalationConfig()

    async def run(self, envelope: TaskEnvelope) -> dict:
        """
        @description 协调循环主体——每次推进一个阶段，直到终态
        """
        saved = await self._store.load(envelope.task_id)
        if saved:
            envelope.phase = saved.phase
            envelope.workflow_name = saved.workflow_name

        terminal = (Phase.DELIVERED, Phase.FAILED, Phase.CANCELLED)
        while envelope.phase not in terminal:
            await self._bus.emit("phase_changed", {
                "task_id": envelope.task_id,
                "phase": envelope.phase.value,
            })

            match envelope.phase:

                case Phase.RECEIVED:
                    classify_result = await self._classifier.classify(envelope)
                    wf_name = classify_result.workflow_name
                    if self._registry.get(wf_name) is None:
                        wf_name = "general"
                    envelope.workflow_name = wf_name
                    envelope.metadata["classify_confidence"] = classify_result.confidence
                    envelope.metadata["classify_source"] = classify_result.source
                    envelope.metadata["classify_reason"] = classify_result.reason
                    envelope.phase = Phase.CLASSIFIED
                    await self._store.save(envelope)

                case Phase.CLASSIFIED:
                    wf_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (wf_entry.interaction_mode if wf_entry else None) or self._confirmation_mode
                    confidence = envelope.metadata.get("classify_confidence", 1.0)

                    if should_escalate(mode, confidence, self._esc_config.classification_threshold):
                        decision = EscalatableDecision(
                            auto_choice=envelope.workflow_name,
                            confidence=confidence,
                            alternatives=self._registry.list_all(),
                            reason=envelope.metadata.get("classify_reason", ""),
                            escalation_prompt=f"将使用 {envelope.workflow_name} 工作流，确认或选择其他",
                        )
                        if self._interactor is not None:
                            chosen = await self._interactor.request_decision(
                                envelope, decision, self._esc_config.classification_timeout_s,
                            )
                            if chosen != envelope.workflow_name:
                                envelope.workflow_name = chosen

                    envelope.phase = Phase.PREPARING
                    await self._store.save(envelope)

                case Phase.PREPARING:
                    wf_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (wf_entry.interaction_mode if wf_entry else None) or self._confirmation_mode
                    try:
                        await self._hook_runner.run(envelope, mode)
                    except HookAborted as e:
                        envelope.phase = Phase.FAILED
                        envelope.result = WorkflowResult(
                            success=False, error=f"prepare_failed:{e.hook_name}",
                        )
                        await self._store.save(envelope)
                        continue
                    except HookReclassify:
                        envelope.phase = Phase.CLASSIFIED
                        await self._store.save(envelope)
                        continue
                    envelope.phase = Phase.EXECUTING
                    await self._store.save(envelope)

                case Phase.EXECUTING:
                    wf_entry = self._registry.get_entry(envelope.workflow_name)
                    mode = (wf_entry.interaction_mode if wf_entry else None) or self._confirmation_mode
                    ctx = TaskContext(envelope, self._store)
                    await self._active_tasks.register(envelope.task_id, ctx)
                    try:
                        result = await self._runtime.run(
                            wf_entry.fn, ctx,
                            timeout=wf_entry.timeout,
                            middlewares=wf_entry.middlewares,
                        )
                    finally:
                        await self._active_tasks.unregister(envelope.task_id)

                    envelope.result = result
                    envelope.phase = await self._iteration_strategy.decide(
                        result, envelope, mode,
                    )
                    await self._store.save(envelope)

        return self._build_result(envelope)

    async def recover(self):
        """
        @description 系统启动时恢复未完成任务。
        扫描 StateStore 中所有非终态任务，按 TTL 判定恢复或过期清理。
        """
        stale = await self._store.list_non_terminal()
        for envelope in stale:
            age = (datetime.now() - envelope.created_at).total_seconds()
            wf_entry = self._registry.get_entry(envelope.workflow_name)
            ttl = (wf_entry.timeout if wf_entry else 300) * 2
            if age > ttl:
                envelope.phase = Phase.FAILED
                envelope.result = WorkflowResult(
                    success=False, error="task_expired",
                )
                await self._store.save(envelope)
                await self._bus.emit("task_expired", {
                    "task_id": envelope.task_id,
                    "age": age,
                    "ttl": ttl,
                })
            else:
                asyncio.create_task(self.run(envelope))
```

#### 3.2.7 PreExecuteHook + 内置钩子

```python
class PreExecuteHook:
    """
    @description 预执行钩子接口，支持必需/可选区分和失败策略
    """
    required: bool = True
    on_fail: str = "abort"  # "abort" | "reclassify" | "skip"
    max_retries: int = 2

    async def run(self, envelope: TaskEnvelope) -> None: ...


class HookAborted(Exception):
    def __init__(self, hook_name: str, message: str = ""):
        self.hook_name = hook_name
        super().__init__(f"Hook aborted: {hook_name}: {message}")


class HookReclassify(Exception):
    def __init__(self, hook_name: str):
        self.hook_name = hook_name
        super().__init__(f"Hook reclassify: {hook_name}")


class ResourcePreflight(PreExecuteHook):
    """
    @description 预检 Worker 可用性和 MCP 工具健康
    """
    required = True
    on_fail = "reclassify"

    async def run(self, envelope):
        ...


class KnowledgeLoader(PreExecuteHook):
    """
    @description 按工作流类型预加载相关知识到上下文
    """
    required = False

    async def run(self, envelope):
        ...
```

#### 3.2.8 UserInteractor 接口

```python
class UserInteractor:
    """
    @description Reconciler / HookRunner / IterationStrategy 与用户交互的抽象接口。
    消除对 Gateway 的逆向依赖——Gateway 适配实现此接口，通过依赖注入提供。
    两个方法分别服务系统层决策和工作流层交互。
    """
    async def request_decision(
        self,
        envelope: TaskEnvelope,
        decision: EscalatableDecision,
        timeout_s: int,
    ) -> str:
        """
        @description 系统层决策升级——展示自主选择和替代选项，用户可确认或覆盖。
        超时返回 decision.auto_choice，保证闭环不卡死。
        @param {TaskEnvelope} envelope - 当前任务
        @param {EscalatableDecision} decision - 可升级决策
        @param {int} timeout_s - 超时秒数
        @returns {str} 用户选择或超时后的 auto_choice
        """
        ...

    async def request_input(
        self,
        envelope: TaskEnvelope,
        prompt: str,
        timeout_s: int,
    ) -> str | None:
        """
        @description 工作流层交互——执行中向用户请求输入（为 ask() 原语服务）
        @returns {str | None} 用户输入，None 表示超时
        """
        ...
```

#### 3.2.9 TaskContext + ActiveTaskRegistry

```python
class TaskContext:
    """
    @description 单个任务的运行上下文，支持取消传播
    """
    def __init__(self, envelope: TaskEnvelope, store: "StateStore"):
        self.envelope = envelope
        self.task = envelope.content
        self.store = store
        self._cancelled = asyncio.Event()

    def cancel(self):
        self._cancelled.set()

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled.is_set()


class ActiveTaskRegistry:
    """
    @description 线程安全的活跃任务注册表，解耦 Reconciler 和 CommandHandler 的共享状态
    """
    def __init__(self):
        self._contexts: dict[str, TaskContext] = {}
        self._lock = asyncio.Lock()

    async def register(self, task_id: str, ctx: TaskContext) -> None:
        async with self._lock:
            self._contexts[task_id] = ctx

    async def unregister(self, task_id: str) -> None:
        async with self._lock:
            self._contexts.pop(task_id, None)

    async def cancel(self, task_id: str) -> bool:
        """
        @description 取消指定任务，返回是否找到活跃上下文
        """
        async with self._lock:
            ctx = self._contexts.get(task_id)
        if ctx:
            ctx.cancel()
            return True
        return False
```

---

### 3.3 Scheduler

```python
class Scheduler:
    """
    @description 优先级队列 + 标签匹配调度器
    """
    def __init__(
        self,
        worker_pool: "WorkerPool",
        breaker_reader: "BreakerStateReader",
        queue_capacity: int = 20,
    ):
        self._pool = worker_pool
        self._breaker = breaker_reader
        self._queue_capacity = queue_capacity

    async def schedule(
        self, step: TaskStep, priority: Priority
    ) -> WorkerAssignment:
        """
        @description 为单个步骤匹配最优 WorkerSlot
        @throws {ServiceUnavailable} 断路器打开
        @throws {NoWorkerAvailable} 无匹配 Worker
        @throws {QueueFull} 队列已满（背压）
        """
        if self._breaker.is_open("agent_runner"):
            raise ServiceUnavailable("agent_runner circuit open")

        candidates = self._pool.filter_available(step.requirements)
        if not candidates:
            raise NoWorkerAvailable(step.requirements)

        scored = self._score(candidates)
        slot = scored[0]
        await slot.acquire(timeout=step.timeout)

        return WorkerAssignment(
            slot=slot, step=step, priority=priority,
            timeout_at=datetime.now() + timedelta(seconds=step.timeout),
        )

    async def schedule_batch(
        self, steps: list[TaskStep], priority: Priority
    ) -> list[WorkerAssignment]:
        """
        @description 批量调度，用于 parallel() 原语
        """
        return await asyncio.gather(*[
            self.schedule(s, priority) for s in steps
        ])

    def _score(self, candidates: list["WorkerSlot"]) -> list["WorkerSlot"]:
        """
        @description 评分排序：空闲度 > 历史成功率
        """
        return sorted(candidates, key=lambda s: (
            s.active_count,
            -s.worker.success_rate,
        ))
```

**断路器读写分离（三态模型）**

```
CLOSED ──(failure_count >= threshold)──→ OPEN
OPEN ──(recovery_timeout 到期)──→ HALF_OPEN
HALF_OPEN ──(探测成功)──→ CLOSED
HALF_OPEN ──(探测失败)──→ OPEN
```

```python
class BreakerState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

class BreakerStateReader:
    """
    @description Scheduler 使用的只读接口
    """
    def is_open(self, service: str) -> bool: ...
    def state(self, service: str) -> BreakerState: ...
```

---

### 3.4 Worker

#### 3.4.1 AgentBackend 接口

```python
class AgentBackend:
    """
    @description Agent 执行后端接口
    @returns {dict} keys: returncode, stdout, stderr, pid
    """
    name: str
    async def run(self, task: str, workspace: str, timeout: int) -> dict: ...
```

内置实现：

| 后端 | name | 用途 |
|------|------|------|
| MiniAgentBackend | `mini-agent` | 调用 mini-agent 子进程（默认） |
| ClaudeCodeBackend | `claude-code` | 调用 Claude Code 远程执行 |
| LLMDirectBackend | `llm-direct` | LLM 直接应答，无子进程（instant 工作流） |

#### 3.4.2 Worker

```python
class Worker:
    """
    @description 纯执行单元——通过 AgentBackend 执行步骤，
    自动分类错误，维护 success_rate
    """
    def __init__(self, id: str, workspace: str, backend: AgentBackend, labels: dict[str, str]):
        self.id = id
        self.workspace = workspace
        self.backend = backend
        self.labels = labels

    async def execute(self, step: TaskStep) -> StepResult:
        """
        @description 调用 backend.run()，成功判定：returncode == 0，
        失败自动 _classify_error()
        """
        ...

    async def heartbeat(self) -> dict: ...
```

#### 3.4.3 WorkerSlot + WorkerStatus

```python
class WorkerStatus(Enum):
    IDLE = "idle"
    BUSY = "busy"
    DRAINING = "draining"
    OFFLINE = "offline"

class WorkerSlot:
    """
    @description 资源槽位——信号量控制容量，状态机管理 IDLE/BUSY/DRAINING/OFFLINE
    """
    def __init__(self, worker: Worker, capacity: int = 2): ...
    def has_capacity(self) -> bool: ...
    async def acquire(self, timeout: float) -> None: ...
    async def release(self) -> None: ...
    async def execute_and_release(self, step: TaskStep) -> StepResult: ...
```

#### 3.4.4 WorkerPool

```python
class WorkerPool:
    """
    @description WorkerSlot 注册与查询 + 自治式健康检查（_health_check_loop）
    """
    async def register(self, worker: Worker, capacity: int = 2): ...
    async def deregister(self, worker_id: str): ...

    def filter_available(self, requirements: dict[str, str]) -> list[WorkerSlot]:
        """
        @description 标签匹配：status not OFFLINE/DRAINING + has_capacity + labels 超集
        """
        ...

    def mark_offline(self, worker_id: str): ...
    def record_heartbeat(self, worker_id: str): ...
```

**Worker 故障处理**：

1. **心跳超时**：WorkerPool 自治检测（`_health_check_loop`），超时 30s → `mark_offline()` + emit `worker_offline`
2. **在途任务超时**：`WorkerAssignment.timeout_at` 到期 → 按 TRANSIENT 重试 → Scheduler 重新分配
3. **进程崩溃**：`AgentBackend.run()` 返回非 0 退出码 → 错误分类 → 按 `on_fail` 策略处理

#### 3.4.5 workers.yaml

```yaml
# config/workers.yaml
workers:
  - id: alpha
    workspace: ~/.openclaw/workspace/
    backend: mini-agent
    labels:
      mcp.file: "true"
      mcp.bash: "true"
      mcp.search: "true"
      mcp.memory: "true"
    capacity: 2

  - id: beta
    workspace: ~/.openclaw/workspace-worker/
    backend: mini-agent
    labels:
      mcp.file: "true"
      mcp.database: "true"
      mcp.bash: "true"
    capacity: 2

  - id: gamma
    workspace: ~/.openclaw/workspace-reviewer/
    backend: mini-agent
    labels:
      review: "true"
      mcp.memory: "true"
    capacity: 1

  - id: instant
    workspace: ""
    backend: llm-direct
    labels:
      instant: "true"
    capacity: 5
```

---

## 4. 旁路系统

### 4.1 Observer

```python
class Observer:
    """
    @description 旁路观察系统——只观察，不编排。
    订阅 EventBus 事件，写入健康状态、持久化失败任务、记录指标。
    """
    def __init__(self, event_bus: "EventBus"):
        self.breakers = CircuitBreakerRegistry()
        self.dlq = DeadLetterQueue()
        self.tracer = TaskTrace()
        self.metrics = MetricsCollector()

        for event, handler in [
            ("step_completed", self._on_step_completed),
            ("step_failed", self._on_step_failed),
            ("step_cancelled", self._on_step_cancelled),
            ("phase_changed", self._on_phase_changed),
            ("worker_heartbeat", self._on_heartbeat),
            ("delivery_exhausted", self._on_delivery_exhausted),
            ("task_cancelled", self._on_cancelled),
            ("task_expired", self._on_task_expired),
        ]:
            event_bus.subscribe(event, handler)

    async def _on_step_completed(self, data):
        self.breakers.record_success(data.get("service", "agent_runner"))
        self.metrics.record(data)

    async def _on_step_failed(self, data):
        self.breakers.record_failure(data.get("service", "agent_runner"))
        self.metrics.record(data)
        if data.get("error_category") == "permanent":
            await self.dlq.enqueue(data)
```

### 4.2 CircuitBreakerRegistry + BreakerState

```python
class CircuitBreakerRegistry:
    """
    @description Observer 使用的读写接口，三态自动转换
    （failure_threshold=5, recovery_timeout=60s）
    """
    def record_failure(self, service: str): ...   # CLOSED→OPEN / HALF_OPEN→OPEN
    def record_success(self, service: str): ...   # HALF_OPEN→CLOSED
    def check_recovery(self, service: str): ...   # OPEN→HALF_OPEN
    def reader(self) -> BreakerStateReader: ...
```

数据流：`Observer (写) → CircuitBreakerRegistry → BreakerStateReader → Scheduler (读)`

---

## 5. 基础设施

### 5.1 StateStore

```python
class StateStore:
    """
    @description 统一状态存储，职责限于状态持久化 + 通用 KV。
    用户交互 IPC 由 StateBackedUserInteractor 封装。
    """
    # --- 任务状态 CRUD ---
    async def save(self, envelope: TaskEnvelope): ...
    async def load(self, task_id: str) -> TaskEnvelope | None: ...
    async def update_phase(self, task_id: str, phase: Phase): ...
    async def list_recent(self, status: str = None, limit: int = 10) -> list: ...
    async def list_non_terminal(self) -> list[TaskEnvelope]: ...
    async def cancel(self, task_id: str) -> bool: ...

    # --- 步骤幂等 checkpoint ---
    async def checkpoint_step(self, task_id: str, idempotency_key: str, result: StepResult): ...
    async def is_step_completed(self, task_id: str, idempotency_key: str) -> bool: ...
    async def load_step_result(self, task_id: str, idempotency_key: str) -> StepResult | None: ...

    # --- 通用 KV（供 adapter 使用） ---
    async def set_kv(self, task_id: str, key: str, value: Any) -> None: ...
    async def get_kv(self, task_id: str, key: str) -> Any | None: ...
```

### 5.2 StateBackedUserInteractor

```python
class StateBackedUserInteractor(UserInteractor):
    """
    @description 通过 StateStore KV + asyncio.Event 实现用户交互。
    StateStore 只提供通用 KV 存储，交互等待/唤醒语义由本 adapter 封装。
    """
    def __init__(self, store: StateStore, gateway_notifier: "GatewayNotifier"):
        self._store = store
        self._notifier = gateway_notifier
        self._pending: dict[str, asyncio.Event] = {}

    async def request_decision(self, envelope, decision, timeout_s):
        """
        @description 系统层决策升级——发送决策请求，等待用户响应或超时
        @returns {str} 用户选择或超时后的 decision.auto_choice
        """
        await self._notifier.send_decision_request(envelope, decision)
        result = await self._wait_response(
            envelope.task_id, "decision", timeout_s,
        )
        return result if result is not None else decision.auto_choice

    async def request_input(self, envelope, prompt, timeout_s):
        """
        @description 工作流层交互——发送输入请求，等待用户响应或超时
        @returns {str | None} 用户输入，None 表示超时
        """
        await self._notifier.send_input_request(envelope, prompt)
        return await self._wait_response(
            envelope.task_id, "input", timeout_s,
        )

    async def submit_response(self, task_id: str, key: str, value: str | None):
        """
        @description Gateway 收到用户响应后调用，唤醒等待方
        """
        await self._store.set_kv(task_id, f"interaction:{key}", value)
        event = self._pending.get(f"{task_id}:{key}")
        if event:
            event.set()

    async def _wait_response(self, task_id, key, timeout_s) -> str | None:
        event = asyncio.Event()
        self._pending[f"{task_id}:{key}"] = event
        try:
            await asyncio.wait_for(event.wait(), timeout=timeout_s)
            return await self._store.get_kv(task_id, f"interaction:{key}")
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending.pop(f"{task_id}:{key}", None)
```

### 5.3 EventBus

异步事件总线。接口：`subscribe(event, handler)` / `emit(event, data)` / `start()` / `stop()`。`emit()` 为非阻塞 `put_nowait`，Observer 在后台消费循环处理。异常不影响主路径，队列满时静默丢弃（背压降级）。

### 5.4 MCPBus / LLMPool / KnowledgeBase

- **MCPBus**：统一 MCP 工具管理（`prepare()` / `health_check()` / `get_all_groups()`）
- **LLMPool**：LLM 服务池（`chat()` / `health_check()`），支持多模型路由
- **KnowledgeBase**：统一知识库（`search()` / `save()`），聚合 memory/ + kb/ + team-repo/kb/

---

## 6. 工作流 DSL

### 6.1 原语：step / parallel / ask

```python
# modules/dsl/primitives.py

import asyncio
import hashlib
from contextvars import ContextVar

_runtime_var: ContextVar["WorkflowRuntime"] = ContextVar("workflow_runtime")

AGENT_LABEL_MAP: dict[str, dict[str, str]] = {
    "executor": {},
    "reviewer": {"review": "true"},
    "instant": {"instant": "true"},
}


def _build_task_step(name, prompt, *, agent="executor", mcp=None, labels=None,
                     timeout=300, required=True, max_retries=2,
                     on_fail="auto", prompt_extra="", **_kw) -> TaskStep:
    """
    @description TaskStep 构建的唯一入口——合并 AGENT_LABEL_MAP + MCP 标签 + 额外标签
    """
    ...


async def step(name: str, prompt: str, *, agent="executor", mcp=None,
               labels=None, timeout=300, required=True, max_retries=2,
               on_fail="auto", prompt_extra="") -> StepResult:
    """
    @description 单步执行原语
    @param {str} agent - 角色语义标签（executor/reviewer/instant），自动映射为 Worker 标签
    @param {list[str]} mcp - 需要的 MCP 工具组
    @param {str} on_fail - 失败策略：auto / skip / abort / llm_fallback
    """
    runtime = _runtime_var.get()
    return await runtime.execute_step(_build_task_step(
        name, prompt, agent=agent, mcp=mcp, labels=labels,
        timeout=timeout, required=required, max_retries=max_retries,
        on_fail=on_fail, prompt_extra=prompt_extra,
    ))


async def parallel(steps: list[dict]) -> list[StepResult]:
    """
    @description 并行执行多个步骤，通过 Scheduler.schedule_batch() 批量调度
    @param {list[dict]} steps - 步骤参数列表，每个元素是 step() 的关键字参数
    @returns {list[StepResult]}
    """
    runtime = _runtime_var.get()
    task_steps = [_build_task_step(**s) for s in steps]
    return await runtime.schedule_batch_and_execute(task_steps)


async def ask(
    name: str,
    prompt: str,
    *,
    options: list[str] | None = None,
    timeout: int = 60,
    default: str = "",
) -> str:
    """
    @description 执行中向用户请求输入的原语。
    通过 InteractionCheckpoint 支持崩溃恢复——同一交互点重放时直接返回已保存响应。
    超时返回 default，保证闭环不卡死。
    @param {str} name - 交互点名称
    @param {str} prompt - 向用户展示的提示信息
    @param {list[str]} options - 可选项列表（None 表示自由输入）
    @param {int} timeout - 等待用户响应的超时秒数
    @param {str} default - 超时时的默认返回值
    @returns {str} 用户输入或超时默认值
    """
    runtime = _runtime_var.get()
    interaction_key = hashlib.sha256(
        f"ask:{name}:{prompt[:100]}".encode(),
    ).hexdigest()[:16]

    saved = await runtime.load_interaction(interaction_key)
    if saved is not None:
        return saved

    await runtime.save_interaction_request(interaction_key, prompt, options, default)
    result = await runtime.request_user_input(name, prompt, options, timeout, default)
    await runtime.save_interaction_response(interaction_key, result)
    return result
```

### 6.2 @workflow + WorkflowEntry + WorkflowRegistry

```python
# modules/dsl/registry.py

from dataclasses import dataclass, field
from typing import Callable

DEFAULT_MIDDLEWARES = ["cancellation", "event", "idempotency", "retry"]


@dataclass
class WorkflowEntry:
    """
    @description 工作流注册条目
    """
    fn: Callable
    timeout: int
    middlewares: list[str] = field(default_factory=lambda: list(DEFAULT_MIDDLEWARES))
    interaction_mode: str = "auto"  # "auto" | "adaptive" | "confirm"


_workflows: dict[str, WorkflowEntry] = {}


def workflow(
    name: str,
    *,
    timeout: int = 300,
    middlewares: list[str] | None = None,
    interaction_mode: str = "auto",
):
    """
    @description 装饰器，注册工作流函数
    @param {str} name - 工作流名称
    @param {int} timeout - 工作流级超时秒数
    @param {list[str]} middlewares - 中间件名称列表，None 时使用默认全链
    @param {str} interaction_mode - 用户参与策略：
        "auto"     所有系统层决策完全自主（默认）
        "adaptive" 低置信度系统层决策升级为用户确认
        "confirm"  所有系统层决策点都询问用户
    """
    def decorator(fn):
        _workflows[name] = WorkflowEntry(
            fn=fn, timeout=timeout,
            middlewares=middlewares if middlewares is not None else list(DEFAULT_MIDDLEWARES),
            interaction_mode=interaction_mode,
        )
        return fn
    return decorator


class WorkflowRegistry:
    """
    @description 工作流注册表
    """
    def get(self, name: str) -> Callable | None:
        entry = _workflows.get(name)
        return entry.fn if entry else None

    def get_entry(self, name: str) -> WorkflowEntry | None:
        return _workflows.get(name)

    def list_all(self) -> list[str]:
        return list(_workflows.keys())
```

### 6.3 内置工作流

```python
# workflows/instant.py
@workflow("instant", timeout=30, middlewares=["cancellation", "event", "retry"])
async def instant_workflow(ctx):
    """
    @description 纯对话/问候/简单问答——无需幂等缓存
    """
    result = await step("直接应答", ctx.task, agent="instant", max_retries=1)
    return result.output


# workflows/general.py
@workflow("general", timeout=300)
async def general_workflow(ctx):
    """
    @description 通用任务：规划 → 执行 → 审核
    """
    plan = await step("任务规划", ctx.task)
    result = await step("执行任务", plan.output)
    review = await step("结果审核", result.output, agent="reviewer")
    return review.output


# workflows/coding.py
@workflow("coding", timeout=600, interaction_mode="adaptive")
async def coding_workflow(ctx):
    """
    @description 编程任务——adaptive 模式：低置信度分类时确认，迭代时可升级为用户决策
    """
    reqs = await step("需求分析", ctx.task)
    code = await step("编写代码", reqs.output, mcp=["file", "bash"])
    review = await step("代码审核", code.output, agent="reviewer")
    if not review.passed:
        code = await step("修正代码", code.output, mcp=["file", "bash"],
                          prompt_extra=f"审核反馈: {review.feedback}")
    test = await step("运行测试", code.output, mcp=["bash"])
    return test.output


# workflows/research.py
@workflow("research", timeout=300)
async def research_workflow(ctx):
    """
    @description 调研任务——并行搜索 + 综合分析
    """
    queries = await step("提取查询", ctx.task)
    results = await parallel([
        {"name": f"搜索-{i}", "prompt": q, "mcp": ["search"]}
        for i, q in enumerate(queries.items or [queries.output])
    ])
    synthesis = await step("综合分析", "\n".join(r.output for r in results if r.success))
    review = await step("审核结论", synthesis.output, agent="reviewer")
    return review.output


# workflows/translation.py
@workflow("translation", timeout=180)
async def translation_workflow(ctx):
    """
    @description 翻译任务
    """
    understood = await step("理解原文", ctx.task)
    translated = await step("翻译", understood.output)
    review = await step("校对", translated.output, agent="reviewer")
    return review.output


# workflows/database.py
@workflow("database", timeout=180)
async def database_workflow(ctx):
    """
    @description 数据库任务
    """
    spec = await step("分析需求", ctx.task)
    sql = await step("编写 SQL", spec.output, mcp=["database"])
    review = await step("审核 SQL", sql.output, agent="reviewer")
    result = await step("执行查询", sql.output, mcp=["database"])
    return result.output
```

---

## 7. WorkflowRuntime 执行引擎

WorkflowRuntime 是 Controller 在 EXECUTING 阶段的代理所有者（阶段委托模式），通过依赖注入获得（长生命周期共享实例）。

### 7.1 级联超时模型

```
工作流超时 (WorkflowEntry.timeout, 如 600s)
  └── 步骤超时 (TaskStep.timeout, 如 300s)
       └── 后端超时 (AgentBackend 的 subprocess timeout)
```

每层超时 <= 上层超时，保证不会出现"步骤已超时但工作流还在等"的不一致。

### 7.2 完整实现

```python
class WorkflowRuntime:
    """
    @description 桥接 DSL 原语与系统组件，通过可配置中间件链处理每个步骤
    """
    MIDDLEWARE_REGISTRY: dict[str, type] = {}

    def __init__(
        self,
        scheduler: Scheduler,
        state_store: StateStore,
        event_bus: EventBus,
        llm_service: "LLMPool",
        user_interactor: "UserInteractor | None" = None,
    ):
        self._scheduler = scheduler
        self._state_store = state_store
        self._event_bus = event_bus
        self._llm_service = llm_service
        self._interactor = user_interactor

        self.MIDDLEWARE_REGISTRY = {
            "cancellation": CancellationMiddleware,
            "event": lambda: EventMiddleware(event_bus),
            "idempotency": lambda: IdempotencyMiddleware(state_store),
            "retry": lambda: RetryMiddleware(llm_service),
        }

    def _build_chain(self, middleware_names: list[str]) -> "MiddlewareChain":
        """
        @description 根据工作流配置动态构建中间件链
        """
        middlewares = []
        for name in middleware_names:
            factory = self.MIDDLEWARE_REGISTRY.get(name)
            if factory:
                middlewares.append(
                    factory() if callable(factory) else factory
                )
        return MiddlewareChain(middlewares)

    async def run(
        self,
        workflow_fn,
        ctx: TaskContext,
        timeout: int = 300,
        middlewares: list[str] | None = None,
    ) -> WorkflowResult:
        """
        @description 执行工作流函数，支持工作流级超时和可配置中间件链
        @param {Callable} workflow_fn - 工作流函数
        @param {TaskContext} ctx - 任务上下文
        @param {int} timeout - 工作流级超时秒数
        @param {list[str]} middlewares - 中间件名称列表
        """
        if middlewares is None:
            middlewares = ["cancellation", "event", "idempotency", "retry"]
        self._chain = self._build_chain(middlewares)
        self._ctx = ctx
        self._step_results: list[StepResult] = []
        token = _runtime_var.set(self)
        try:
            output = await asyncio.wait_for(
                workflow_fn(ctx), timeout=timeout
            )
            if isinstance(output, WorkflowResult):
                result = output
            else:
                result = WorkflowResult(success=True, output=str(output))
            result.steps = list(self._step_results)
            result.degraded_steps = [
                r.step_name for r in self._step_results
                if r.degraded or r.skipped
            ]
            return result
        except asyncio.TimeoutError:
            return WorkflowResult(
                success=False,
                error=f"workflow timeout ({timeout}s)",
                steps=list(self._step_results),
            )
        except WorkflowCancelled:
            return WorkflowResult(
                success=False, error="cancelled",
                steps=list(self._step_results),
            )
        except WorkflowAborted as e:
            return WorkflowResult(
                success=False, error=str(e),
                steps=list(self._step_results),
            )
        finally:
            _runtime_var.reset(token)

    async def execute_step(self, step: TaskStep) -> StepResult:
        """
        @description 中间件链入口——DSL step() 原语最终调用此方法
        """
        result = await self._chain.process(
            step, self._ctx, self._schedule_and_execute
        )
        self._step_results.append(result)
        return result

    async def schedule_batch_and_execute(
        self, steps: list[TaskStep]
    ) -> list[StepResult]:
        """
        @description 批量调度 + 并行执行，供 parallel() 原语使用
        """
        assignments = await self._scheduler.schedule_batch(
            steps, self._ctx.envelope.priority
        )
        results = await asyncio.gather(*[
            self._chain.process(
                step, self._ctx,
                lambda s, a=assignment: a.slot.execute_and_release(s),
            )
            for step, assignment in zip(steps, assignments)
        ], return_exceptions=True)
        return [
            r if not isinstance(r, Exception)
            else StepResult(step_name="parallel", success=False, error=str(r))
            for r in results
        ]

    async def _schedule_and_execute(self, step: TaskStep) -> StepResult:
        """
        @description 中间件链最内层：调度 + 执行
        """
        assignment = await self._scheduler.schedule(
            step, self._ctx.envelope.priority
        )
        return await assignment.slot.execute_and_release(step)

    async def load_interaction(self, interaction_key: str) -> str | None:
        """
        @description 检查 InteractionCheckpoint 中是否有已保存的用户响应（崩溃恢复）
        """
        return await self._state_store.get_kv(
            self._ctx.envelope.task_id, f"interaction:{interaction_key}:response",
        )

    async def save_interaction_request(
        self, interaction_key: str, prompt: str,
        options: list[str] | None, default: str,
    ):
        """
        @description 写入 InteractionCheckpoint 请求
        """
        await self._state_store.set_kv(
            self._ctx.envelope.task_id,
            f"interaction:{interaction_key}:request",
            {"prompt": prompt, "options": options, "default": default},
        )

    async def save_interaction_response(self, interaction_key: str, response: str):
        """
        @description 写入 InteractionCheckpoint 响应
        """
        await self._state_store.set_kv(
            self._ctx.envelope.task_id,
            f"interaction:{interaction_key}:response",
            response,
        )

    async def request_user_input(
        self,
        name: str,
        prompt: str,
        options: list[str] | None,
        timeout: int,
        default: str,
    ) -> str:
        """
        @description 执行中向用户请求输入，供 ask() 原语调用。
        UserInteractor 未注入则直接返回 default。
        @returns {str} 用户输入或超时默认值
        """
        if self._interactor is None:
            return default
        result = await self._interactor.request_input(
            self._ctx.envelope, prompt, timeout,
        )
        return result if result is not None else default
```

---

## 8. 中间件链

### 8.1 执行顺序

```
Cancellation → Event → Idempotency → Retry → 实际调度执行
```

| 位置 | 中间件 | 选择理由 |
|------|--------|---------|
| 最外层 | CancellationMiddleware | fail-fast，避免已取消任务进入后续处理 |
| 第二层 | EventMiddleware | 包裹 Idempotency 和 Retry，确保缓存命中/最终失败均有事件记录 |
| 第三层 | IdempotencyMiddleware | 在重试之前检查缓存，避免对已完成步骤发起重试 |
| 最内层 | RetryMiddleware | 包裹实际执行，处理瞬态故障的指数退避重试 |

中间件链可通过 `@workflow(middlewares=[...])` 按需配置。

### 8.2 StepMiddleware 接口

```python
class StepMiddleware:
    """
    @description 步骤执行中间件接口
    """
    async def process(
        self, step: TaskStep, ctx: "TaskContext", next_fn
    ) -> StepResult:
        return await next_fn(step)
```

### 8.3 CancellationMiddleware

```python
class CancellationMiddleware(StepMiddleware):
    """
    @description 每步执行前检查取消标记
    """
    async def process(self, step, ctx, next_fn):
        if ctx.is_cancelled:
            raise WorkflowCancelled(step.name)
        return await next_fn(step)
```

### 8.4 EventMiddleware

```python
class EventMiddleware(StepMiddleware):
    """
    @description 步骤事件通知，覆盖所有执行路径（含缓存命中和取消）
    """
    def __init__(self, event_bus: "EventBus"):
        self._bus = event_bus

    async def process(self, step, ctx, next_fn):
        event_name = None
        event_data = {
            "task_id": ctx.envelope.task_id,
            "step_name": step.name,
            "service": "agent_runner",
            "channel": ctx.envelope.channel,
        }
        try:
            result = await next_fn(step)
            event_name = "step_completed" if result.success else "step_failed"
            event_data["success"] = result.success
            event_data["cached"] = result.cached
            event_data["error_category"] = (
                result.error_category.value if result.error_category else ""
            )
            return result
        except WorkflowCancelled:
            event_name = "step_cancelled"
            raise
        finally:
            if event_name:
                await self._bus.emit(event_name, event_data)
```

### 8.5 IdempotencyMiddleware

```python
class IdempotencyMiddleware(StepMiddleware):
    """
    @description 幂等缓存——已完成的步骤直接返回（标记 cached=True），
    成功的步骤写入 checkpoint
    """
    def __init__(self, state_store: "StateStore"):
        self._store = state_store

    async def process(self, step, ctx, next_fn):
        cached = await self._store.load_step_result(
            ctx.envelope.task_id, step.idempotency_key
        )
        if cached:
            cached.cached = True
            return cached

        result = await next_fn(step)

        if result.success:
            await self._store.checkpoint_step(
                ctx.envelope.task_id, step.idempotency_key, result
            )
        return result
```

### 8.6 RetryMiddleware

```python
class RetryMiddleware(StepMiddleware):
    """
    @description 指数退避重试 + 降级 + on_fail 策略。
    TRANSIENT → 指数退避重试（max_retries 次）；
    PERMANENT → 立即中止；
    DEGRADABLE + not required → 标记 degraded 跳过。
    重试耗尽后按 step.on_fail 策略处理（auto 时 required ? abort : skip）。
    """
    def __init__(self, llm_service: "LLMPool"):
        self._llm = llm_service

    async def process(self, step, ctx, next_fn):
        ...
```

### 8.7 MiddlewareChain

```python
class MiddlewareChain:
    """
    @description 按注册顺序嵌套执行——build_chain 递归构建 next_fn 调用链
    """
    def __init__(self, middlewares: list[StepMiddleware]):
        self._middlewares = middlewares

    async def process(self, step, ctx, final_fn) -> StepResult:
        ...
```

---

## 9. 错误处理策略

### 9.1 错误分类

| 类别 | 含义 | 自动处理 | 示例 |
|------|------|---------|------|
| TRANSIENT | 临时故障 | 指数退避重试（最多 max_retries 次） | timeout, 429, ECONNREFUSED |
| PERMANENT | 永久故障 | 立即中止 | 401, 404, 认证失败 |
| DEGRADABLE | 非关键故障 | 标记 degraded 跳过（仅 required=False） | MCP 不可用 |

### 9.2 两层设计

**自动层**（中间件链内置）：RetryMiddleware 按 ErrorCategory 自动处理每个 `step()`。

**显式层**（工作流作者可选覆盖）：

```python
# 方式 1: on_fail 参数
await step("外部 API", prompt, on_fail="llm_fallback")

# 方式 2: try/except + ask() 实现步骤失败的用户参与
try:
    result = await step("可能失败的步骤", prompt, on_fail="abort")
except WorkflowAborted:
    choice = await ask("步骤失败", "执行失败，请选择：",
                       options=["重试", "跳过", "终止"], default="终止")
    if choice == "重试":
        result = await step("可能失败的步骤", prompt)
    elif choice == "跳过":
        result = StepResult(step_name="备用", success=False, skipped=True)
    else:
        return WorkflowResult(success=False, error="用户选择终止")
```

### 9.3 DLQ

永久失败且无法恢复的步骤进入 DLQ。Observer 管理 DLQ，定期扫描并发出告警。

---

## 10. 配置汇总

### 10.1 classifier.yaml

```yaml
# config/classifier.yaml
rules:
  - name: coding
    keywords: ["代码", "编程", "写代码", "bug", "函数", "重构"]
    priority: 10
  - name: research
    keywords: ["搜索", "调研", "查找", "论文"]
    priority: 10
  - name: translation
    keywords: ["翻译", "translate"]
    priority: 10
  - name: database
    keywords: ["数据库", "SQL", "查询"]
    priority: 10

instant_threshold:
  max_length: 20
  exclude_keywords: ["帮我", "请", "写", "做", "分析"]

fallback: "general"

confirmation_mode: adaptive
confirm_threshold: 0.6

iteration:
  reclassify_threshold: 0.5

escalation:
  classification:
    adaptive_threshold: 0.6
    timeout_s: 30
  iteration:
    adaptive_threshold: 0.5
    timeout_s: 30
  hook_failure:
    adaptive_threshold: 0.5
    timeout_s: 15
```

### 10.2 workers.yaml

```yaml
# config/workers.yaml
workers:
  - id: alpha
    workspace: ~/.openclaw/workspace/
    backend: mini-agent
    labels:
      mcp.file: "true"
      mcp.bash: "true"
      mcp.search: "true"
      mcp.memory: "true"
    capacity: 2

  - id: beta
    workspace: ~/.openclaw/workspace-worker/
    backend: mini-agent
    labels:
      mcp.file: "true"
      mcp.database: "true"
      mcp.bash: "true"
    capacity: 2

  - id: gamma
    workspace: ~/.openclaw/workspace-reviewer/
    backend: mini-agent
    labels:
      review: "true"
      mcp.memory: "true"
    capacity: 1

  - id: instant
    workspace: ""
    backend: llm-direct
    labels:
      instant: "true"
    capacity: 5
```

---

## 11. 目录结构

```
~/.openclaw/
├── config/
│   ├── module-registry.yaml     # 模块启用配置
│   ├── workers.yaml             # Worker 注册配置
│   ├── classifier.yaml          # 分类规则 + 升级行为配置
│   └── mcp-bus.yaml             # 统一 MCP 配置
│
├── modules/
│   ├── base.py                  # ModuleBase
│   ├── registry.py              # ModuleRegistry
│   │
│   ├── gateway/
│   │   └── gateway.py
│   │
│   ├── controller/
│   │   ├── task_controller.py   # 入口分派
│   │   ├── reconciler.py        # 纯状态机
│   │   ├── classifier.py        # 策略链分类器
│   │   ├── command_handler.py   # 斜杠指令
│   │   ├── hook_runner.py       # 钩子编排 + 决策升级
│   │   ├── iteration_strategy.py # 迭代决策 + 决策升级
│   │   └── escalation.py        # EscalatableDecision + should_escalate
│   │
│   ├── scheduler/
│   │   ├── scheduler.py
│   │   └── worker_pool.py
│   │
│   ├── worker/
│   │   ├── worker.py
│   │   └── backends.py
│   │
│   ├── observer/
│   │   ├── observer.py
│   │   └── breaker.py
│   │
│   ├── infra/
│   │   └── event_bus.py
│   │
│   ├── dsl/
│   │   ├── primitives.py        # step / parallel / ask
│   │   ├── middleware.py         # 4 个中间件 + MiddlewareChain
│   │   ├── runtime.py           # WorkflowRuntime
│   │   ├── registry.py          # @workflow + WorkflowRegistry
│   │   └── errors.py            # WorkflowCancelled / WorkflowAborted
│   │
│   ├── planner/                 # 保留
│   └── task_reviewer/           # 保留
│
├── workflows/
│   ├── instant.py
│   ├── general.py
│   ├── coding.py
│   ├── research.py
│   ├── translation.py
│   └── database.py
│
├── services/
│   ├── state_store/             # 统一状态存储
│   ├── mcp_bus/                 # 统一 MCP 管理
│   ├── llm_service/
│   └── ...
│
├── scripts/
│   ├── openclaw_task_bridge.py  # 瘦身为 Gateway 适配
│   └── ...
│
└── docs/
    ├── WORKFLOW_DESIGN.md           # 架构设计
    └── WORKFLOW_IMPLEMENTATION.md   # 本文档
```

---

## 12. 实施路径

### 分期计划

| Phase | 周期 | 范围 | 关键产出 |
|-------|------|------|---------|
| 1 | 1-2 周 | Controller + Scheduler + Gateway + EventBus | 核心状态机骨架（含 HookRunner / IterationStrategy / EscalatableDecision），外部接口不变 |
| 2 | 1-2 周 | Worker + Backends + Observer + Breaker | 通用 Worker + 可插拔后端 + 旁路观察 |
| 3 | 1-2 周 | DSL + 中间件链 + 6 个内置工作流 | Python DSL + WorkflowRuntime |
| 4 | 1 周 | StateStore 合并 + MCP Bus 合并 + 归档清理 | 基础设施统一 |

### 向后兼容

`OpenClawTaskBridge.execute_task()` 方法签名不变，内部改为 `Gateway → Controller` 调用链。外部调用方无需修改。
