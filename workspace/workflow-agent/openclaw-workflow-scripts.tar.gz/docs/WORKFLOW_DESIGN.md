# OpenClaw 工作流代理架构设计

> **一句话结论**：Gateway → Controller → Scheduler → Worker 四角色主路径，驱动任务经 RECEIVED → CLASSIFIED → PREPARING → EXECUTING 到达终态；决策升级模式将系统层决策（分类 / 迭代 / 钩子失败）与工作流层交互（`ask()` 原语）正交分离，9 个闭环 + 双层迭代 + 可配置中间件链 + Classifier 策略链保证可靠交付。

---

## 目录

1. [设计原则](#1-设计原则)
2. [架构总览](#2-架构总览)
3. [决策模型](#3-决策模型)
4. [全链路闭环保证](#4-全链路闭环保证)
5. [组件职责概述](#5-组件职责概述)

> 本文档只描述架构设计与设计思路（Why + What）。完整接口定义、数据结构和实现代码见 [WORKFLOW_IMPLEMENTATION.md](WORKFLOW_IMPLEMENTATION.md)。

---

## 1. 设计原则

### 1.1 金字塔原理（MECE）

- **结论先行**：每个模块的接口先定义"做什么"，内部再回答"怎么做"
- **归类分组**：同层组件职责互斥、完全穷尽（MECE）
- **逻辑递进**：任务生命周期严格顺序推进，中间件链按确定性顺序嵌套

### 1.2 集群管理范式

- **协调循环**（Reconciliation Loop）：Controller 对标 K8s Controller，持续推进 desired state（DELIVERED）
- **标签调度**：Worker 声明能力标签，Scheduler 按需匹配，对标 K8s node label + pod affinity
- **心跳自愈**：Worker 定期上报，超时标记 OFFLINE 并重调度
- **断路器读写分离**：Observer 写入健康状态，Scheduler 只读消费

### 1.3 正交分离

系统用两个维度正交管理：

- **时间轴**：任务经过哪些阶段（RECEIVED → CLASSIFIED → PREPARING → EXECUTING → 终态）
- **空间轴**：哪个角色在哪个阶段做什么（Gateway / Controller / Scheduler / Worker / Observer / Infra）

两者不混合在同一个层次结构中。

#### 1.3.1 共享状态中介模式（Shared State Mediation）

Observer 通过 CircuitBreakerRegistry → BreakerStateReader 向 Scheduler 传递健康状态，间接影响调度决策。这是 Observer "只观察不编排"原则的**唯一受控例外**：Observer 不发起控制流，仅通过写入共享状态、由 Scheduler 主动读取的方式产生间接影响。数据流严格单向——Observer 写入、Scheduler 只读，不构成控制回路。

```
Observer ──(write)──→ CircuitBreakerRegistry ──(read-only view)──→ BreakerStateReader ──→ Scheduler
                                                                         ↑ 只读，无回写
```

#### 1.3.2 阶段委托模式（Phase Delegation）

Reconciler 在 EXECUTING 阶段将控制权**完全委托**给 WorkflowRuntime，直到收回 WorkflowResult。WorkflowRuntime 是 EXECUTING 阶段的"代理所有者"（Delegated Owner），拥有该阶段内的完整编排权——中间件链组装、步骤调度（通过 Scheduler）、用户交互（通过 `ask()` 原语）。它的生命周期和作用范围由 Reconciler 限定在单个阶段内。

```
Reconciler ──(delegate EXECUTING)──→ WorkflowRuntime ──(return WorkflowResult)──→ Reconciler
                                          │
                                          ├── Middleware Chain
                                          ├── Scheduler.schedule()
                                          └── UserInteractor.request_input()
```

### 1.4 决策升级模式（Decision Escalation）

系统在运行过程中会产生多种**自主决策**（选工作流、选迭代方向、选钩子失败应对策略）。这些决策通过 `interaction_mode` 配置控制是否升级为用户参与：

- `auto`：系统完全自主，不与用户交互
- `adaptive`：当系统对自主选择的置信度低于阈值时，升级为用户确认
- `confirm`：所有决策点都升级为用户确认

所有升级的决策均有超时兜底——超时后自动使用系统的自主选择，保证闭环不卡死。

决策升级与工作流层交互（`ask()` 原语）分属不同层次：

```mermaid
flowchart TB
    subgraph systemLayer ["系统层决策（可升级）"]
        D1["分类确认"]
        D2["迭代方向"]
        D3["钩子失败应对"]
    end

    subgraph workflowLayer ["工作流层交互（作者显式定义）"]
        D4["ask() 原语"]
    end

    IM["interaction_mode\nauto / adaptive / confirm"]
    IM -->|"控制升级策略"| systemLayer
    IM -.->|"不影响"| workflowLayer

    SE["EscalatableDecision\n+ should_escalate()\n+ request_decision()"]
    systemLayer -->|"统一机制"| SE

    RI["UserInteractor\nrequest_input()"]
    workflowLayer -->|"直接使用"| RI
```

- **系统层决策**由 `EscalatableDecision` 数据结构描述（含自主选择、置信度、可选项、决策理由），由 `should_escalate()` 纯函数统一判定是否升级，由 `UserInteractor.request_decision()` 执行用户交互。
- **工作流层交互**由工作流作者在 DSL 中通过 `ask()` 原语显式定义，通过 `UserInteractor.request_input()` 执行，与 `interaction_mode` 无关。

---

## 2. 架构总览

### 2.1 正交矩阵

```
              | RECEIVED | CLASSIFIED | PREPARING  | EXECUTING  | DELIVERED/FAILED |
  ------------+----------+------------+------------+------------+------------------+
  Gateway     |    ●     |            |            |            |        ●         |
  Controller  |    ●     |     ●      |     ●      | ●(via RT)  |                  |
  Scheduler   |          |            |            |     ●      |                  |
  Worker      |          |            |            |     ●      |                  |
  Observer    |    ○     |     ○      |     ○      |     ○      |        ○         |
  Infra       |          |     ●      |     ●      |     ●      |                  |

  ● = 主动参与   ○ = 被动观察
  RT = WorkflowRuntime，EXECUTING 阶段的代理所有者（§1.3.2）
```

Controller 在终态不主动参与——结果投递完全由 Gateway 负责，保持单向数据流。

### 2.2 角色清单

| 角色 | 职责 | 路径 |
|------|------|------|
| Gateway | 协议适配 + 准入校验 + 结果回传（含交付重试） | 主路径 |
| Controller | 协调循环（状态机），含 Reconciler / Classifier / CommandHandler / HookRunner / IterationStrategy | 主路径 |
| Scheduler | 优先级队列 + 标签匹配 | 主路径 |
| Worker | 通用步骤执行（可插拔 Agent 后端） | 主路径 |
| Observer | 事件订阅 + 断路器写入 + DLQ + 指标记录 | 旁路 |
| Infrastructure | LLM Pool / MCP Bus / State Store / Knowledge Base | 被调用 |

**WorkflowRuntime** 是 Controller 在 EXECUTING 阶段的代理所有者（§1.3.2），桥接 DSL 原语与 Scheduler / Worker。4 个主路径角色在每个阶段职责不重叠（MECE）。

### 2.3 架构图

```mermaid
flowchart TB
    subgraph input [用户入口]
        Feishu[飞书 Bot]
        API[REST API]
        CLI[命令行]
    end

    subgraph gateway [Gateway]
        GW[统一网关]
        Validate[准入校验]
        DeliveryRetry[交付重试]
    end

    subgraph controller [Controller]
        CH["CommandHandler\n(/help /status /cancel ...)"]
        RC["Reconciler\n(纯状态机驱动)"]
        CL[Classifier]
        HR["HookRunner\n(钩子编排+决策升级)"]
        IS["IterationStrategy\n(迭代决策+决策升级)"]
    end

    subgraph runtime ["WorkflowRuntime · EXECUTING 代理所有者"]
        WR["DSL 执行"]
        MW["中间件链\n(取消/事件/幂等/重试)"]
    end

    subgraph scheduler [Scheduler]
        PQ[优先级队列]
        LM["标签匹配器\n(读断路器)"]
    end

    subgraph workers [Worker Pool]
        WS1["WorkerSlot-alpha"]
        WS2["WorkerSlot-beta"]
        WS3["WorkerSlot-gamma"]
        WS4["WorkerSlot-instant"]
        W1["Worker-alpha\n{mcp.file, mcp.bash}"]
        W2["Worker-beta\n{mcp.search}"]
        W3["Worker-gamma\n{review}"]
        W4["Worker-instant\n{instant}"]
    end

    subgraph observer [Observer 旁路]
        EB[EventBus]
        CB["CircuitBreaker\n(写状态)"]
        DLQ_obs[DeadLetterQueue]
        MT[MetricsCollector]
    end

    subgraph infra [Infrastructure]
        LLM[LLM Pool]
        MCP[MCP Bus]
        SS[State Store]
        KB[Knowledge Base]
    end

    Feishu --> GW
    API --> GW
    CLI --> GW
    GW --> Validate
    Validate -->|TaskEnvelope| RC
    RC -->|"斜杠指令"| CH
    RC --> CL
    CL -->|"workflow name\n+ ClassifyResult"| HR
    HR --> WR
    RC -.->|"委托 EXECUTING"| WR
    WR --> MW
    MW -->|StepRequest| PQ
    PQ --> LM
    LM -->|Assignment| WS1 --> W1
    LM -->|Assignment| WS2 --> W2
    LM -->|Assignment| WS3 --> W3
    LM -->|Assignment| WS4 --> W4
    W1 -->|StepResult| MW
    W2 -->|StepResult| MW
    W3 -->|StepResult| MW
    W4 -->|StepResult| MW
    WR -->|WorkflowResult| IS
    IS -->|"next phase"| RC
    RC -->|Response| GW
    GW --> DeliveryRetry

    W1 --> MCP
    W2 --> MCP
    W3 --> MCP
    CL --> LLM
    WR --> SS
    RC --> SS

    RC -.->|events| EB
    WR -.->|events| EB
    EB -.-> CB
    EB -.-> DLQ_obs
    EB -.-> MT
    LM -.->|"读 breaker"| CB
```

### 2.4 任务生命周期

```
RECEIVED ──→ CLASSIFIED ──→ PREPARING ──→ EXECUTING ──→ DELIVERED（成功）
                  ↑              ↑              │
                  │(reclassify)  │(迭代，        ├──→ FAILED（最终失败）
                  │              │ 不重新分类)    │
                  └──────────────┴──────────────┘└──→ CANCELLED（用户取消）
```

4 个核心阶段 + 3 个终态，每阶段在 State Store 中持久化。崩溃恢复时从最后持久化的阶段继续。

| 阶段 | 实质工作 | 负责角色 |
|------|---------|---------|
| RECEIVED | 解析指令、准入校验 | Gateway + Controller |
| CLASSIFIED | 分类选工作流 + 决策升级确认（§3） | Controller（Classifier + Reconciler） |
| PREPARING | 预执行钩子 + 失败决策升级（§3） | Controller（HookRunner） |
| EXECUTING | WorkflowRuntime 驱动工作流 + 中间件链 | Controller(via RT) + Scheduler + Worker |
| DELIVERED | 结果回传（含重试） | Gateway |
| FAILED | 最终失败（重试耗尽/永久错误），记录 DLQ | Gateway + Observer |
| CANCELLED | 用户主动取消 | Controller |

DELIVERED 限定为"成功交付"，FAILED 表示终态失败。PREPARING 从 CLASSIFIED 中拆出，确保每阶段语义纯粹。EXECUTING 完成后由 IterationStrategy 决定下一阶段（含决策升级，§3）。

---

## 3. 决策模型

### 3.1 两层交互分离

系统中的用户交互分为两个正交层次，各自独立运作：

**系统层决策**——系统在运行过程中自主产生的决策，可根据 `interaction_mode` 升级为用户确认：

| 决策点 | 所在阶段 | 自主行为（auto） | 描述 |
|--------|---------|----------------|------|
| 分类确认 | CLASSIFIED | Classifier 自动选择工作流 | 对分类结果的确认或覆盖 |
| 迭代方向 | EXECUTING 后 | IterationStrategy 自动选择回退目标 | 选择 PREPARING / CLASSIFIED / 终止 |
| 钩子失败应对 | PREPARING | HookRunner 按 on_fail 配置执行 | 选择 abort / reclassify / retry |

**工作流层交互**——工作流作者在 DSL 中通过 `ask()` 原语显式定义的用户交互，与 `interaction_mode` 无关。工作流作者完全控制交互时机、提示文本和恢复逻辑。

这种分层确保了：系统层的决策升级不侵入工作流 DSL 和中间件链的纯粹性；工作流作者的 `ask()` 和 `try/except` 提供了比系统级覆盖更灵活的步骤失败处理能力。

### 3.2 interaction_mode 三模式

每个工作流通过 `@workflow(interaction_mode=...)` 声明用户参与策略，控制所有系统层决策点的行为：

| 模式 | 含义 |
|------|------|
| `auto` | 所有系统层决策完全自主，不与用户交互（默认） |
| `adaptive` | 当系统对自主选择的置信度低于阈值时升级为用户确认 |
| `confirm` | 所有系统层决策点都升级为用户确认 |

工作流级 `interaction_mode` 优先于全局 `confirmation_mode` 配置。

### 3.3 行为矩阵

| 决策点 | auto | adaptive | confirm |
|--------|------|----------|---------|
| 分类确认 | 直接进入 PREPARING | LLM 分类且置信度 < 阈值时升级 | 始终升级 |
| 迭代方向 | 系统自主选择（PREPARING / CLASSIFIED / 终止） | 执行失败且分类置信度低时升级 | 始终升级 |
| 钩子失败 | 按 on_fail 配置执行（abort / reclassify） | 必需钩子失败时升级 | 始终升级 |

所有升级的决策超时后自动使用系统的自主选择（`auto_choice`）兜底，保证闭环不卡死。

### 3.4 双阈值分域

系统存在两类阈值，服务不同目的，分属不同配置域以避免认知混淆：

| 阈值类型 | 配置域 | 作用 | 示例 |
|---------|--------|------|------|
| 自主行为阈值 | `iteration.reclassify_threshold` | 控制系统在自主模式下"选什么" | 低于 0.5 时自动重分类 |
| 升级行为阈值 | `escalation.*.adaptive_threshold` | 控制"是否要问用户" | 低于 0.6 时升级为用户确认 |

两类阈值完全正交——一个控制 **what**（自主选择的内容），一个控制 **whether to ask**（是否升级为用户决策）。各决策点的置信度由各自的策略组件独立计算：

- 分类确认：直接使用 `ClassifyResult.confidence`
- 迭代方向：执行失败 + 分类低置信度 → 使用原分类置信度；其他 → 1.0（高置信度不升级）
- 钩子失败：必需钩子 → 0.3（强制低置信度触发升级）；可选钩子 → 1.0

---

## 4. 全链路闭环保证

系统通过 9 个闭环确保从输入到输出的完整性。每个闭环回答一个"如果 X 怎么办"的问题。

### 4.1 执行闭环

```
用户输入 → Gateway → Controller → [CLASSIFIED → PREPARING → EXECUTING] → DELIVERED/FAILED → Gateway → 用户
```

每个阶段持久化。崩溃恢复从最后阶段继续。

### 4.2 迭代闭环

系统存在**两层迭代**，各自独立运作：

**工作流内迭代（DSL 层）**——由工作流函数通过 Python 控制流（`if / while`）驱动，在单次 EXECUTING 阶段内完成。典型场景：代码审核不通过 → 修正 → 重审。

```
EXECUTING 阶段内:
  step("编写代码") → step("代码审核") → review.passed == False
    → step("修正代码") → step("代码审核") → review.passed == True → 继续
```

**工作流外迭代（Reconciler 层）**——由 `WorkflowResult.needs_iteration` 触发，IterationStrategy 决定回退到 PREPARING 或 CLASSIFIED。最多 `max_iterations` 轮（默认 3）。

```
EXECUTING 完成 → IterationStrategy.decide()
  ├─ should_escalate() == true → 升级为用户决策（用户选择：重新准备 / 重新分类 / 终止）
  ├─ needs_iteration + 显式 reclassify → 回到 CLASSIFIED（重新分类）
  ├─ needs_iteration + 失败 + 低置信度 + 未重分类过 → 回到 CLASSIFIED（自动重分类，最多一次）
  ├─ needs_iteration + 其他 → 回到 PREPARING（重新准备，跳过分类）
  └─ 否 → DELIVERED / FAILED
```

两层迭代各自独立：内层处理步骤级修正循环，外层处理工作流级重试。`envelope.reclassified` 标记确保自动重分类最多一次。

### 4.3 用户反馈闭环

```
DELIVERED → 用户不满意 → /redo <id> [feedback]
→ Controller 注入 user_feedback → 重置为 PREPARING → 重新执行
```

### 4.4 交付闭环

```
Gateway.deliver() 失败 → 自身指数退避重试（最多 3 次）
→ 全部失败 → emit delivery_exhausted → 标记 FAILED
→ Observer 记录 DLQ + 指标
```

交付重试由 Gateway 自管理，Observer 只记录最终失败指标。

### 4.5 取消闭环

```
/cancel <id> → Controller 设置 CancellationToken
→ CancellationMiddleware 在下一个 step 前检查 → raise WorkflowCancelled
→ 标记 CANCELLED → 通知用户
```

### 4.6 分类确认闭环

```
CLASSIFIED → Classifier 返回 ClassifyResult（含 confidence + source + reason）
  ├─ interaction_mode=auto → 直接进入 PREPARING
  ├─ interaction_mode=adaptive
  │    ├─ source != "llm" → 直接进入 PREPARING（规则匹配无需确认）
  │    ├─ source == "llm" && confidence >= threshold → 直接进入 PREPARING
  │    └─ source == "llm" && confidence < threshold
  │         → request_decision()：展示分类结果 + 候选工作流
  │         → 用户确认或覆盖（超时自动放行）→ PREPARING
  └─ interaction_mode=confirm
       → request_decision()：展示分类结果 + 候选工作流
       → 用户确认或覆盖（超时自动放行）→ PREPARING
```

### 4.7 执行中交互闭环

```
EXECUTING 阶段内:
  step("编写代码") → ask("确认方案", "检测到两种实现方案，请选择：...") → 用户选择
    ├─ 用户响应 → 使用用户选择继续执行
    └─ 超时（timeout_s）→ 使用 default 值继续执行

崩溃恢复:
  重新执行工作流函数 → 已完成 step 被幂等缓存跳过
    → 到达 ask() → 检查 InteractionCheckpoint
      ├─ 有已保存响应 → 直接返回（幂等）
      └─ 无已保存响应 → 重新向用户请求输入
```

`ask()` 原语通过 InteractionCheckpoint（基于 StateStore KV）持久化交互状态，复用幂等缓存的设计理念。超时自动使用 default 保证闭环不卡死。

### 4.8 任务恢复闭环

**崩溃恢复**：

```
系统重启 → Reconciler.recover() 扫描 StateStore 中所有非终态任务
  → 任务存活时间 <= TTL → 恢复到最后持久化阶段 → 继续执行
  → 任务存活时间 > TTL → 标记 FAILED + error="task_expired" → 通知用户
```

TTL = 2 × 工作流超时（默认 300s × 2 = 600s），防止误清理正常任务且避免僵尸任务。

### 4.9 预执行准备闭环

```
PREPARING 阶段 → HookRunner 执行钩子链:
  PreExecuteHook(required=true) 执行
    ├─ 成功 → 继续下一个钩子
    ├─ 失败 + should_escalate() == true
    │    → request_decision()：展示失败信息 + 选项（abort / reclassify / retry）
    │    → 按用户选择执行（超时使用 hook.on_fail 兜底）
    ├─ 失败 + TRANSIENT → 短暂等待后重试 PREPARING（最多 max_retries 次）
    ├─ 失败 + on_fail="reclassify" → 回退到 CLASSIFIED 尝试换工作流
    └─ 失败 + on_fail="abort" → 标记 FAILED
  PreExecuteHook(required=false) 执行
    ├─ 成功 → 继续
    └─ 失败 → 降级标记 → 继续 EXECUTING
```

区分必需钩子（失败则阻止执行）和可选钩子（失败则降级继续），使 PREPARING 阶段的行为可预测。

---

## 5. 组件职责概述

### 5.1 Gateway

协议适配层。将飞书消息 / REST API / CLI 输入统一为 `TaskEnvelope`，执行准入校验（认证、限流、安全拦截），按原渠道回传结果。交付重试由 Gateway 自管理（指数退避，最多 3 次），不依赖 Observer 编排。Gateway 不参与任务的业务逻辑处理。

### 5.2 Controller

K8s 风格协调循环，desired state = DELIVERED / FAILED。内部拆分为 5 个职责单一的子组件：

| 子组件 | 职责 |
|--------|------|
| **Reconciler** | 纯状态机循环驱动器——驱动任务经历各阶段到达终态，组合调用其他子组件。自身不包含分类、钩子、迭代的业务逻辑 |
| **Classifier** | 选工作流的唯一入口。采用策略链模式（L0 用户指定 → L1 命令映射 → L2 关键词 → L3 短文本 → L4 LLM → L5 兜底），返回含置信度的 `ClassifyResult` |
| **CommandHandler** | 处理即时命令（/help /status /task /tasks /cancel），不触发工作流执行 |
| **HookRunner** | PREPARING 阶段的钩子编排——执行预执行钩子链，处理失败策略（含决策升级） |
| **IterationStrategy** | EXECUTING 后的迭代方向决策——根据执行结果和置信度决定下一阶段（含决策升级） |

Classifier（Controller 层，选工作流）与 Planner（Workflow 层，分解任务）职责不同。`/run` 由 Classifier 策略链中的 `UserOverrideStrategy` 统一处理。

### 5.3 Scheduler

优先级排队（P0 > P1 > P2）+ 标签匹配（Worker.labels ⊇ step.requirements）+ 断路器只读消费 + 背压控制。Scheduler 不参与工作流级决策，只关注步骤级资源匹配。

### 5.4 Worker

纯执行单元。通过可插拔 `AgentBackend` 接口执行单个步骤，自动分类错误（TRANSIENT / PERMANENT / DEGRADABLE），维护 success_rate。资源管理（容量/信号量/状态）由 WorkerSlot 负责，注册/注销由 WorkerPool 管理。Worker 不感知工作流语义，只关注步骤执行。

### 5.5 Observer

严格旁路系统。订阅 EventBus 事件，写入断路器健康状态、持久化永久失败到 DLQ、记录指标。**不发出控制类事件，不编排任何主路径行为。** 对主路径的唯一影响通过共享状态中介模式（§1.3.1）。

### 5.6 WorkflowRuntime

Controller 在 EXECUTING 阶段的代理所有者（§1.3.2）。桥接 DSL 原语（`step` / `parallel` / `ask`）与 Scheduler / Worker，通过可配置中间件链处理每个步骤。支持级联超时模型（工作流超时 > 步骤超时 > 后端超时）。生命周期和作用范围由 Reconciler 限定在单个 EXECUTING 阶段内。

### 5.7 Infrastructure

- **StateStore**：统一状态存储（任务 CRUD + 步骤幂等 checkpoint + 通用 KV）
- **EventBus**：异步事件总线，emit 非阻塞，异常不影响主路径
- **MCPBus**：统一 MCP 工具管理
- **LLMPool**：LLM 服务池，支持多模型路由
- **KnowledgeBase**：统一知识库
