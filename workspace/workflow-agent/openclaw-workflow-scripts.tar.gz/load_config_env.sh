#!/bin/bash
# =============================================================================
# OpenClaw 配置加载脚本
# 用法: source load_config_env.sh [config_file]
# 
# 功能:
#   1. 加载 ~/.openclaw/.env 中的环境变量
#   2. 将配置文件中的 ${VAR} 占位符替换为实际值
#   3. 输出处理后的配置文件供 OpenClaw 使用
#
# 使用方式:
#   # 在运行 openclaw 前先 source 此脚本:
#   source load_config_env.sh
#   openclaw gateway start
#
#   # 或者直接加载配置到环境变量:
#   source load_config_env.sh --env-only
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
CONFIG_FILE="${1:-}"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查 .env 文件是否存在
if [ ! -f "$ENV_FILE" ]; then
    echo_warn "未找到 .env 文件: $ENV_FILE"
    echo_info "请复制 .env.template 为 .env 并填入实际值"
    exit 0
fi

echo_info "加载环境变量 from: $ENV_FILE"

# 加载 .env 文件中的环境变量
set -a  # 自动导出所有变量
source "$ENV_FILE"
set +a

# 定义需要的环境变量列表
REQUIRED_VARS=(
    "DASHSCOPE_API_KEY"
    "FEISHU_APP_SECRET"
    "MINIMAX_API_KEY"
    "OPENCLAW_GATEWAY_TOKEN"
)

# 检查必要的环境变量
MISSING_VARS=()
for var in "${REQUIRED_VARS[@]}"; do
    if [ -z "${!var}" ]; then
        MISSING_VARS+=("$var")
    fi
done

if [ ${#MISSING_VARS[@]} -gt 0 ]; then
    echo_warn "以下环境变量未设置:"
    for var in "${MISSING_VARS[@]}"; do
        echo "  - $var"
    done
fi

echo_info "环境变量加载完成"

# 如果指定了配置文件，进行占位符替换
if [ -n "$CONFIG_FILE" ] && [ -f "$CONFIG_FILE" ]; then
    echo_info "处理配置文件: $CONFIG_FILE"
    
    # 创建临时文件
    TEMP_FILE=$(mktemp)
    
    # 替换 ${VAR} 格式的占位符
    cat "$CONFIG_FILE" | while IFS= read -r line; do
        for var in "${REQUIRED_VARS[@]}"; do
            if [ -n "${!var}" ]; then
                line="${line//\$\{${var}\}/${!var}}"
            fi
        done
        echo "$line"
    done > "$TEMP_FILE"
    
    # 复制回原文件
    cp "$TEMP_FILE" "$CONFIG_FILE"
    rm "$TEMP_FILE"
    
    echo_info "配置文件已更新: $CONFIG_FILE"
fi

# 如果是 --env-only 模式，只加载环境变量
if [ "$1" = "--env-only" ]; then
    echo_info "环境变量已加载，现在可以运行 openclaw 命令"
fi

# 导出函数供后续使用
export -f echo_info
export -f echo_warn
export -f echo_error
