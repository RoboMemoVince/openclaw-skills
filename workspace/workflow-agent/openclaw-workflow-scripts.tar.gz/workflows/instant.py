"""
Built-in instant workflow.
"""

from modules.dsl.primitives import step
from modules.dsl.registry import workflow


@workflow("instant", timeout=30, middlewares=["cancellation", "event", "retry"])
async def instant_workflow(ctx):
    """
    @description 纯对话/简单问答工作流。
    """

    result = await step("直接应答", ctx.task, agent="instant", max_retries=1)
    return result.output
