"""
Built-in translation workflow.
"""

from modules.dsl.primitives import step
from modules.dsl.registry import workflow


@workflow("translation", timeout=180)
async def translation_workflow(ctx):
    """
    @description 翻译任务：理解 -> 翻译 -> 校对。
    """

    understood = await step("理解原文", f"请理解以下文本的语义和语气：\n\n{ctx.task}")
    translated = await step("翻译", understood.output or ctx.task)
    review = await step(
        "校对",
        (
            "请校对以下翻译。"
            "第一行只返回 PASS 或 FAIL，后续给出具体修改建议。\n\n"
            f"{translated.output}"
        ),
        agent="reviewer",
    )
    return review.output if review.output else translated.output
