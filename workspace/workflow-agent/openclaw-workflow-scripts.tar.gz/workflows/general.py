"""
Built-in general workflow.
"""

from modules.dsl.primitives import step
from modules.dsl.registry import workflow


@workflow("general", timeout=300)
async def general_workflow(ctx):
    """
    @description 通用任务：规划 -> 执行 -> 审核。
    """

    plan = await step("任务规划", f"请拆解并规划以下任务：\n\n{ctx.task}")
    result = await step("执行任务", plan.output or ctx.task)
    review = await step(
        "结果审核",
        (
            "请审核以下结果是否满足任务要求。"
            "第一行只返回 PASS 或 FAIL，后续给出简短理由。\n\n"
            f"原始任务：{ctx.task}\n\n结果：{result.output}"
        ),
        agent="reviewer",
    )
    return review.output if review.output else result.output
