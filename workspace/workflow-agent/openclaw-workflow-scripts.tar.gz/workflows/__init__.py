"""
Built-in workflow registrations.
"""

from workflows.instant import instant_workflow  # noqa: F401
from workflows.general import general_workflow  # noqa: F401
from workflows.coding import coding_workflow  # noqa: F401
from workflows.research import research_workflow  # noqa: F401
from workflows.translation import translation_workflow  # noqa: F401
from workflows.database import database_workflow  # noqa: F401
