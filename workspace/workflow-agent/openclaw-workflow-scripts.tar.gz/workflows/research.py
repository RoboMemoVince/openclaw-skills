"""
Built-in research workflow.
"""

from modules.dsl.primitives import parallel, step
from modules.dsl.registry import workflow


def _extract_queries(text: str) -> list[str]:
    """
    @description 将查询提取结果拆成多个子查询。
    @param {str} text
    @returns {list[str]}
    """

    queries = []
    for line in text.splitlines():
        normalized = line.strip(" -0123456789.")
        if normalized:
            queries.append(normalized)
    return queries[:5]


@workflow("research", timeout=300)
async def research_workflow(ctx):
    """
    @description 调研任务：提取查询 -> 并行搜索 -> 综合分析。
    """

    queries = await step(
        "提取查询",
        (
            "请把以下调研任务拆成 3 到 5 个搜索查询，每行一个，不要输出额外说明。\n\n"
            f"{ctx.task}"
        ),
    )
    query_items = _extract_queries(queries.output) or [ctx.task]
    results = await parallel(
        [
            {
                "name": f"搜索-{index + 1}",
                "prompt": query,
                "mcp": ["search"],
                "timeout": 120,
            }
            for index, query in enumerate(query_items)
        ]
    )
    synthesis = await step(
        "综合分析",
        "\n\n".join(result.output for result in results if result.success),
    )
    review = await step(
        "审核结论",
        (
            "请审核以下调研结论是否回答了原问题。"
            "第一行只返回 PASS 或 FAIL，后续给出缺漏说明。\n\n"
            f"原问题：{ctx.task}\n\n结论：{synthesis.output}"
        ),
        agent="reviewer",
    )
    return review.output if review.output else synthesis.output
