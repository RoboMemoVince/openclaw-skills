"""
Built-in database workflow.
"""

from modules.dsl.primitives import step
from modules.dsl.registry import workflow


@workflow("database", timeout=180)
async def database_workflow(ctx):
    """
    @description 数据库任务：分析 -> SQL -> 审核 -> 执行。
    """

    spec = await step("分析需求", f"请分析以下数据库需求并整理查询目标：\n\n{ctx.task}")
    sql = await step("编写 SQL", spec.output or ctx.task, mcp=["database"])
    review = await step(
        "审核 SQL",
        (
            "请审核以下 SQL 是否安全、正确、满足需求。"
            "第一行只返回 PASS 或 FAIL，后续给出理由。\n\n"
            f"{sql.output}"
        ),
        agent="reviewer",
    )
    if not review.passed:
        sql = await step(
            "修正 SQL",
            sql.output,
            mcp=["database"],
            prompt_extra=f"审核反馈：{review.feedback}",
        )
    result = await step("执行查询", sql.output, mcp=["database"], on_fail="skip")
    return result.output or sql.output
