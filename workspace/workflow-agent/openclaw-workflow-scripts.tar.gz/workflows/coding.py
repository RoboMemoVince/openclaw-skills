"""
Built-in coding workflow.
"""

from modules.data_types import WorkflowResult
from modules.dsl.primitives import step
from modules.dsl.registry import workflow


@workflow("coding", timeout=600, interaction_mode="adaptive")
async def coding_workflow(ctx):
    """
    @description 编程任务：分析 -> 编码 -> 审核 -> 修正 -> 测试。
    """

    reqs = await step("需求分析", f"请分析以下编程需求并给出实现计划：\n\n{ctx.task}")
    code = await step("编写代码", reqs.output or ctx.task, mcp=["file", "bash"])
    review = await step(
        "代码审核",
        (
            "请审核以下代码或实现结果。"
            "第一行只返回 PASS 或 FAIL，后续给出关键问题和建议。\n\n"
            f"{code.output}"
        ),
        agent="reviewer",
        timeout=180,
    )
    if not review.passed:
        code = await step(
            "修正代码",
            code.output or ctx.task,
            mcp=["file", "bash"],
            prompt_extra=f"审核反馈：{review.feedback}",
        )
    test = await step(
        "运行测试",
        (
            "请在当前工作区运行必要测试或验证步骤。"
            "如果无法运行，请说明原因和建议的手工验证方式。\n\n"
            f"{code.output}"
        ),
        mcp=["bash"],
        on_fail="skip",
    )
    if not test.success and test.error:
        return WorkflowResult(
            success=False,
            output=code.output,
            error=test.error,
            needs_iteration=True,
            iteration_reason="测试或验证失败，需要重新准备后再执行",
        )
    return test.output or code.output
