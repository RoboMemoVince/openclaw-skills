#!/usr/bin/env python3
"""
OpenClaw workflow executor.

This entry point talks only to the new workflow bridge and DSL registry.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time

from openclaw_task_bridge import OpenClawTaskBridge


def _format_text_result(task: str, workflow: str | None, duration: float, result: dict) -> str:
    """
    @description 将执行结果格式化为文本输出。
    @param {str} task
    @param {str | None} workflow
    @param {float} duration
    @param {dict} result
    @returns {str}
    """

    lines = [
        "=" * 60,
        f"任务: {task}",
        f"工作流: {workflow or 'auto'}",
        f"成功: {result.get('success', False)}",
        f"耗时: {duration:.2f}s",
    ]
    if result.get("error"):
        lines.append(f"错误: {result['error']}")
    if result.get("output"):
        lines.append("")
        lines.append("输出:")
        lines.append(str(result["output"]))
    steps = result.get("steps", [])
    if steps:
        lines.append("")
        lines.append("步骤:")
        for step in steps:
            lines.append(
                f"- {step.get('name', '')} | success={step.get('success', False)} | error={step.get('error', '')}"
            )
    lines.append("=" * 60)
    return "\n".join(lines)


async def _execute_task(task: str, workflow: str | None, workspace: str, timeout: int) -> tuple[float, dict]:
    """
    @description 通过新工作流桥接执行任务。
    @param {str} task
    @param {str | None} workflow
    @param {str} workspace
    @param {int} timeout
    @returns {tuple[float, dict]}
    """

    bridge = OpenClawTaskBridge(workspace=workspace)
    started_at = time.time()
    if workflow:
        result = await bridge.execute_workflow(
            task=task,
            workflow_id=workflow,
            user_id="cli",
            workspace=workspace,
        )
    else:
        result = await bridge.execute_task(
            task=task,
            user_id="cli",
            workspace=workspace,
            timeout=timeout,
        )
    return time.time() - started_at, result


def _print_workflows() -> None:
    """
    @description 打印内置工作流列表。
    @returns {None}
    """

    import workflows  # noqa: F401
    from modules.dsl.registry import WorkflowRegistry

    registry = WorkflowRegistry()
    print("\n可用工作流:")
    print("-" * 60)
    for workflow_name in registry.list_all():
        print(f"  - {workflow_name}")
    print(f"\n共 {len(registry.list_all())} 个工作流")


async def main() -> int:
    """
    @description CLI 主入口。
    @returns {int}
    """

    parser = argparse.ArgumentParser(description="OpenClaw 工作流执行器")
    parser.add_argument("task", nargs="?", help="任务描述")
    parser.add_argument("-t", "--task", dest="task_arg", help="任务描述（另一种写法）")
    parser.add_argument("-w", "--workspace", default=os.getcwd(), help="工作目录")
    parser.add_argument("-o", "--output", choices=["json", "text"], default="text", help="输出模式")
    parser.add_argument("--no-notify", action="store_true", help="兼容参数，当前已无独立通知脚本依赖")
    parser.add_argument("--timeout", type=int, default=600, help="超时时间秒")
    parser.add_argument("--workflow", "-wf", help="显式指定工作流")
    parser.add_argument("--list-workflows", action="store_true", help="列出所有工作流")
    args = parser.parse_args()

    del args.no_notify

    if args.list_workflows:
        _print_workflows()
        return 0

    task = args.task or args.task_arg
    if not task:
        parser.print_help()
        return 0

    duration, result = await _execute_task(
        task=task,
        workflow=args.workflow,
        workspace=args.workspace,
        timeout=args.timeout,
    )

    if args.output == "json":
        print(json.dumps({"duration": duration, "result": result}, ensure_ascii=False, indent=2))
    else:
        print(_format_text_result(task, args.workflow, duration, result))
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
