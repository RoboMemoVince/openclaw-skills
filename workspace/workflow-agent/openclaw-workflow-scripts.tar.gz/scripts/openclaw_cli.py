#!/usr/bin/env python3
"""
OpenClaw 统一CLI入口
仅暴露新工作流架构相关能力
"""

from __future__ import annotations

import sys
import argparse
import asyncio
import json
from pathlib import Path


def cmd_workflow(args):
    """工作流命令"""
    from openclaw_task_bridge import OpenClawTaskBridge
    import workflows  # noqa: F401
    from modules.controller.classifier import Classifier
    from modules.core_types import TaskEnvelope
    from modules.dsl.registry import WorkflowRegistry

    workflow_registry = WorkflowRegistry()
    
    if args.subcommand == "list":
        print(f"\n{'='*60}")
        print("可用工作流模板")
        print(f"{'='*60}\n")

        for workflow_name in workflow_registry.list_all():
            print(f"  {workflow_name}")
    
    elif args.subcommand == "run":
        bridge = OpenClawTaskBridge(workspace=str(Path.cwd()))
        if args.template:
            result = asyncio.run(
                bridge.execute_workflow(
                    task=args.task,
                    workflow_id=args.template,
                    user_id="cli",
                    workspace=str(Path.cwd()),
                )
            )
            workflow_name = args.template
        else:
            result = asyncio.run(
                bridge.execute_task(
                    task=args.task,
                    user_id="cli",
                    workspace=str(Path.cwd()),
                )
            )
            workflow_name = "auto"

        print(f"执行: {workflow_name}")
        print(f"任务: {args.task}")
        print(f"成功: {result.get('success', False)}")
        print(f"结果: {result.get('output', '')}")
        print(f"错误: {result.get('error', '')}")
    
    elif args.subcommand == "match":
        classifier = Classifier(llm_service=None, workflow_registry=workflow_registry)
        envelope = TaskEnvelope(task_id="cli_match", content=args.task)
        result = asyncio.run(classifier.classify(envelope))
        print(f"任务: {args.task}")
        print(f"匹配: {result.workflow_name}")
        print(f"来源: {result.source}")
        print(f"理由: {result.reason}")


def cmd_task(args):
    """任务命令"""
    from openclaw_task_bridge import OpenClawTaskBridge

    bridge = OpenClawTaskBridge(workspace=str(Path.cwd()))
    
    if args.subcommand == "run":
        result = asyncio.run(
            bridge.execute_task(
                task=args.task,
                user_id="cli",
                workspace=str(Path.cwd()),
            )
        )
        print(f"成功: {result.get('success', False)}")
        print(f"结果: {result.get('output', '')}")
        print(f"错误: {result.get('error', '')}")
    
    elif args.subcommand == "status":
        result = asyncio.run(
            bridge.execute_task(
                task="/tasks",
                user_id="cli",
                workspace=str(Path.cwd()),
            )
        )
        print(result.get("output", ""))


def cmd_mcp(args):
    """MCP命令"""
    from modules.registry import ModuleRegistry

    async def _list_groups():
        registry = ModuleRegistry()
        await registry.boot()
        mcp_service = registry.get("mcp_service")
        groups = mcp_service.get_all_groups() if mcp_service else []
        print(f"\nMCP Groups ({len(groups)}):")
        for group in groups:
            healthy = await mcp_service.health_check(group) if mcp_service else False
            print(f"  - {group}: {'healthy' if healthy else 'unhealthy'}")

    if args.subcommand == "list":
        asyncio.run(_list_groups())
    elif args.subcommand == "request":
        print("当前新架构不再维护独立的 MCP request 队列。")
        print("请直接通过 workflow/task 命令触发任务，由 mcp_service 自动解析和加载分组。")


def cmd_status(args):
    """系统状态命令"""
    from openclaw_task_bridge import OpenClawTaskBridge

    bridge = OpenClawTaskBridge(workspace=str(Path.cwd()))
    result = asyncio.run(
        bridge.execute_task(
            task="/status",
            user_id="cli",
            workspace=str(Path.cwd()),
        )
    )
    print(result.get("output", ""))


def cmd_config(args):
    """配置命令"""
    config_dir = Path("/home/lkx/.openclaw/config")
    
    if args.subcommand == "list":
        print(f"\n配置文件:")
        for f in config_dir.rglob("*.yaml"):
            print(f"  - {f.relative_to(config_dir)}")
        for f in config_dir.rglob("*.json"):
            print(f"  - {f.relative_to(config_dir)}")
    
    elif args.subcommand == "show":
        config_file = config_dir / args.file
        if config_file.exists():
            text = config_file.read_text(encoding="utf-8")
            if config_file.suffix == ".json":
                print(json.dumps(json.loads(text), ensure_ascii=False, indent=2))
            else:
                print(text)
        else:
            print(f"配置文件不存在: {config_file}")


def main():
    parser = argparse.ArgumentParser(
        description="OpenClaw 统一CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # workflow 命令
    wf_parser = subparsers.add_parser("workflow", help="工作流管理")
    wf_sub = wf_parser.add_subparsers(dest="subcommand")
    wf_sub.add_parser("list", help="列出模板")
    wf_sub.add_parser("match", help="测试匹配").add_argument("task", help="任务")
    wf_run = wf_sub.add_parser("run", help="运行工作流")
    wf_run.add_argument("task", help="任务描述")
    wf_run.add_argument("-t", "--template", help="指定模板")
    wf_run.add_argument("--task-id", help="任务ID")
    
    # task 命令
    task_parser = subparsers.add_parser("task", help="任务管理")
    task_sub = task_parser.add_subparsers(dest="subcommand")
    task_run = task_sub.add_parser("run", help="运行任务")
    task_run.add_argument("task", help="任务描述")
    task_sub.add_parser("status", help="查看状态")
    
    # mcp 命令
    mcp_parser = subparsers.add_parser("mcp", help="MCP管理")
    mcp_sub = mcp_parser.add_subparsers(dest="subcommand")
    mcp_sub.add_parser("list", help="列出MCP")
    mcp_req = mcp_sub.add_parser("request", help="MCP请求")
    mcp_req.add_argument("-l", "--list", action="store_true", help="列出请求")
    
    # config 命令
    cfg_parser = subparsers.add_parser("config", help="配置管理")
    cfg_sub = cfg_parser.add_subparsers(dest="subcommand")
    cfg_sub.add_parser("list", help="列出配置")
    cfg_show = cfg_sub.add_parser("show", help="显示配置")
    cfg_show.add_argument("file", help="配置文件")
    
    # status 命令
    subparsers.add_parser("status", help="系统状态")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        print("\n示例:")
        print("  openclaw workflow list")
        print("  openclaw workflow run '搜索AI新闻'")
        print("  openclaw task run '分析数据'")
        print("  openclaw status")
        return
    
    # 执行命令
    try:
        if args.command == "workflow":
            cmd_workflow(args)
        elif args.command == "task":
            cmd_task(args)
        elif args.command == "mcp":
            cmd_mcp(args)
        elif args.command == "config":
            cmd_config(args)
        elif args.command == "status":
            cmd_status(args)
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
