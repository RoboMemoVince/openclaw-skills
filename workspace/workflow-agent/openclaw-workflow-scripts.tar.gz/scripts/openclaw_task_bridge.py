#!/usr/bin/env python3
"""
OpenClaw 任务桥接器 (v2 -- 薄代理)
保留 OpenClawTaskBridge 的公开 API (execute_task / execute_workflow)，
内部委托给模块化 Orchestrator。

向后兼容: feishu_bot_server.py 和 mini-agent-mcp/server.py 的调用方无需修改。
"""

import asyncio
import os
import sys
from typing import Dict, Any, Optional

# 确保 modules/ 和 services/ 可被导入
_OPENCLAW_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _OPENCLAW_ROOT not in sys.path:
    sys.path.insert(0, _OPENCLAW_ROOT)

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

_orchestrator_instance = None
_boot_lock = asyncio.Lock() if hasattr(asyncio, "Lock") else None


async def _get_orchestrator():
    """Lazily boot the modular orchestrator (singleton)."""
    global _orchestrator_instance
    if _orchestrator_instance is not None:
        return _orchestrator_instance

    lock = _boot_lock or asyncio.Lock()
    async with lock:
        if _orchestrator_instance is not None:
            return _orchestrator_instance
        try:
            from modules.orchestrator import create_orchestrator
            _orchestrator_instance = await create_orchestrator()
        except Exception as e:
            print(f"[bridge] failed to boot orchestrator: {e}")
            _orchestrator_instance = None
    return _orchestrator_instance


class OpenClawTaskBridge:
    """
    Thin proxy -- delegates to the workflow Gateway -> Controller chain.
    Keeps the same constructor and method signatures as v1.
    """

    def __init__(self, workspace: str = "/home/lkx"):
        self.workspace = workspace

    async def execute_task(
        self,
        task: str,
        user_id: str = "",
        workspace: str = None,
        timeout: int = 600,
    ) -> Dict[str, Any]:
        """
        @param {str} task - 任务描述
        @param {str} user_id - 飞书用户 ID
        @param {str} workspace - 工作目录
        @param {int} timeout - 超时秒数
        @returns {dict} 包含 success, output, error, duration 等字段
        """
        orch = await _get_orchestrator()
        if not orch:
            return {"success": False, "output": "", "error": "orchestrator unavailable", "duration": 0}

        return await orch.handle({
            "content": task,
            "user_id": user_id,
            "workspace": workspace or self.workspace,
            "timeout": timeout,
            "source": "bridge",
        })

    async def execute_workflow(
        self,
        task: str,
        workflow_id: str = None,
        user_id: str = "",
        workspace: str = None,
    ) -> Dict[str, Any]:
        """
        @param {str} task - 任务描述
        @param {str} workflow_id - 工作流 ID，内部通过 `/run` 显式指定
        @param {str} user_id - 飞书用户 ID
        @param {str} workspace - 工作目录
        @returns {dict}
        """
        if workflow_id:
            task = f"/run {workflow_id} {task}"
        return await self.execute_task(
            task=task, user_id=user_id,
            workspace=workspace or self.workspace,
        )

    def get_available_mcp(self):
        """Compatibility stub."""
        return []


async def main():
    """Quick smoke test."""
    bridge = OpenClawTaskBridge()
    result = await bridge.execute_task(
        task="/help",
        user_id="test",
        timeout=30,
    )
    print(result.get("output", result))


if __name__ == "__main__":
    asyncio.run(main())
