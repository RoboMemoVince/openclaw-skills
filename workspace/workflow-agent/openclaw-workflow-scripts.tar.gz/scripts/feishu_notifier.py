#!/usr/bin/env python3
"""
Feishu notifier wrapper backed by the shared feishu service implementation.
"""

from services.feishu_service.notifier import FeishuNotifierService as FeishuNotifier


def main():
    """测试通知器"""
    import os
    import sys
    
    notifier = FeishuNotifier(
        app_id=os.getenv("FEISHU_APP_ID", "cli_a928f897c2b89cca"),
        app_secret=os.getenv("FEISHU_APP_SECRET", "tri2ADJx8UWuQSh81YqiAeEi42H2rXHv"),
    )
    
    # 测试发送消息
    # notifier.send_task_start(
    #     receive_id="ou_xxxxx",
    #     task_name="测试任务",
    #     task_target="这是一个测试任务的目标"
    # )
    
    print("FeishuNotifier initialized")


if __name__ == "__main__":
    main()
