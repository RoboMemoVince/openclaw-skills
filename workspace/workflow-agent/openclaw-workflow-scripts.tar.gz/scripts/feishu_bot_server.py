#!/usr/bin/env python3
"""
飞书机器人主服务器
负责：接收飞书消息 -> 转发给 OpenClaw -> 接收结果 -> 通知用户

支持功能：
1. WebSocket 长连接接收消息
2. HTTP 回调接收消息
3. 自动任务处理和通知
"""

import json
import sys
import os
import asyncio
import threading
from datetime import datetime
from typing import Optional, Dict, Any
import argparse

# 添加脚本目录到路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OPENCLAW_ROOT = os.path.dirname(SCRIPT_DIR)
sys.path.insert(0, SCRIPT_DIR)

_ENV_FILE = os.path.join(OPENCLAW_ROOT, ".env")
if os.path.isfile(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _line = _line.removeprefix("export ")
                _key, _, _val = _line.partition("=")
                os.environ.setdefault(_key.strip(), _val.strip().strip('"'))

# 导入相关模块
from feishu_message_receiver import FeishuMessageReceiver
from openclaw_task_bridge import OpenClawTaskBridge
from feishu_notifier import FeishuNotifier


class FeishuBotServer:
    """飞书机器人主服务器"""
    
    def __init__(self, config_path: str = None):
        # 飞书配置
        self.app_id = os.getenv("FEISHU_APP_ID", "cli_a928f897c2b89cca")
        self.app_secret = os.getenv("FEISHU_APP_SECRET", "tri2ADJx8UWuQSh81YqiAeEi42H2rXHv")
        
        # 初始化组件
        self.message_receiver = FeishuMessageReceiver(self.app_id, self.app_secret)
        self.task_bridge = OpenClawTaskBridge()
        self.notifier = FeishuNotifier(self.app_id, self.app_secret)
        
        # 任务存储 (message_id -> task_info)
        self.tasks: Dict[str, Dict[str, Any]] = {}
        
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        
    def handle_incoming_message(self, event: dict) -> dict:
        """
        处理接收到的飞书消息事件
        这是整个链路的入口点
        """
        try:
            # 1. 解析消息
            message_info = self.message_receiver.parse_message_event(event)
            if not message_info:
                return {"success": False, "error": "Failed to parse message"}
            
            message_id = message_info["message_id"]
            user_id = message_info["user_id"]
            user_name = message_info.get("user_name", "未知用户")
            content = message_info["content"]
            chat_id = message_info.get("chat_id", "")
            
            print(f"\n{'='*60}")
            print(f"📥 收到新消息")
            print(f"{'='*60}")
            print(f"消息ID: {message_id}")
            print(f"用户: {user_name} ({user_id})")
            print(f"内容: {content[:200]}...")
            print(f"会话: {chat_id}")
            print(f"{'='*60}\n")
            
            # 2. 存储任务信息
            task_info = {
                "message_id": message_id,
                "user_id": user_id,
                "user_name": user_name,
                "content": content,
                "chat_id": chat_id,
                "status": "pending",
                "created_at": datetime.now().isoformat()
            }
            self.tasks[message_id] = task_info
            
            # 3. 发送"正在处理"通知
            print("📤 发送'正在处理'通知...")
            start_notification = self.notifier.send_task_start(
                receive_id=user_id,
                task_name=content[:100],
                task_target=self._extract_task_target(content),
                receive_id_type="open_id"
            )
            
            # 4. 异步执行任务（不阻塞飞书连接）
            if self._loop and self._loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    self._execute_task_async(message_id, task_info),
                    self._loop,
                )
            else:
                threading.Thread(
                    target=asyncio.run,
                    args=(self._execute_task_async(message_id, task_info),),
                    daemon=True,
                ).start()
            
            return {"success": True, "message_id": message_id}
            
        except Exception as e:
            print(f"❌ 处理消息失败: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return {"success": False, "error": str(e)}
    
    def _extract_task_target(self, content: str) -> str:
        """从任务内容中提取目标"""
        # 简单的目标提取逻辑
        if len(content) > 150:
            return content[:150] + "..."
        return content
    
    async def _execute_task_async(self, message_id: str, task_info: dict):
        """异步执行任务"""
        try:
            # 更新状态
            task_info["status"] = "executing"
            task_info["started_at"] = datetime.now().isoformat()
            
            print(f"\n🤖 开始执行任务: {message_id}")
            
            result = await self.task_bridge.execute_task(
                task=task_info["content"],
                user_id=task_info["user_id"],
                workspace="/home/lkx",
                timeout=600,
            )
            
            # 更新状态
            task_info["status"] = "completed" if result.get("success") else "failed"
            task_info["completed_at"] = datetime.now().isoformat()
            task_info["result"] = result
            
            # 计算耗时
            started = datetime.fromisoformat(task_info["started_at"])
            duration = int((datetime.now() - started).total_seconds())
            
            # 发送完成通知
            print(f"\n📤 发送任务完成通知...")
            
            formatted_result = self._format_task_result(result)
            
            self.notifier.send_task_complete(
                receive_id=task_info["user_id"],
                task_name=task_info["content"][:100],
                result=formatted_result,
                status="success" if result.get("success") else "error",
                duration=duration,
                receive_id_type="open_id"
            )
            
            print(f"\n✅ 任务完成! 耗时: {duration}秒")
            
        except Exception as e:
            print(f"❌ 任务执行失败: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            
            task_info["status"] = "failed"
            task_info["error"] = str(e)
            
            # 发送错误通知
            self.notifier.send_task_complete(
                receive_id=task_info["user_id"],
                task_name=task_info["content"][:100],
                result=f"任务执行失败: {str(e)}",
                status="error",
                duration=0,
                receive_id_type="open_id"
            )
    
    def _format_task_result(self, result: dict) -> str:
        """格式化任务结果"""
        if result.get("success"):
            output = result.get("output", "")
            # 截取有用的部分
            lines = output.split("\n")
            useful_lines = []
            capture = False
            
            for line in lines:
                if "✅" in line or "完成" in line or "结果" in line:
                    capture = True
                if capture:
                    useful_lines.append(line)
            
            if useful_lines:
                return "\n".join(useful_lines[-30:])
            return output[:500] if output else "任务执行完成"
        else:
            error = result.get("error", "未知错误")
            return f"❌ 执行失败: {error}"
    
    def start_websocket(self):
        """启动 WebSocket 长连接"""
        print("🚀 启动飞书机器人 WebSocket 长连接...")

        self._loop = asyncio.new_event_loop()
        loop_thread = threading.Thread(
            target=self._loop.run_forever, daemon=True
        )
        loop_thread.start()

        self.message_receiver.set_message_handler(self.handle_incoming_message)
        self.message_receiver.start_websocket()
    
    def start_http_server(self, port: int = 8000):
        """启动 HTTP 服务器（可选）"""
        print(f"🚀 启动飞书机器人 HTTP 服务器 (端口: {port})...")
        # 这里可以添加 HTTP 服务器实现
        # 使用 Flask 或内置 http.server
        pass


def main():
    parser = argparse.ArgumentParser(description="飞书机器人主服务器")
    parser.add_argument("--mode", choices=["ws", "http", "both"], default="ws",
                        help="启动模式: ws(WebSocket), http(HTTP), both(两者)")
    parser.add_argument("--port", type=int, default=8000, help="HTTP 端口")
    parser.add_argument("--config", help="配置文件路径")
    
    args = parser.parse_args()
    
    # 创建服务器
    server = FeishuBotServer(args.config)
    
    # 启动服务
    if args.mode in ["ws", "both"]:
        try:
            server.start_websocket()
        except KeyboardInterrupt:
            print("\n\n🛑 服务已停止")
        except Exception as e:
            print(f"❌ 服务启动失败: {e}")
            sys.exit(1)
    
    if args.mode in ["http", "both"]:
        server.start_http_server(args.port)


if __name__ == "__main__":
    main()
