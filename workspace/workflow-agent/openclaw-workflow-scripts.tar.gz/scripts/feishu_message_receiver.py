#!/usr/bin/env python3
"""
Feishu message receiver wrapper backed by the shared feishu service client.
"""

import json
from typing import Optional, Dict, Any, Callable

from services.feishu_service.client import FeishuClient


class FeishuMessageReceiver:
    """飞书消息接收器"""

    def __init__(self, app_id: str, app_secret: str):
        self._client = FeishuClient(app_id=app_id, app_secret=app_secret)
        self.message_handler: Optional[Callable] = None

    def get_tenant_access_token(self) -> Optional[str]:
        return self._client.get_tenant_access_token()

    def get_message_content(self, message_id: str) -> Optional[str]:
        return self._client.get_message_content(message_id)

    def _parse_post_message(self, body: dict) -> str:
        """解析富文本消息，支持 zh_cn / en_us 等多语言 fallback"""
        try:
            content = body.get("content", {})
            if isinstance(content, str):
                content = json.loads(content)

            lang_data = None
            for lang in ("zh_cn", "en_us", "ja_jp"):
                if lang in content:
                    lang_data = content[lang]
                    break
            if not lang_data and content:
                lang_data = next(iter(content.values()), {})
            if not lang_data:
                return str(body)

            text_parts = []
            for paragraph in lang_data.get("content", []):
                if isinstance(paragraph, list):
                    for item in paragraph:
                        if isinstance(item, dict):
                            if item.get("tag") == "text":
                                text_parts.append(item.get("text", ""))
                            elif item.get("tag") == "at":
                                text_parts.append(f"@{item.get('user_id', '')}")
                elif isinstance(paragraph, dict):
                    if paragraph.get("tag") == "text":
                        text_parts.append(paragraph.get("text", ""))
                    elif paragraph.get("tag") == "at":
                        text_parts.append(f"@{paragraph.get('user_id', '')}")

            return "".join(text_parts)
        except Exception:
            return str(body)

    def get_user_info(self, user_id: str) -> Optional[Dict[str, str]]:
        return self._client.get_user_info(user_id)
    
    def parse_message_event(self, event: dict) -> Optional[Dict[str, Any]]:
        """
        解析飞书消息事件
        
        返回格式:
        {
            "message_id": "xxx",
            "user_id": "xxx",
            "user_name": "xxx",
            "content": "xxx",
            "msg_type": "text",
            "chat_id": "xxx"
        }
        """
        try:
            # 处理不同的事件类型
            if "type" in event and event["type"] == "im.message":
                # 回调事件
                message_event = event.get("event", {})
            else:
                # 直接传入的消息对象
                message_event = event
            
            # 获取基本信息
            message = message_event.get("message", {})
            sender = message_event.get("sender", {})
            
            message_id = message.get("message_id", "")
            msg_type = message.get("msg_type", "text")
            chat_id = message.get("chat_id", "")
            
            # 获取发送者信息
            sender_id = sender.get("sender_id", {})
            user_id = sender_id.get("open_id", "")
            
            # 获取用户名
            user_info = self.get_user_info(user_id)
            user_name = user_info.get("name", "未知用户") if user_info else "未知用户"
            
            # 获取消息内容
            if msg_type == "text":
                content = message.get("content", "")
                # 解析 text 消息内容
                try:
                    content_obj = json.loads(content)
                    content = content_obj.get("text", content)
                except:
                    pass
            else:
                content = message.get("content", "")
            
            return {
                "message_id": message_id,
                "user_id": user_id,
                "user_name": user_name,
                "content": content,
                "msg_type": msg_type,
                "chat_id": chat_id
            }
            
        except Exception as e:
            print(f"Error parsing message event: {e}", file=__import__('sys').stderr)
            return None
    
    def set_message_handler(self, handler: Callable):
        """设置消息处理回调"""
        self.message_handler = handler
    
    def start_websocket(self):
        """启动 WebSocket 长连接"""
        try:
            import lark_oapi as lark
            from lark_oapi.api.im.v1 import P2ImMessageReceiveV1
            
            # 创建事件处理器
            def handle_message(event: P2ImMessageReceiveV1):
                if self.message_handler:
                    # 转换为字典格式
                    event_dict = {
                        "type": "im.message",
                        "event": {
                            "message": {
                                "message_id": event.event.message.message_id,
                                "msg_type": event.event.message.msg_type,
                                "content": event.event.message.content,
                                "chat_id": event.event.message.chat_id
                            },
                            "sender": {
                                "sender_id": {
                                    "open_id": event.event.sender.sender_id.open_id if event.event.sender.sender_id else None
                                }
                            }
                        }
                    }
                    self.message_handler(event_dict)
            
            # 构建事件调度器
            event_dispatcher = lark.EventDispatcherHandler.builder("", "") \
                .register_p2_im_message_receive_v1(handle_message).build()
            
            # 创建 WebSocket 客户端
            ws_client = lark.ws.Client(
                app_id=self.app_id,
                app_secret=self.app_secret,
                event_handler=event_dispatcher,
                log_level=lark.LogLevel.INFO
            )
            
            print("✅ 飞书 WebSocket 连接已建立")
            print("📡 等待接收消息...")
            
            # 启动长连接
            ws_client.start()
            
        except ImportError:
            print("Error: lark-oapi not installed. Installing...", file=__import__('sys').stderr)
            __import__('subprocess').run(["pip", "install", "lark-oapi", "-U"], check=True)
            print("Please restart the server.", file=__import__('sys').stderr)
        except KeyboardInterrupt:
            print("\n🛑 WebSocket 连接已关闭")
        except Exception as e:
            print(f"WebSocket error: {e}", file=__import__('sys').stderr)
            raise


def main():
    """测试消息接收器"""
    import os
    import sys
    
    receiver = FeishuMessageReceiver(
        app_id=os.getenv("FEISHU_APP_ID", "cli_a928f897c2b89cca"),
        app_secret=os.getenv("FEISHU_APP_SECRET", "tri2ADJx8UWuQSh81YqiAeEi42H2rXHv"),
    )
    
    # 测试 token 获取
    token = receiver.get_tenant_access_token()
    print(f"Token: {token[:20]}..." if token else "Failed to get token")
    
    # 测试用户信息
    user_info = receiver.get_user_info("ou_xxxxx")
    print(f"User info: {user_info}")


if __name__ == "__main__":
    main()
